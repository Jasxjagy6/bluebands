-- =====================================================================
-- EmpireBlox: updates 11, 12, 13 and 14 in one go
-- Paste this whole file into Supabase → SQL Editor → New query → Run.
-- If Supabase asks about RLS, choose "Run without RLS". Safe to run twice.
-- =====================================================================

-- =====================================================================
-- EmpireBlox update 11 (includes everything in updates 9 and 10)
-- Run once in Supabase → SQL Editor → New query → paste → Run.
-- If Supabase asks about RLS, choose "Run without RLS". Safe to run twice.
-- Keeps all players, coins and history.
--
--  • 50 cases, from 600 coins up
--  • Regular pulls: 70% junk (a few % of the price), 20% quarter-to-half back, 10% about three-quarters back
--  • Gold dice prizes (about 6 per case, ~2x to 30-100x the price) hit 1%, 5% or 10% of the time
--  • Pays back roughly 30% (1% dice cases) to 45-60% (5-10% dice cases)
--  • Admin: hide a player from the weekly leaderboard
-- =====================================================================

insert into public.cases (id, name, sort, price, image, active) values
  ('peppermint', 'Peppermint', 100, 1000, 'assets/cases/peppermint.webp', true),
  ('crystal-egg', 'Crystal Egg', 101, 1100, 'assets/cases/crystal-egg.webp', true),
  ('faberge', 'Fabergé', 102, 1000, 'assets/cases/faberge.webp', true),
  ('zombie-horde', 'Zombie Horde', 103, 1200, 'assets/cases/zombie-horde.webp', true),
  ('haunted-patch', 'Haunted Patch', 104, 1500, 'assets/cases/haunted-patch.webp', true),
  ('fiesta', 'Fiesta', 105, 2000, 'assets/cases/fiesta.webp', true),
  ('overgrown', 'Overgrown', 106, 2500, 'assets/cases/overgrown.webp', true),
  ('dragon-hatch', 'Dragon Hatch', 107, 3000, 'assets/cases/dragon-hatch.webp', true),
  ('orbit', 'Orbit', 108, 3900, 'assets/cases/orbit.webp', true),
  ('martian', 'Martian', 109, 5000, 'assets/cases/martian.webp', true),
  ('blue-grin', 'Blue Grin', 110, 5200, 'assets/cases/blue-grin.webp', true),
  ('gearhead', 'Gearhead', 111, 6500, 'assets/cases/gearhead.webp', true),
  ('gilded-night', 'Gilded Night', 112, 6600, 'assets/cases/gilded-night.webp', true),
  ('spooky-beats', 'Spooky Beats', 113, 8000, 'assets/cases/spooky-beats.webp', true),
  ('atlantis', 'Atlantis', 114, 9100, 'assets/cases/atlantis.webp', true),
  ('ember', 'Ember', 115, 9800, 'assets/cases/ember.webp', true),
  ('topaz', 'Topaz', 116, 10000, 'assets/cases/topaz.webp', true),
  ('tide-blade', 'Tide Blade', 117, 12000, 'assets/cases/tide-blade.webp', true),
  ('brass-samurai', 'Brass Samurai', 118, 15000, 'assets/cases/brass-samurai.webp', true),
  ('bubblegum-grin', 'Bubblegum Grin', 119, 16000, 'assets/cases/bubblegum-grin.webp', true),
  ('shogun', 'Shogun', 120, 20000, 'assets/cases/shogun.webp', true),
  ('golden-snow', 'Golden Snow', 121, 21000, 'assets/cases/golden-snow.webp', true),
  ('frostbite', 'Frostbite', 122, 22000, 'assets/cases/frostbite.webp', true),
  ('pop-art', 'Pop Art', 123, 23000, 'assets/cases/pop-art.webp', true),
  ('jurassic', 'Jurassic', 124, 25000, 'assets/cases/jurassic.webp', true),
  ('midnight-holly', 'Midnight Holly', 125, 29000, 'assets/cases/midnight-holly.webp', true),
  ('viking-ember', 'Viking Ember', 126, 34000, 'assets/cases/viking-ember.webp', true),
  ('nevermoor', 'Nevermoor', 127, 50000, 'assets/cases/nevermoor.webp', true),
  ('smiley', 'Smiley', 128, 65000, 'assets/cases/smiley.webp', true),
  ('tropical-pop', 'Tropical Pop', 129, 68000, 'assets/cases/tropical-pop.webp', true),
  ('retro-wave', 'Retro Wave', 130, 72000, 'assets/cases/retro-wave.webp', true),
  ('eclipse', 'Eclipse', 131, 75000, 'assets/cases/eclipse.webp', true),
  ('shadow-beats', 'Shadow Beats', 132, 110000, 'assets/cases/shadow-beats.webp', true),
  ('arctic-moss', 'Arctic Moss', 133, 180000, 'assets/cases/arctic-moss.webp', true),
  ('sunbeam', 'Sunbeam', 134, 220000, 'assets/cases/sunbeam.webp', true),
  ('neon-pop', 'Neon Pop', 135, 310000, 'assets/cases/neon-pop.webp', true),
  ('crystal-beats', 'Crystal Beats', 136, 320000, 'assets/cases/crystal-beats.webp', true),
  ('lime-grin', 'Lime Grin', 137, 400000, 'assets/cases/lime-grin.webp', true),
  ('mistletoe', 'Mistletoe', 138, 540000, 'assets/cases/mistletoe.webp', true),
  ('winter-crown', 'Winter Crown', 139, 550000, 'assets/cases/winter-crown.webp', true),
  ('violet-beats', 'Violet Beats', 140, 1000000, 'assets/cases/violet-beats.webp', true),
  ('glacier', 'Glacier', 141, 1000000, 'assets/cases/glacier.webp', true),
  ('evergreen', 'Evergreen', 142, 1000000, 'assets/cases/evergreen.webp', true),
  ('fire-ice', 'Fire Ice', 143, 1600000, 'assets/cases/fire-ice.webp', true),
  ('black-ice', 'Black Ice', 144, 1700000, 'assets/cases/black-ice.webp', true),
  ('amethyst', 'Amethyst', 145, 2800000, 'assets/cases/amethyst.webp', true),
  ('jade', 'Jade', 146, 5000000, 'assets/cases/jade.webp', true),
  ('sapphire', 'Sapphire', 147, 6500000, 'assets/cases/sapphire.webp', true),
  ('sunset-remix', 'Sunset Remix', 148, 7600000, 'assets/cases/sunset-remix.webp', true),
  ('ultimate-grin', 'Ultimate Grin', 149, 28000000, 'assets/cases/ultimate-grin.webp', true)
on conflict (id) do update set name = excluded.name, sort = excluded.sort, price = excluded.price, image = excluded.image, active = true;

delete from public.case_items where case_id in ('peppermint','crystal-egg','faberge','zombie-horde','haunted-patch','fiesta','overgrown','dragon-hatch','orbit','martian','blue-grin','gearhead','gilded-night','spooky-beats','atlantis','ember','topaz','tide-blade','brass-samurai','bubblegum-grin','shogun','golden-snow','frostbite','pop-art','jurassic','midnight-holly','viking-ember','nevermoor','smiley','tropical-pop','retro-wave','eclipse','shadow-beats','arctic-moss','sunbeam','neon-pop','crystal-beats','lime-grin','mistletoe','winter-crown','violet-beats','glacier','evergreen','fire-ice','black-ice','amethyst','jade','sapphire','sunset-remix','ultimate-grin');

insert into public.case_items (case_id, idx, name, value, rarity, weight, catalog_id, art, top) values
  ('peppermint', 0, 'POW! To the Moon! Egg', 400, 'rare', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('peppermint', 1, 'Specular Egg of Red, No Blue', 400, 'rare', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('peppermint', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'rare', 95000, 24826811, 'bighead:#9aa3b8', false),
  ('peppermint', 3, 'Unassuming Egg of Shyness', 400, 'rare', 95000, 24826840, 'bighead:#9aa3b8', false),
  ('peppermint', 4, 'Chrome Egg of Speeding Bullet', 500, 'rare', 95000, 24826640, 'bighead:#9aa3b8', false),
  ('peppermint', 5, 'Snowflake Winter Cap', 1400, 'legendary', 15957, 42846005, 'bighead:#9aa3b8', true),
  ('peppermint', 6, 'Spring into Christmas', 1800, 'legendary', 12766, 67995955, 'bighead:#9aa3b8', true),
  ('peppermint', 7, 'Blue Winter Cap', 3500, 'legendary', 10638, 1309918, 'bighead:#9aa3b8', true),
  ('peppermint', 8, 'Sci-Fi Santa', 4500, 'legendary', 6383, 18729820, 'bighead:#9aa3b8', true),
  ('peppermint', 9, '2010 Party Cap', 7100, 'legendary', 3191, 20044751, 'bighead:#9aa3b8', true),
  ('peppermint', 10, 'Bucket', 18000, 'legendary', 1064, 1081239, 'bighead:#9aa3b8', true),
  ('crystal-egg', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('crystal-egg', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 270000, 24826800, 'bighead:#9aa3b8', false),
  ('crystal-egg', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 90000, 24826811, 'bighead:#9aa3b8', false),
  ('crystal-egg', 3, 'Unassuming Egg of Shyness', 400, 'uncommon', 90000, 24826840, 'bighead:#9aa3b8', false),
  ('crystal-egg', 4, 'Chrome Egg of Speeding Bullet', 500, 'rare', 90000, 24826640, 'bighead:#9aa3b8', false),
  ('crystal-egg', 5, 'Stationary Egg of Boring', 1200, 'legendary', 31915, 1530795, 'bighead:#9aa3b8', true),
  ('crystal-egg', 6, 'Starry Egg of the Wild Ride', 1500, 'legendary', 25532, 31151864, 'bighead:#9aa3b8', true),
  ('crystal-egg', 7, 'Ethereal Ghost Egg', 2000, 'legendary', 21277, 76692331, 'bighead:#9aa3b8', true),
  ('crystal-egg', 8, 'Puzzling Egg of Enigma', 2600, 'legendary', 12766, 1532386, 'bighead:#9aa3b8', true),
  ('crystal-egg', 9, 'Green Fabergé Egg', 3300, 'legendary', 6383, 24832637, 'bighead:#9aa3b8', true),
  ('crystal-egg', 10, 'Invisible Egg of Shadow', 4900, 'legendary', 2128, 1532389, 'bighead:#9aa3b8', true),
  ('faberge', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('faberge', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('faberge', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 99000, 24826811, 'bighead:#9aa3b8', false),
  ('faberge', 3, 'Chrome Egg of Speeding Bullet', 500, 'uncommon', 99000, 24826640, 'bighead:#9aa3b8', false),
  ('faberge', 4, 'Guardia in Exile', 800, 'rare', 99000, 18174901, 'bighead:#9aa3b8', false),
  ('faberge', 5, 'Fried Egg Eye Patch', 3100, 'legendary', 3571, 63647492, 'bighead:#9aa3b8', true),
  ('faberge', 6, 'Invisible Egg of Shadow', 4900, 'legendary', 2857, 1532389, 'bighead:#9aa3b8', true),
  ('faberge', 7, 'Black Iron Warhelm of Pwnage', 10200, 'legendary', 1786, 10351018, 'bighead:#9aa3b8', true),
  ('faberge', 8, 'Mick McCann', 21100, 'legendary', 1071, 23264604, 'bighead:#9aa3b8', true),
  ('faberge', 9, 'Viridian Hood', 41200, 'legendary', 536, 16954107, 'bighead:#9aa3b8', true),
  ('faberge', 10, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 179, 47597760, 'bighead:#9aa3b8', true),
  ('zombie-horde', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('zombie-horde', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('zombie-horde', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 99000, 24826811, 'bighead:#9aa3b8', false),
  ('zombie-horde', 3, 'Rusty Egg of Magnetism', 600, 'uncommon', 99000, 24826787, 'bighead:#9aa3b8', false),
  ('zombie-horde', 4, 'Racing Helmet', 900, 'rare', 99000, 6379764, 'bighead:#9aa3b8', false),
  ('zombie-horde', 5, 'Halloween Harbinger', 3300, 'legendary', 3571, 15727771, 'bighead:#9aa3b8', true),
  ('zombie-horde', 6, 'Halloween Santa Hat', 7100, 'legendary', 2857, 1173851, 'bighead:#9aa3b8', true),
  ('zombie-horde', 7, 'Camoface', 12000, 'legendary', 1786, 24441888, 'bighead:#9aa3b8', true),
  ('zombie-horde', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 1071, 20980122, 'bighead:#9aa3b8', true),
  ('zombie-horde', 9, 'The Crown of Nachos', 44100, 'legendary', 536, 22547617, 'bighead:#9aa3b8', true),
  ('zombie-horde', 10, 'Lava Reactor', 101800, 'legendary', 179, 32858948, 'bighead:#9aa3b8', true),
  ('haunted-patch', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('haunted-patch', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('haunted-patch', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 95000, 24826811, 'bighead:#9aa3b8', false),
  ('haunted-patch', 3, 'Guardia in Exile', 800, 'uncommon', 95000, 18174901, 'bighead:#9aa3b8', false),
  ('haunted-patch', 4, 'Stationary Egg of Boring', 1200, 'rare', 95000, 1530795, 'bighead:#9aa3b8', false),
  ('haunted-patch', 5, 'Halloween Harbinger', 3300, 'legendary', 15957, 15727771, 'bighead:#9aa3b8', true),
  ('haunted-patch', 6, 'Sci-Fi Santa', 4500, 'legendary', 12766, 18729820, 'bighead:#9aa3b8', true),
  ('haunted-patch', 7, 'Halloween Santa Hat', 7100, 'legendary', 10638, 1173851, 'bighead:#9aa3b8', true),
  ('haunted-patch', 8, 'Camoface', 12000, 'legendary', 6383, 24441888, 'bighead:#9aa3b8', true),
  ('haunted-patch', 9, 'Failed Proofs of the Riemann Hypothesis', 23100, 'legendary', 3191, 1285300, 'bighead:#9aa3b8', true),
  ('haunted-patch', 10, 'The Crown of Nachos', 44100, 'legendary', 1064, 22547617, 'bighead:#9aa3b8', true),
  ('fiesta', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('fiesta', 1, 'Specular Egg of Red, No Blue', 400, 'common', 270000, 24826800, 'bighead:#9aa3b8', false),
  ('fiesta', 2, 'Rusty Egg of Magnetism', 600, 'uncommon', 90000, 24826787, 'bighead:#9aa3b8', false),
  ('fiesta', 3, 'Arctic Hood', 1000, 'uncommon', 90000, 18171366, 'bighead:#9aa3b8', false),
  ('fiesta', 4, 'Starry Egg of the Wild Ride', 1500, 'rare', 90000, 31151864, 'bighead:#9aa3b8', false),
  ('fiesta', 5, 'Ultimate Slide Skateboard', 3700, 'legendary', 31915, 52180878, 'bighead:#9aa3b8', true),
  ('fiesta', 6, 'Bloxxadore Domino Mask', 5200, 'legendary', 25532, 14492461, 'bighead:#9aa3b8', true),
  ('fiesta', 7, 'Black Paintball Mask', 6800, 'legendary', 21277, 9254521, 'bighead:#9aa3b8', true),
  ('fiesta', 8, '2010 Party Cap', 7100, 'legendary', 12766, 20044751, 'bighead:#9aa3b8', true),
  ('fiesta', 9, 'Black Iron Warhelm of Pwnage', 10200, 'legendary', 6383, 10351018, 'bighead:#9aa3b8', true),
  ('fiesta', 10, 'Bucket', 18000, 'legendary', 2128, 1081239, 'bighead:#9aa3b8', true),
  ('overgrown', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('overgrown', 1, 'Specular Egg of Red, No Blue', 400, 'common', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('overgrown', 2, 'Chaos Canyon Sugar Egg', 700, 'uncommon', 95000, 76692143, 'bighead:#9aa3b8', false),
  ('overgrown', 3, 'Turbo Builders Club Hard Hat', 1300, 'uncommon', 95000, 11844853, 'bighead:#9aa3b8', false),
  ('overgrown', 4, 'Blinking Egg of Relocation', 1800, 'rare', 95000, 1532381, 'bighead:#9aa3b8', false),
  ('overgrown', 5, 'Treehugger Visor', 5700, 'legendary', 15957, 9910514, 'bighead:#9aa3b8', true),
  ('overgrown', 6, 'Mandrake Root', 10400, 'legendary', 12766, 1191812, 'bighead:#9aa3b8', true),
  ('overgrown', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 10638, 14817131, 'bighead:#9aa3b8', true),
  ('overgrown', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('overgrown', 9, 'Viridian Hood', 41200, 'legendary', 3191, 16954107, 'bighead:#9aa3b8', true),
  ('overgrown', 10, 'Lava Reactor', 101800, 'legendary', 1064, 32858948, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 1, 'Specular Egg of Red, No Blue', 400, 'common', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 2, 'Guardia in Exile', 800, 'uncommon', 95000, 18174901, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 3, 'Starry Egg of the Wild Ride', 1500, 'uncommon', 95000, 31151864, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 4, '2009 Graduation Cap', 2300, 'rare', 95000, 11721340, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 5, 'Invisible Egg of Shadow', 4900, 'legendary', 15957, 1532389, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 6, 'Robosquid', 9200, 'legendary', 12766, 37238566, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 10638, 14817131, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 9, 'The Crown of Nachos', 44100, 'legendary', 3191, 22547617, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 10, 'Playful Vampire', 90000, 'legendary', 1064, 2409285794, 'bighead:#9aa3b8', true),
  ('orbit', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('orbit', 1, 'Specular Egg of Red, No Blue', 400, 'common', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('orbit', 2, 'Arctic Hood', 1000, 'uncommon', 99000, 18171366, 'bighead:#9aa3b8', false),
  ('orbit', 3, 'Christmas Baseball Cap', 2000, 'uncommon', 99000, 1272713, 'bighead:#9aa3b8', false),
  ('orbit', 4, 'The Moon', 2900, 'rare', 99000, 7319168, 'bighead:#9aa3b8', false),
  ('orbit', 5, 'Bag O'' Noobs', 11800, 'legendary', 3571, 32355759, 'bighead:#9aa3b8', true),
  ('orbit', 6, 'Seeing Stars', 18700, 'legendary', 2857, 27599954, 'bighead:#9aa3b8', true),
  ('orbit', 7, 'Viridian Hood', 41200, 'legendary', 1786, 16954107, 'bighead:#9aa3b8', true),
  ('orbit', 8, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 1071, 47597760, 'bighead:#9aa3b8', true),
  ('orbit', 9, 'Super Super Happy Face', 162000, 'legendary', 536, 494291269, 'bighead:#9aa3b8', true),
  ('orbit', 10, 'Monstars Visor', 270000, 'legendary', 179, 1086815, 'bighead:#9aa3b8', true),
  ('martian', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('martian', 1, 'Chrome Egg of Speeding Bullet', 500, 'common', 270000, 24826640, 'bighead:#9aa3b8', false),
  ('martian', 2, 'Pink Penguin', 1400, 'uncommon', 90000, 16985920, 'bighead:#9aa3b8', false),
  ('martian', 3, 'Red Baseball Cap', 2500, 'uncommon', 90000, 1028606, 'bighead:#9aa3b8', false),
  ('martian', 4, 'Ultimate Slide Skateboard', 3700, 'rare', 90000, 52180878, 'bighead:#9aa3b8', false),
  ('martian', 5, 'Greenbot', 10200, 'legendary', 31915, 22023239, 'bighead:#9aa3b8', true),
  ('martian', 6, 'Ochre Ogre', 10900, 'legendary', 25532, 16723499, 'bighead:#9aa3b8', true),
  ('martian', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 21277, 14817131, 'bighead:#9aa3b8', true),
  ('martian', 8, 'Bucket', 18000, 'legendary', 12766, 1081239, 'bighead:#9aa3b8', true),
  ('martian', 9, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('martian', 10, 'Viridian Hood', 41200, 'legendary', 2128, 16954107, 'bighead:#9aa3b8', true),
  ('blue-grin', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('blue-grin', 1, 'Chrome Egg of Speeding Bullet', 500, 'common', 285000, 24826640, 'bighead:#9aa3b8', false),
  ('blue-grin', 2, 'Starry Egg of the Wild Ride', 1500, 'uncommon', 95000, 31151864, 'bighead:#9aa3b8', false),
  ('blue-grin', 3, 'Puzzling Egg of Enigma', 2600, 'uncommon', 95000, 1532386, 'bighead:#9aa3b8', false),
  ('blue-grin', 4, 'Headrow', 3900, 'rare', 95000, 1082935, 'bighead:#9aa3b8', false),
  ('blue-grin', 5, 'Seeing Stars', 18700, 'legendary', 15957, 27599954, 'bighead:#9aa3b8', true),
  ('blue-grin', 6, 'Mick McCann', 21100, 'legendary', 12766, 23264604, 'bighead:#9aa3b8', true),
  ('blue-grin', 7, 'Hotdog Head', 35800, 'legendary', 10638, 15318156, 'bighead:#9aa3b8', true),
  ('blue-grin', 8, 'The Bluesteel Bathelm', 63000, 'legendary', 6383, 1172161, 'bighead:#9aa3b8', true),
  ('blue-grin', 9, 'Lava Reactor', 101800, 'legendary', 3191, 32858948, 'bighead:#9aa3b8', true),
  ('blue-grin', 10, 'The Ice Skull of Nevermoor', 180000, 'legendary', 1064, 6552254, 'bighead:#9aa3b8', true),
  ('gearhead', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('gearhead', 1, 'Chaos Canyon Sugar Egg', 700, 'common', 285000, 76692143, 'bighead:#9aa3b8', false),
  ('gearhead', 2, 'Blinking Egg of Relocation', 1800, 'uncommon', 95000, 1532381, 'bighead:#9aa3b8', false),
  ('gearhead', 3, 'Halloween Harbinger', 3300, 'uncommon', 95000, 15727771, 'bighead:#9aa3b8', false),
  ('gearhead', 4, 'Invisible Egg of Shadow', 4900, 'rare', 95000, 1532389, 'bighead:#9aa3b8', false),
  ('gearhead', 5, 'Kid Robot', 12500, 'legendary', 15957, 29283299, 'bighead:#9aa3b8', true),
  ('gearhead', 6, 'Burning Otaku, the Firesouled', 24600, 'legendary', 12766, 20980122, 'bighead:#9aa3b8', true),
  ('gearhead', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('gearhead', 8, 'Wildcard', 65400, 'legendary', 6383, 38322996, 'bighead:#9aa3b8', true),
  ('gearhead', 9, 'Even Eviler Jester', 106700, 'legendary', 3191, 40893465, 'bighead:#9aa3b8', true),
  ('gearhead', 10, 'Monstars Visor', 270000, 'legendary', 1064, 1086815, 'bighead:#9aa3b8', true),
  ('gilded-night', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('gilded-night', 1, 'Chaos Canyon Sugar Egg', 700, 'common', 297000, 76692143, 'bighead:#9aa3b8', false),
  ('gilded-night', 2, 'Blinking Egg of Relocation', 1800, 'uncommon', 99000, 1532381, 'bighead:#9aa3b8', false),
  ('gilded-night', 3, 'Halloween Harbinger', 3300, 'uncommon', 99000, 15727771, 'bighead:#9aa3b8', false),
  ('gilded-night', 4, 'The Viper Band', 5000, 'rare', 99000, 18482403, 'bighead:#9aa3b8', false),
  ('gilded-night', 5, 'Seeing Stars', 18700, 'legendary', 3571, 27599954, 'bighead:#9aa3b8', true),
  ('gilded-night', 6, 'Golden Headphones', 52700, 'legendary', 2857, 29051524, 'bighead:#9aa3b8', true),
  ('gilded-night', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 1786, 47597760, 'bighead:#9aa3b8', true),
  ('gilded-night', 8, 'Super Super Happy Face', 162000, 'legendary', 1071, 494291269, 'bighead:#9aa3b8', true),
  ('gilded-night', 9, 'Monstars Visor', 270000, 'legendary', 536, 1086815, 'bighead:#9aa3b8', true),
  ('gilded-night', 10, 'Valkyrie Helm', 540000, 'legendary', 179, 1365767, 'bighead:#9aa3b8', true),
  ('spooky-beats', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('spooky-beats', 1, 'Guardia in Exile', 800, 'common', 285000, 18174901, 'bighead:#9aa3b8', false),
  ('spooky-beats', 2, 'Bouncing Egg of Boing Boing', 2200, 'uncommon', 95000, 1532384, 'bighead:#9aa3b8', false),
  ('spooky-beats', 3, 'The Earth', 4100, 'uncommon', 95000, 10072631, 'bighead:#9aa3b8', false),
  ('spooky-beats', 4, 'Gold Buckle Capotain', 6200, 'rare', 95000, 5671970, 'bighead:#9aa3b8', false),
  ('spooky-beats', 5, 'Bucket', 18000, 'legendary', 15957, 1081239, 'bighead:#9aa3b8', true),
  ('spooky-beats', 6, 'Burning Otaku, the Firesouled', 24600, 'legendary', 12766, 20980122, 'bighead:#9aa3b8', true),
  ('spooky-beats', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('spooky-beats', 8, 'The Bluesteel Bathelm', 63000, 'legendary', 6383, 1172161, 'bighead:#9aa3b8', true),
  ('spooky-beats', 9, 'Even Eviler Jester', 106700, 'legendary', 3191, 40893465, 'bighead:#9aa3b8', true),
  ('spooky-beats', 10, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1064, 1073690, 'bighead:#9aa3b8', true),
  ('atlantis', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('atlantis', 1, 'Racing Helmet', 900, 'common', 270000, 6379764, 'bighead:#9aa3b8', false),
  ('atlantis', 2, 'Red Baseball Cap', 2500, 'uncommon', 90000, 1028606, 'bighead:#9aa3b8', false),
  ('atlantis', 3, 'Black Lightning', 4600, 'uncommon', 90000, 29532225, 'bighead:#9aa3b8', false),
  ('atlantis', 4, 'Black Paintball Mask', 6800, 'rare', 90000, 9254521, 'bighead:#9aa3b8', false),
  ('atlantis', 5, 'Bucket', 18000, 'legendary', 31915, 1081239, 'bighead:#9aa3b8', true),
  ('atlantis', 6, 'Mick McCann', 21100, 'legendary', 25532, 23264604, 'bighead:#9aa3b8', true),
  ('atlantis', 7, 'Burning Otaku, the Firesouled', 24600, 'legendary', 21277, 20980122, 'bighead:#9aa3b8', true),
  ('atlantis', 8, 'Hotdog Head', 35800, 'legendary', 12766, 15318156, 'bighead:#9aa3b8', true),
  ('atlantis', 9, 'The Crown of Nachos', 44100, 'legendary', 6383, 22547617, 'bighead:#9aa3b8', true),
  ('atlantis', 10, 'The Bluesteel Bathelm', 63000, 'legendary', 2128, 1172161, 'bighead:#9aa3b8', true),
  ('ember', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('ember', 1, 'Arctic Hood', 1000, 'common', 270000, 18171366, 'bighead:#9aa3b8', false),
  ('ember', 2, 'Target Hat', 2700, 'uncommon', 90000, 1051578, 'bighead:#9aa3b8', false),
  ('ember', 3, 'Invisible Egg of Shadow', 4900, 'uncommon', 90000, 1532389, 'bighead:#9aa3b8', false),
  ('ember', 4, 'White Witch Hat', 7300, 'rare', 90000, 5207053, 'bighead:#9aa3b8', false),
  ('ember', 5, 'Burning Otaku, the Firesouled', 24600, 'legendary', 31915, 20980122, 'bighead:#9aa3b8', true),
  ('ember', 6, 'Hotdog Head', 35800, 'legendary', 25532, 15318156, 'bighead:#9aa3b8', true),
  ('ember', 7, 'Viridian Hood', 41200, 'legendary', 21277, 16954107, 'bighead:#9aa3b8', true),
  ('ember', 8, 'Imagine', 41400, 'legendary', 12766, 30394316, 'bighead:#9aa3b8', true),
  ('ember', 9, 'Golden Headphones', 52700, 'legendary', 6383, 29051524, 'bighead:#9aa3b8', true),
  ('ember', 10, 'Lava Reactor', 101800, 'legendary', 2128, 32858948, 'bighead:#9aa3b8', true),
  ('topaz', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('topaz', 1, 'Arctic Hood', 1000, 'common', 285000, 18171366, 'bighead:#9aa3b8', false),
  ('topaz', 2, 'White Ninja Headband of the Unimpeachable Soul', 2800, 'uncommon', 95000, 11297746, 'bighead:#9aa3b8', false),
  ('topaz', 3, 'The Viper Band', 5000, 'uncommon', 95000, 18482403, 'bighead:#9aa3b8', false),
  ('topaz', 4, 'White Witch Hat', 7300, 'rare', 95000, 5207053, 'bighead:#9aa3b8', false),
  ('topaz', 5, 'Mick McCann', 21100, 'legendary', 15957, 23264604, 'bighead:#9aa3b8', true),
  ('topaz', 6, 'The Crown of Nachos', 44100, 'legendary', 12766, 22547617, 'bighead:#9aa3b8', true),
  ('topaz', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('topaz', 8, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 6383, 47597760, 'bighead:#9aa3b8', true),
  ('topaz', 9, 'Super Super Happy Face', 162000, 'legendary', 3191, 494291269, 'bighead:#9aa3b8', true),
  ('topaz', 10, 'Monstars Visor', 270000, 'legendary', 1064, 1086815, 'bighead:#9aa3b8', true),
  ('tide-blade', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('tide-blade', 1, 'Stationary Egg of Boring', 1200, 'common', 297000, 1530795, 'bighead:#9aa3b8', false),
  ('tide-blade', 2, 'Halloween Harbinger', 3300, 'uncommon', 99000, 15727771, 'bighead:#9aa3b8', false),
  ('tide-blade', 3, 'Gold Buckle Capotain', 6200, 'uncommon', 99000, 5671970, 'bighead:#9aa3b8', false),
  ('tide-blade', 4, 'Robosquid', 9200, 'rare', 99000, 37238566, 'bighead:#9aa3b8', false),
  ('tide-blade', 5, 'Hotdog Head', 35800, 'legendary', 3571, 15318156, 'bighead:#9aa3b8', true),
  ('tide-blade', 6, 'Sword of the Winter Winds', 57600, 'legendary', 2857, 42847923, 'bighead:#9aa3b8', true),
  ('tide-blade', 7, 'Even Eviler Jester', 106700, 'legendary', 1786, 40893465, 'bighead:#9aa3b8', true),
  ('tide-blade', 8, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1071, 1073690, 'bighead:#9aa3b8', true),
  ('tide-blade', 9, 'Valkyrie Helm', 540000, 'legendary', 536, 1365767, 'bighead:#9aa3b8', true),
  ('tide-blade', 10, 'Spec Beta Biograft Energy Sword', 1260000, 'legendary', 179, 14876573, 'bighead:#9aa3b8', true),
  ('brass-samurai', 0, 'Chrome Egg of Speeding Bullet', 500, 'common', 380000, 24826640, 'bighead:#9aa3b8', false),
  ('brass-samurai', 1, 'Starry Egg of the Wild Ride', 1500, 'common', 285000, 31151864, 'bighead:#9aa3b8', false),
  ('brass-samurai', 2, 'Golden Egg of Kings', 4200, 'uncommon', 95000, 1532387, 'bighead:#9aa3b8', false),
  ('brass-samurai', 3, 'White Witch Hat', 7300, 'uncommon', 95000, 5207053, 'bighead:#9aa3b8', false),
  ('brass-samurai', 4, 'Hollywood Sign', 11300, 'rare', 95000, 17614445, 'bighead:#9aa3b8', false),
  ('brass-samurai', 5, 'Hotdog Head', 35800, 'legendary', 15957, 15318156, 'bighead:#9aa3b8', true),
  ('brass-samurai', 6, 'Golden Headphones', 52700, 'legendary', 12766, 29051524, 'bighead:#9aa3b8', true),
  ('brass-samurai', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 10638, 47597760, 'bighead:#9aa3b8', true),
  ('brass-samurai', 8, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('brass-samurai', 9, 'JJ5x5''s White Top Hat', 243000, 'legendary', 3191, 1073690, 'bighead:#9aa3b8', true),
  ('brass-samurai', 10, 'Valkyrie Helm', 540000, 'legendary', 1064, 1365767, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 0, 'Chrome Egg of Speeding Bullet', 500, 'common', 380000, 24826640, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 1, 'Outrageous Builders Club Hard Hat', 1600, 'common', 285000, 17408283, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 2, 'Sci-Fi Santa', 4500, 'uncommon', 95000, 18729820, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 3, 'Das Deutschlandlied', 8400, 'uncommon', 95000, 26018282, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 4, 'Camoface', 12000, 'rare', 95000, 24441888, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 5, 'Bubble Trouble', 57600, 'legendary', 15957, 19264845, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 6, 'Sundae Best', 74600, 'legendary', 12766, 35685322, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 7, 'Lava Reactor', 101800, 'legendary', 10638, 32858948, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 8, 'Super Super Happy Face', 162000, 'legendary', 6383, 494291269, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 9, 'Monstars Visor', 270000, 'legendary', 3191, 1086815, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 10, 'Wanwood Antlers', 630000, 'legendary', 1064, 1272714, 'bighead:#9aa3b8', true),
  ('shogun', 0, 'Rusty Egg of Magnetism', 600, 'common', 380000, 24826787, 'bighead:#9aa3b8', false),
  ('shogun', 1, 'Christmas Baseball Cap', 2000, 'common', 285000, 1272713, 'bighead:#9aa3b8', false),
  ('shogun', 2, 'Ladies Who Lunch', 5600, 'uncommon', 95000, 35167841, 'bighead:#9aa3b8', false),
  ('shogun', 3, 'Black Iron Warhelm of Pwnage', 10200, 'uncommon', 95000, 10351018, 'bighead:#9aa3b8', false),
  ('shogun', 4, 'Outlawed Vampumatiger Hybrid', 13800, 'rare', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('shogun', 5, 'The Bluesteel Bathelm', 63000, 'legendary', 15957, 1172161, 'bighead:#9aa3b8', true),
  ('shogun', 6, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 12766, 47597760, 'bighead:#9aa3b8', true),
  ('shogun', 7, 'Even Eviler Jester', 106700, 'legendary', 10638, 40893465, 'bighead:#9aa3b8', true),
  ('shogun', 8, 'Picklace', 192600, 'legendary', 6383, 33615415, 'bighead:#9aa3b8', true),
  ('shogun', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('shogun', 10, 'Helm of the Sacred Earth', 900000, 'legendary', 1064, 22157971, 'bighead:#9aa3b8', true),
  ('golden-snow', 0, 'Rusty Egg of Magnetism', 600, 'common', 380000, 24826787, 'bighead:#9aa3b8', false),
  ('golden-snow', 1, 'Kind Egg of Sharing', 2100, 'common', 285000, 1532395, 'bighead:#9aa3b8', false),
  ('golden-snow', 2, 'Santa Hat', 5800, 'uncommon', 95000, 1098277, 'bighead:#9aa3b8', false),
  ('golden-snow', 3, 'Mandrake Root', 10400, 'uncommon', 95000, 1191812, 'bighead:#9aa3b8', false),
  ('golden-snow', 4, 'Outlawed Vampumatiger Hybrid', 13800, 'rare', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('golden-snow', 5, 'Golden Headphones', 52700, 'legendary', 15957, 29051524, 'bighead:#9aa3b8', true),
  ('golden-snow', 6, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 12766, 47597760, 'bighead:#9aa3b8', true),
  ('golden-snow', 7, 'Even Eviler Jester', 106700, 'legendary', 10638, 40893465, 'bighead:#9aa3b8', true),
  ('golden-snow', 8, 'Korblox King', 168200, 'legendary', 6383, 52492417, 'bighead:#9aa3b8', true),
  ('golden-snow', 9, 'Monstars Visor', 270000, 'legendary', 3191, 1086815, 'bighead:#9aa3b8', true),
  ('golden-snow', 10, 'Wanwood Antlers', 630000, 'legendary', 1064, 1272714, 'bighead:#9aa3b8', true),
  ('frostbite', 0, 'Chaos Canyon Sugar Egg', 700, 'common', 396000, 76692143, 'bighead:#9aa3b8', false),
  ('frostbite', 1, 'Bouncing Egg of Boing Boing', 2200, 'common', 297000, 1532384, 'bighead:#9aa3b8', false),
  ('frostbite', 2, 'Gold Buckle Capotain', 6200, 'uncommon', 99000, 5671970, 'bighead:#9aa3b8', false),
  ('frostbite', 3, 'Ochre Ogre', 10900, 'uncommon', 99000, 16723499, 'bighead:#9aa3b8', false),
  ('frostbite', 4, 'Bucket', 18000, 'rare', 99000, 1081239, 'bighead:#9aa3b8', false),
  ('frostbite', 5, 'The Bluesteel Bathelm', 63000, 'legendary', 3571, 1172161, 'bighead:#9aa3b8', true),
  ('frostbite', 6, 'The Ice Skull of Nevermoor', 180000, 'legendary', 2857, 6552254, 'bighead:#9aa3b8', true),
  ('frostbite', 7, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1786, 1073690, 'bighead:#9aa3b8', true),
  ('frostbite', 8, 'Valkyrie Helm', 540000, 'legendary', 1071, 1365767, 'bighead:#9aa3b8', true),
  ('frostbite', 9, 'Green Ice Crown', 954000, 'legendary', 536, 193696233, 'bighead:#9aa3b8', true),
  ('frostbite', 10, 'Hooded Frostlord', 1800000, 'legendary', 179, 136802867, 'bighead:#9aa3b8', true),
  ('pop-art', 0, 'Chaos Canyon Sugar Egg', 700, 'common', 360000, 76692143, 'bighead:#9aa3b8', false),
  ('pop-art', 1, '2009 Graduation Cap', 2300, 'common', 270000, 11721340, 'bighead:#9aa3b8', false),
  ('pop-art', 2, 'For the Ages: Abraham Lincoln', 6400, 'uncommon', 90000, 46363235, 'bighead:#9aa3b8', false),
  ('pop-art', 3, 'Hollywood Sign', 11300, 'uncommon', 90000, 17614445, 'bighead:#9aa3b8', false),
  ('pop-art', 4, 'Bucket', 18000, 'rare', 90000, 1081239, 'bighead:#9aa3b8', false),
  ('pop-art', 5, 'Wildcard', 65400, 'legendary', 31915, 38322996, 'bighead:#9aa3b8', true),
  ('pop-art', 6, 'Sundae Best', 74600, 'legendary', 25532, 35685322, 'bighead:#9aa3b8', true),
  ('pop-art', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 21277, 47597760, 'bighead:#9aa3b8', true),
  ('pop-art', 8, 'Playful Vampire', 90000, 'legendary', 12766, 2409285794, 'bighead:#9aa3b8', true),
  ('pop-art', 9, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('pop-art', 10, 'Super Super Happy Face', 162000, 'legendary', 2128, 494291269, 'bighead:#9aa3b8', true),
  ('jurassic', 0, 'Guardia in Exile', 800, 'common', 360000, 18174901, 'bighead:#9aa3b8', false),
  ('jurassic', 1, 'Red Baseball Cap', 2500, 'common', 270000, 1028606, 'bighead:#9aa3b8', false),
  ('jurassic', 2, '2010 Party Cap', 7100, 'uncommon', 90000, 20044751, 'bighead:#9aa3b8', false),
  ('jurassic', 3, 'Kid Robot', 12500, 'uncommon', 90000, 29283299, 'bighead:#9aa3b8', false),
  ('jurassic', 4, 'Seeing Stars', 18700, 'rare', 90000, 27599954, 'bighead:#9aa3b8', false),
  ('jurassic', 5, 'The Crown of Nachos', 44100, 'legendary', 31915, 22547617, 'bighead:#9aa3b8', true),
  ('jurassic', 6, 'Pin Head', 56100, 'legendary', 25532, 25880554, 'bighead:#9aa3b8', true),
  ('jurassic', 7, 'Sundae Best', 74600, 'legendary', 21277, 35685322, 'bighead:#9aa3b8', true),
  ('jurassic', 8, 'Playful Vampire', 90000, 'legendary', 12766, 2409285794, 'bighead:#9aa3b8', true),
  ('jurassic', 9, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('jurassic', 10, 'Picklace', 192600, 'legendary', 2128, 33615415, 'bighead:#9aa3b8', true),
  ('midnight-holly', 0, 'Racing Helmet', 900, 'common', 380000, 6379764, 'bighead:#9aa3b8', false),
  ('midnight-holly', 1, 'The Moon', 2900, 'common', 285000, 7319168, 'bighead:#9aa3b8', false),
  ('midnight-holly', 2, 'Das Deutschlandlied', 8400, 'uncommon', 95000, 26018282, 'bighead:#9aa3b8', false),
  ('midnight-holly', 3, 'Outlawed Vampumatiger Hybrid', 13800, 'uncommon', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('midnight-holly', 4, 'Mick McCann', 21100, 'rare', 95000, 23264604, 'bighead:#9aa3b8', false),
  ('midnight-holly', 5, 'Even Eviler Jester', 106700, 'legendary', 15957, 40893465, 'bighead:#9aa3b8', true),
  ('midnight-holly', 6, 'Super Super Happy Face', 162000, 'legendary', 12766, 494291269, 'bighead:#9aa3b8', true),
  ('midnight-holly', 7, 'Korblox King', 168200, 'legendary', 10638, 52492417, 'bighead:#9aa3b8', true),
  ('midnight-holly', 8, 'Monstars Visor', 270000, 'legendary', 6383, 1086815, 'bighead:#9aa3b8', true),
  ('midnight-holly', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('midnight-holly', 10, 'Pink Queen of the Night', 1026000, 'legendary', 1064, 553971558, 'bighead:#9aa3b8', true),
  ('viking-ember', 0, 'Arctic Hood', 1000, 'common', 380000, 18171366, 'bighead:#9aa3b8', false),
  ('viking-ember', 1, 'Blue Winter Cap', 3500, 'common', 285000, 1309918, 'bighead:#9aa3b8', false),
  ('viking-ember', 2, 'Cyborg Soldier', 9400, 'uncommon', 95000, 27052155, 'bighead:#9aa3b8', false),
  ('viking-ember', 3, 'Bucket', 18000, 'uncommon', 95000, 1081239, 'bighead:#9aa3b8', false),
  ('viking-ember', 4, 'Burning Otaku, the Firesouled', 24600, 'rare', 95000, 20980122, 'bighead:#9aa3b8', false),
  ('viking-ember', 5, 'The Bluesteel Bathelm', 63000, 'legendary', 15957, 1172161, 'bighead:#9aa3b8', true),
  ('viking-ember', 6, 'Lava Reactor', 101800, 'legendary', 12766, 32858948, 'bighead:#9aa3b8', true),
  ('viking-ember', 7, 'Korblox King', 168200, 'legendary', 10638, 52492417, 'bighead:#9aa3b8', true),
  ('viking-ember', 8, 'Monstars Visor', 270000, 'legendary', 6383, 1086815, 'bighead:#9aa3b8', true),
  ('viking-ember', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('viking-ember', 10, 'Helm of the Sacred Earth', 900000, 'legendary', 1064, 22157971, 'bighead:#9aa3b8', true),
  ('nevermoor', 0, 'Starry Egg of the Wild Ride', 1500, 'common', 380000, 31151864, 'bighead:#9aa3b8', false),
  ('nevermoor', 1, 'The Viper Band', 5000, 'common', 285000, 18482403, 'bighead:#9aa3b8', false),
  ('nevermoor', 2, 'Outlawed Vampumatiger Hybrid', 13800, 'uncommon', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('nevermoor', 3, 'Burning Otaku, the Firesouled', 24600, 'uncommon', 95000, 20980122, 'bighead:#9aa3b8', false),
  ('nevermoor', 4, 'Hotdog Head', 35800, 'rare', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('nevermoor', 5, 'Lava Reactor', 101800, 'legendary', 15957, 32858948, 'bighead:#9aa3b8', true),
  ('nevermoor', 6, 'The Ice Skull of Nevermoor', 180000, 'legendary', 12766, 6552254, 'bighead:#9aa3b8', true),
  ('nevermoor', 7, 'JJ5x5''s White Top Hat', 243000, 'legendary', 10638, 1073690, 'bighead:#9aa3b8', true),
  ('nevermoor', 8, 'Valkyrie Helm', 540000, 'legendary', 6383, 1365767, 'bighead:#9aa3b8', true),
  ('nevermoor', 9, 'Ice Valkyrie', 738000, 'legendary', 3191, 4390891467, 'bighead:#9aa3b8', true),
  ('nevermoor', 10, 'Hooded Frostlord', 1800000, 'legendary', 1064, 136802867, 'bighead:#9aa3b8', true),
  ('smiley', 0, 'Christmas Baseball Cap', 2000, 'common', 360000, 1272713, 'bighead:#9aa3b8', false),
  ('smiley', 1, 'For the Ages: Abraham Lincoln', 6400, 'common', 270000, 46363235, 'bighead:#9aa3b8', false),
  ('smiley', 2, 'Bucket', 18000, 'uncommon', 90000, 1081239, 'bighead:#9aa3b8', false),
  ('smiley', 3, 'Hotdog Head', 35800, 'uncommon', 90000, 15318156, 'bighead:#9aa3b8', false),
  ('smiley', 4, 'Golden Headphones', 52700, 'rare', 90000, 29051524, 'bighead:#9aa3b8', false),
  ('smiley', 5, 'Super Super Happy Face', 162000, 'legendary', 34091, 494291269, 'bighead:#9aa3b8', true),
  ('smiley', 6, 'Korblox King', 168200, 'legendary', 27273, 52492417, 'bighead:#9aa3b8', true),
  ('smiley', 7, 'The Ice Skull of Nevermoor', 180000, 'legendary', 22727, 6552254, 'bighead:#9aa3b8', true),
  ('smiley', 8, 'Monstars Visor', 270000, 'legendary', 13636, 1086815, 'bighead:#9aa3b8', true),
  ('smiley', 9, 'Valkyrie Helm', 540000, 'legendary', 2273, 1365767, 'bighead:#9aa3b8', true),
  ('tropical-pop', 0, 'Christmas Baseball Cap', 2000, 'common', 380000, 1272713, 'bighead:#9aa3b8', false),
  ('tropical-pop', 1, 'Black Paintball Mask', 6800, 'common', 285000, 9254521, 'bighead:#9aa3b8', false),
  ('tropical-pop', 2, 'Seeing Stars', 18700, 'uncommon', 95000, 27599954, 'bighead:#9aa3b8', false),
  ('tropical-pop', 3, 'Hotdog Head', 35800, 'uncommon', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('tropical-pop', 4, 'Golden Headphones', 52700, 'rare', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('tropical-pop', 5, 'JJ5x5''s White Top Hat', 243000, 'legendary', 15957, 1073690, 'bighead:#9aa3b8', true),
  ('tropical-pop', 6, 'Monstars Visor', 270000, 'legendary', 12766, 1086815, 'bighead:#9aa3b8', true),
  ('tropical-pop', 7, 'Valkyrie Helm', 540000, 'legendary', 10638, 1365767, 'bighead:#9aa3b8', true),
  ('tropical-pop', 8, 'Wanwood Antlers', 630000, 'legendary', 6383, 1272714, 'bighead:#9aa3b8', true),
  ('tropical-pop', 9, 'Collision Top Hat', 990000, 'legendary', 3191, 158068251, 'bighead:#9aa3b8', true),
  ('tropical-pop', 10, 'Red Crown of Ozymandias', 1980000, 'legendary', 1064, 9465511, 'bighead:#9aa3b8', true),
  ('retro-wave', 0, 'Bouncing Egg of Boing Boing', 2200, 'common', 380000, 1532384, 'bighead:#9aa3b8', false),
  ('retro-wave', 1, 'Traffic Cone', 7200, 'common', 285000, 1082932, 'bighead:#9aa3b8', false),
  ('retro-wave', 2, 'Mick McCann', 21100, 'uncommon', 95000, 23264604, 'bighead:#9aa3b8', false),
  ('retro-wave', 3, 'Hotdog Head', 35800, 'uncommon', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('retro-wave', 4, 'Golden Headphones', 52700, 'rare', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('retro-wave', 5, 'Monstars Visor', 270000, 'legendary', 21429, 1086815, 'bighead:#9aa3b8', true),
  ('retro-wave', 6, 'Valkyrie Helm', 540000, 'legendary', 14286, 1365767, 'bighead:#9aa3b8', true),
  ('retro-wave', 7, 'Glorious Purple Party Queen', 936000, 'legendary', 8571, 258184056, 'bighead:#9aa3b8', true),
  ('retro-wave', 8, 'Clockwork''s Headphones', 1440000, 'legendary', 4286, 1235488, 'bighead:#9aa3b8', true),
  ('retro-wave', 9, 'Retro 80s Headphones', 2520000, 'legendary', 1429, 29844011, 'bighead:#9aa3b8', true),
  ('eclipse', 0, '2009 Graduation Cap', 2300, 'common', 396000, 11721340, 'bighead:#9aa3b8', false),
  ('eclipse', 1, 'White Witch Hat', 7300, 'common', 297000, 5207053, 'bighead:#9aa3b8', false),
  ('eclipse', 2, 'Mick McCann', 21100, 'uncommon', 99000, 23264604, 'bighead:#9aa3b8', false),
  ('eclipse', 3, 'Hotdog Head', 35800, 'uncommon', 99000, 15318156, 'bighead:#9aa3b8', false),
  ('eclipse', 4, 'Pin Head', 56100, 'rare', 99000, 25880554, 'bighead:#9aa3b8', false),
  ('eclipse', 5, 'JJ5x5''s White Top Hat', 243000, 'legendary', 3571, 1073690, 'bighead:#9aa3b8', true),
  ('eclipse', 6, 'Valkyrie Helm', 540000, 'legendary', 2857, 1365767, 'bighead:#9aa3b8', true),
  ('eclipse', 7, 'Silver King of the Night', 846000, 'legendary', 1786, 439945661, 'bighead:#9aa3b8', true),
  ('eclipse', 8, 'Dark Cerulean Crown of Ozymandias', 1512000, 'legendary', 1071, 13370505, 'bighead:#9aa3b8', true),
  ('eclipse', 9, 'Crown of Om Nom Nom', 3060000, 'legendary', 536, 21070350, 'bighead:#9aa3b8', true),
  ('eclipse', 10, 'Gaze of Socom1880', 6120000, 'legendary', 179, 14671091, 'bighead:#9aa3b8', true),
  ('shadow-beats', 0, 'Halloween Harbinger', 3300, 'common', 396000, 15727771, 'bighead:#9aa3b8', false),
  ('shadow-beats', 1, 'Ochre Ogre', 10900, 'common', 297000, 16723499, 'bighead:#9aa3b8', false),
  ('shadow-beats', 2, 'Hotdog Head', 35800, 'uncommon', 99000, 15318156, 'bighead:#9aa3b8', false),
  ('shadow-beats', 3, 'Pin Head', 56100, 'uncommon', 99000, 25880554, 'bighead:#9aa3b8', false),
  ('shadow-beats', 4, 'Golden Chakram of the Sky Palace', 77000, 'rare', 99000, 47597760, 'bighead:#9aa3b8', false),
  ('shadow-beats', 5, 'Monstars Visor', 270000, 'legendary', 3571, 1086815, 'bighead:#9aa3b8', true),
  ('shadow-beats', 6, 'Silver King of the Night', 846000, 'legendary', 2857, 439945661, 'bighead:#9aa3b8', true),
  ('shadow-beats', 7, 'Pink Queen of the Night', 1026000, 'legendary', 1786, 553971558, 'bighead:#9aa3b8', true),
  ('shadow-beats', 8, 'Vaiobot''s Moneylicious Tie', 2250000, 'legendary', 1071, 30371876, 'bighead:#9aa3b8', true),
  ('shadow-beats', 9, 'Sword Cane', 4320000, 'legendary', 536, 25740034, 'bighead:#9aa3b8', true),
  ('shadow-beats', 10, 'Black Iron King of the Night', 10800000, 'legendary', 179, 439946249, 'bighead:#9aa3b8', true),
  ('arctic-moss', 0, 'Ladies Who Lunch', 5600, 'common', 380000, 35167841, 'bighead:#9aa3b8', false),
  ('arctic-moss', 1, 'Bucket', 18000, 'common', 285000, 1081239, 'bighead:#9aa3b8', false),
  ('arctic-moss', 2, 'Golden Headphones', 52700, 'uncommon', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('arctic-moss', 3, 'Playful Vampire', 90000, 'uncommon', 95000, 2409285794, 'bighead:#9aa3b8', false),
  ('arctic-moss', 4, 'Super Super Happy Face', 162000, 'rare', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('arctic-moss', 5, 'Wanwood Antlers', 630000, 'legendary', 15957, 1272714, 'bighead:#9aa3b8', true),
  ('arctic-moss', 6, 'Ice Valkyrie', 738000, 'legendary', 12766, 4390891467, 'bighead:#9aa3b8', true),
  ('arctic-moss', 7, 'Green Ice Crown', 954000, 'legendary', 10638, 193696233, 'bighead:#9aa3b8', true),
  ('arctic-moss', 8, 'Helm of the Great Tree', 1350000, 'legendary', 6383, 9910420, 'bighead:#9aa3b8', true),
  ('arctic-moss', 9, 'Green Bow Tie', 2700000, 'legendary', 3191, 16598513, 'bighead:#9aa3b8', true),
  ('arctic-moss', 10, 'The Ice Crown', 7200000, 'legendary', 1064, 1323384, 'bighead:#9aa3b8', true),
  ('sunbeam', 0, 'One Star General''s Beret', 6700, 'common', 360000, 28039679, 'bighead:#9aa3b8', false),
  ('sunbeam', 1, 'Mick McCann', 21100, 'common', 270000, 23264604, 'bighead:#9aa3b8', false),
  ('sunbeam', 2, 'The Bluesteel Bathelm', 63000, 'uncommon', 90000, 1172161, 'bighead:#9aa3b8', false),
  ('sunbeam', 3, 'Even Eviler Jester', 106700, 'uncommon', 90000, 40893465, 'bighead:#9aa3b8', false),
  ('sunbeam', 4, 'Super Super Happy Face', 162000, 'rare', 90000, 494291269, 'bighead:#9aa3b8', false),
  ('sunbeam', 5, 'Valkyrie Helm', 540000, 'legendary', 31915, 1365767, 'bighead:#9aa3b8', true),
  ('sunbeam', 6, 'Ice Valkyrie', 738000, 'legendary', 25532, 4390891467, 'bighead:#9aa3b8', true),
  ('sunbeam', 7, 'Helm of the Sacred Earth', 900000, 'legendary', 21277, 22157971, 'bighead:#9aa3b8', true),
  ('sunbeam', 8, 'Goldlika: Hero', 936000, 'legendary', 12766, 323419455, 'bighead:#9aa3b8', true),
  ('sunbeam', 9, 'Headdress of Aken-Aten, the Sun King', 1080000, 'legendary', 6383, 18482398, 'bighead:#9aa3b8', true),
  ('sunbeam', 10, 'GoldLika: Troll', 1530000, 'legendary', 2128, 398674241, 'bighead:#9aa3b8', true),
  ('neon-pop', 0, 'Cyborg Soldier', 9400, 'common', 380000, 27052155, 'bighead:#9aa3b8', false),
  ('neon-pop', 1, 'Hotdog Head', 35800, 'common', 285000, 15318156, 'bighead:#9aa3b8', false),
  ('neon-pop', 2, 'Playful Vampire', 90000, 'uncommon', 95000, 2409285794, 'bighead:#9aa3b8', false),
  ('neon-pop', 3, 'Super Super Happy Face', 162000, 'uncommon', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('neon-pop', 4, 'JJ5x5''s White Top Hat', 243000, 'rare', 95000, 1073690, 'bighead:#9aa3b8', false),
  ('neon-pop', 5, 'Neon Purple Crazy Crown', 1116000, 'legendary', 15957, 376805769, 'bighead:#9aa3b8', true),
  ('neon-pop', 6, 'Crazy Glasses', 1350000, 'legendary', 12766, 16646369, 'bighead:#9aa3b8', true),
  ('neon-pop', 7, 'CW Ultimate: Sapphire Serenity', 1890000, 'legendary', 10638, 188888052, 'bighead:#9aa3b8', true),
  ('neon-pop', 8, 'Neon Green Crazy Crown', 2430000, 'legendary', 6383, 321346616, 'bighead:#9aa3b8', true),
  ('neon-pop', 9, 'WC Ultimates: Pink Diamond Distraction', 6300000, 'legendary', 3191, 315549204, 'bighead:#9aa3b8', true),
  ('neon-pop', 10, '): Red Grind', 11700000, 'legendary', 1064, 20573086, 'bighead:#9aa3b8', true),
  ('crystal-beats', 0, 'Cyborg Soldier', 9400, 'common', 396000, 27052155, 'bighead:#9aa3b8', false),
  ('crystal-beats', 1, 'Hotdog Head', 35800, 'common', 297000, 15318156, 'bighead:#9aa3b8', false),
  ('crystal-beats', 2, 'Playful Vampire', 90000, 'uncommon', 99000, 2409285794, 'bighead:#9aa3b8', false),
  ('crystal-beats', 3, 'Super Super Happy Face', 162000, 'uncommon', 99000, 494291269, 'bighead:#9aa3b8', false),
  ('crystal-beats', 4, 'JJ5x5''s White Top Hat', 243000, 'rare', 99000, 1073690, 'bighead:#9aa3b8', false),
  ('crystal-beats', 5, 'Green Ice Crown', 954000, 'legendary', 3571, 193696233, 'bighead:#9aa3b8', true),
  ('crystal-beats', 6, 'Retro 80s Headphones', 2520000, 'legendary', 2857, 29844011, 'bighead:#9aa3b8', true),
  ('crystal-beats', 7, 'Yellow Glowing Eyes', 3240000, 'legendary', 1786, 416846000, 'bighead:#9aa3b8', true),
  ('crystal-beats', 8, 'WC Ultimates: Pink Diamond Distraction', 6300000, 'legendary', 1071, 315549204, 'bighead:#9aa3b8', true),
  ('crystal-beats', 9, 'WC Ultimates: Aquamarine Attitude', 17100000, 'legendary', 536, 323417812, 'bighead:#9aa3b8', true),
  ('crystal-beats', 10, 'Eerie Pumpkin Head', 36000000, 'legendary', 179, 1158416, 'bighead:#9aa3b8', true),
  ('lime-grin', 0, 'Camoface', 12000, 'common', 380000, 24441888, 'bighead:#9aa3b8', false),
  ('lime-grin', 1, 'Viridian Hood', 41200, 'common', 285000, 16954107, 'bighead:#9aa3b8', false),
  ('lime-grin', 2, 'Even Eviler Jester', 106700, 'uncommon', 95000, 40893465, 'bighead:#9aa3b8', false),
  ('lime-grin', 3, 'Picklace', 192600, 'uncommon', 95000, 33615415, 'bighead:#9aa3b8', false),
  ('lime-grin', 4, 'Monstars Visor', 270000, 'rare', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('lime-grin', 5, 'Clockwork''s Headphones', 1440000, 'legendary', 15957, 1235488, 'bighead:#9aa3b8', true),
  ('lime-grin', 6, 'GoldLika: Troll', 1530000, 'legendary', 12766, 398674241, 'bighead:#9aa3b8', true),
  ('lime-grin', 7, 'Neon Green Crazy Crown', 2430000, 'legendary', 10638, 321346616, 'bighead:#9aa3b8', true),
  ('lime-grin', 8, 'Yellow Glowing Eyes', 3240000, 'legendary', 6383, 416846000, 'bighead:#9aa3b8', true),
  ('lime-grin', 9, 'Gaze of Socom1880', 6120000, 'legendary', 3191, 14671091, 'bighead:#9aa3b8', true),
  ('lime-grin', 10, '): Red Grind', 11700000, 'legendary', 1064, 20573086, 'bighead:#9aa3b8', true),
  ('mistletoe', 0, 'Bucket', 18000, 'common', 360000, 1081239, 'bighead:#9aa3b8', false),
  ('mistletoe', 1, 'Golden Headphones', 52700, 'common', 270000, 29051524, 'bighead:#9aa3b8', false),
  ('mistletoe', 2, 'Super Super Happy Face', 162000, 'uncommon', 90000, 494291269, 'bighead:#9aa3b8', false),
  ('mistletoe', 3, 'Monstars Visor', 270000, 'uncommon', 90000, 1086815, 'bighead:#9aa3b8', false),
  ('mistletoe', 4, 'Valkyrie Helm', 540000, 'rare', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('mistletoe', 5, 'Fancy St. Patrick''s Fedora', 1350000, 'legendary', 31915, 149594212, 'bighead:#9aa3b8', true),
  ('mistletoe', 6, 'Immortal Sword: Endless Ice Slasher', 1800000, 'legendary', 25532, 568920951, 'bighead:#9aa3b8', true),
  ('mistletoe', 7, 'CW Ultimate: Sapphire Serenity', 1890000, 'legendary', 21277, 188888052, 'bighead:#9aa3b8', true),
  ('mistletoe', 8, 'Neon Green Crazy Crown', 2430000, 'legendary', 12766, 321346616, 'bighead:#9aa3b8', true),
  ('mistletoe', 9, 'Green Bow Tie', 2700000, 'legendary', 6383, 16598513, 'bighead:#9aa3b8', true),
  ('mistletoe', 10, 'Sparkle Time Fedora', 4500000, 'legendary', 2128, 1285307, 'bighead:#9aa3b8', true),
  ('winter-crown', 0, 'Bucket', 18000, 'common', 380000, 1081239, 'bighead:#9aa3b8', false),
  ('winter-crown', 1, 'Pin Head', 56100, 'common', 285000, 25880554, 'bighead:#9aa3b8', false),
  ('winter-crown', 2, 'Super Super Happy Face', 162000, 'uncommon', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('winter-crown', 3, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('winter-crown', 4, 'Valkyrie Helm', 540000, 'rare', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('winter-crown', 5, 'Red Crown of Ozymandias', 1980000, 'legendary', 15957, 9465511, 'bighead:#9aa3b8', true),
  ('winter-crown', 6, 'Neon Green Crazy Crown', 2430000, 'legendary', 12766, 321346616, 'bighead:#9aa3b8', true),
  ('winter-crown', 7, 'Crown of Om Nom Nom', 3060000, 'legendary', 10638, 21070350, 'bighead:#9aa3b8', true),
  ('winter-crown', 8, 'The Void Star', 5580000, 'legendary', 6383, 1125510, 'bighead:#9aa3b8', true),
  ('winter-crown', 9, 'Black Iron King of the Night', 10800000, 'legendary', 3191, 439946249, 'bighead:#9aa3b8', true),
  ('winter-crown', 10, 'Darkheart', 21600000, 'legendary', 1064, 16895215, 'bighead:#9aa3b8', true),
  ('violet-beats', 0, 'Hotdog Head', 35800, 'common', 360000, 15318156, 'bighead:#9aa3b8', false),
  ('violet-beats', 1, 'Lava Reactor', 101800, 'common', 270000, 32858948, 'bighead:#9aa3b8', false),
  ('violet-beats', 2, 'Monstars Visor', 270000, 'uncommon', 90000, 1086815, 'bighead:#9aa3b8', false),
  ('violet-beats', 3, 'Valkyrie Helm', 540000, 'uncommon', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('violet-beats', 4, 'Ice Valkyrie', 738000, 'rare', 90000, 4390891467, 'bighead:#9aa3b8', false),
  ('violet-beats', 5, 'CW Ultimate: Amethyst Addiction', 2520000, 'legendary', 31915, 188004500, 'bighead:#9aa3b8', true),
  ('violet-beats', 6, 'Crown of the Undead Hoard', 2610000, 'legendary', 25532, 31046644, 'bighead:#9aa3b8', true),
  ('violet-beats', 7, 'Chrononoctis: The Ominous Helm', 2790000, 'legendary', 21277, 161211371, 'bighead:#9aa3b8', true),
  ('violet-beats', 8, 'CW Ultimate: Rose Quartz Rebellion', 3600000, 'legendary', 12766, 228449574, 'bighead:#9aa3b8', true),
  ('violet-beats', 9, 'Steampunk Aetherspectacles', 4860000, 'legendary', 6383, 12908119, 'bighead:#9aa3b8', true),
  ('violet-beats', 10, 'Dominus Rex', 7920000, 'legendary', 2128, 250395631, 'bighead:#9aa3b8', true),
  ('glacier', 0, 'Hotdog Head', 35800, 'common', 380000, 15318156, 'bighead:#9aa3b8', false),
  ('glacier', 1, 'Lava Reactor', 101800, 'common', 285000, 32858948, 'bighead:#9aa3b8', false),
  ('glacier', 2, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('glacier', 3, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('glacier', 4, 'Ice Valkyrie', 738000, 'rare', 95000, 4390891467, 'bighead:#9aa3b8', false),
  ('glacier', 5, 'Frozen Horns of the Frigid Planes', 3600000, 'legendary', 15957, 74891470, 'bighead:#9aa3b8', true),
  ('glacier', 6, 'Fiery Horns of the Netherworld', 3960000, 'legendary', 12766, 215718515, 'bighead:#9aa3b8', true),
  ('glacier', 7, 'Steampunk Aetherspectacles', 4860000, 'legendary', 10638, 12908119, 'bighead:#9aa3b8', true),
  ('glacier', 8, 'The Ice Crown', 7200000, 'legendary', 6383, 1323384, 'bighead:#9aa3b8', true),
  ('glacier', 9, 'The Wanwood Crown', 14400000, 'legendary', 3191, 9910070, 'bighead:#9aa3b8', true),
  ('glacier', 10, 'Eerie Pumpkin Head', 36000000, 'legendary', 1064, 1158416, 'bighead:#9aa3b8', true),
  ('evergreen', 0, 'Hotdog Head', 35800, 'common', 380000, 15318156, 'bighead:#9aa3b8', false),
  ('evergreen', 1, 'Lava Reactor', 101800, 'common', 285000, 32858948, 'bighead:#9aa3b8', false),
  ('evergreen', 2, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('evergreen', 3, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('evergreen', 4, 'Ice Valkyrie', 738000, 'rare', 95000, 4390891467, 'bighead:#9aa3b8', false),
  ('evergreen', 5, 'Green Glowing Eyes', 3780000, 'legendary', 15957, 398676450, 'bighead:#9aa3b8', true),
  ('evergreen', 6, 'CW Ultimate: Emerald Entropy', 4320000, 'legendary', 12766, 271015154, 'bighead:#9aa3b8', true),
  ('evergreen', 7, 'Gaze of Socom1880', 6120000, 'legendary', 10638, 14671091, 'bighead:#9aa3b8', true),
  ('evergreen', 8, 'Red Glowing Eyes', 8280000, 'legendary', 6383, 180660043, 'bighead:#9aa3b8', true),
  ('evergreen', 9, 'Bluesteel Bling $$ Necklace', 18900000, 'legendary', 3191, 489196035, 'bighead:#9aa3b8', true),
  ('evergreen', 10, 'Domino Crown', 43200000, 'legendary', 1064, 1031429, 'bighead:#9aa3b8', true),
  ('fire-ice', 0, 'The Crown of Nachos', 44100, 'common', 360000, 22547617, 'bighead:#9aa3b8', false),
  ('fire-ice', 1, 'Super Super Happy Face', 162000, 'common', 270000, 494291269, 'bighead:#9aa3b8', false),
  ('fire-ice', 2, 'Valkyrie Helm', 540000, 'uncommon', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('fire-ice', 3, 'Silver King of the Night', 846000, 'uncommon', 90000, 439945661, 'bighead:#9aa3b8', false),
  ('fire-ice', 4, 'Crown of Tones', 1188000, 'rare', 90000, 152173424, 'bighead:#9aa3b8', false),
  ('fire-ice', 5, 'Fiery Horns of the Netherworld', 3960000, 'legendary', 31915, 215718515, 'bighead:#9aa3b8', true),
  ('fire-ice', 6, ':( Front Stand', 4050000, 'legendary', 25532, 321346550, 'bighead:#9aa3b8', true),
  ('fire-ice', 7, 'Sparkle Time Fedora', 4500000, 'legendary', 21277, 1285307, 'bighead:#9aa3b8', true),
  ('fire-ice', 8, 'The Ice Crown', 7200000, 'legendary', 12766, 1323384, 'bighead:#9aa3b8', true),
  ('fire-ice', 9, 'Red Glowing Eyes', 8280000, 'legendary', 6383, 180660043, 'bighead:#9aa3b8', true),
  ('fire-ice', 10, '): Red Grind', 11700000, 'legendary', 2128, 20573086, 'bighead:#9aa3b8', true),
  ('black-ice', 0, 'Golden Headphones', 52700, 'common', 380000, 29051524, 'bighead:#9aa3b8', false),
  ('black-ice', 1, 'Korblox King', 168200, 'common', 285000, 52492417, 'bighead:#9aa3b8', false),
  ('black-ice', 2, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('black-ice', 3, 'Silver King of the Night', 846000, 'uncommon', 95000, 439945661, 'bighead:#9aa3b8', false),
  ('black-ice', 4, 'Spec Beta Biograft Energy Sword', 1260000, 'rare', 95000, 14876573, 'bighead:#9aa3b8', false),
  ('black-ice', 5, 'Azurewrath, Lord of the Void', 3420000, 'legendary', 15957, 17109706, 'bighead:#9aa3b8', true),
  ('black-ice', 6, 'The Ice Crown', 7200000, 'legendary', 12766, 1323384, 'bighead:#9aa3b8', true),
  ('black-ice', 7, 'Black Iron King of the Night', 10800000, 'legendary', 10638, 439946249, 'bighead:#9aa3b8', true),
  ('black-ice', 8, 'The Crown of Roses', 13500000, 'legendary', 6383, 17449820, 'bighead:#9aa3b8', true),
  ('black-ice', 9, 'Darkheart', 21600000, 'legendary', 3191, 16895215, 'bighead:#9aa3b8', true),
  ('black-ice', 10, 'Black Sparkle Time Fedora', 45000000, 'legendary', 1064, 259423244, 'bighead:#9aa3b8', true),
  ('amethyst', 0, 'Playful Vampire', 90000, 'common', 396000, 2409285794, 'bighead:#9aa3b8', false),
  ('amethyst', 1, 'Monstars Visor', 270000, 'common', 297000, 1086815, 'bighead:#9aa3b8', false),
  ('amethyst', 2, 'Ice Valkyrie', 738000, 'uncommon', 99000, 4390891467, 'bighead:#9aa3b8', false),
  ('amethyst', 3, 'Dominus Praefectus', 1422000, 'uncommon', 99000, 527365852, 'bighead:#9aa3b8', false),
  ('amethyst', 4, 'Red Crown of Ozymandias', 1980000, 'rare', 99000, 9465511, 'bighead:#9aa3b8', false),
  ('amethyst', 5, 'Countess of the Federation', 9000000, 'legendary', 3571, 188003914, 'bighead:#9aa3b8', true),
  ('amethyst', 6, 'Orange Sparkle Time Fedora', 17100000, 'legendary', 2857, 215751161, 'bighead:#9aa3b8', true),
  ('amethyst', 7, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 1786, 63043890, 'bighead:#9aa3b8', true),
  ('amethyst', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 1071, 259423244, 'bighead:#9aa3b8', true),
  ('amethyst', 9, 'Dominus Astra', 108000000, 'legendary', 536, 162067148, 'bighead:#9aa3b8', true),
  ('amethyst', 10, 'Dominus Empyreus', 198000000, 'legendary', 179, 21070012, 'bighead:#9aa3b8', true),
  ('jade', 0, 'Super Super Happy Face', 162000, 'common', 380000, 494291269, 'bighead:#9aa3b8', false),
  ('jade', 1, 'Valkyrie Helm', 540000, 'common', 285000, 1365767, 'bighead:#9aa3b8', false),
  ('jade', 2, 'Dominus Praefectus', 1422000, 'uncommon', 95000, 527365852, 'bighead:#9aa3b8', false),
  ('jade', 3, 'Clockwork''s Shades', 2520000, 'uncommon', 95000, 11748356, 'bighead:#9aa3b8', false),
  ('jade', 4, 'Green Glowing Eyes', 3780000, 'rare', 95000, 398676450, 'bighead:#9aa3b8', false),
  ('jade', 5, 'Teal Sparkle Time Fedora', 18000000, 'legendary', 15957, 147180077, 'bighead:#9aa3b8', true),
  ('jade', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 12766, 493476042, 'bighead:#9aa3b8', true),
  ('jade', 7, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 10638, 63043890, 'bighead:#9aa3b8', true),
  ('jade', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 6383, 259423244, 'bighead:#9aa3b8', true),
  ('jade', 9, 'Dominus Astra', 108000000, 'legendary', 3191, 162067148, 'bighead:#9aa3b8', true),
  ('jade', 10, 'Dominus Empyreus', 198000000, 'legendary', 1064, 21070012, 'bighead:#9aa3b8', true),
  ('sapphire', 0, 'Picklace', 192600, 'common', 360000, 33615415, 'bighead:#9aa3b8', false),
  ('sapphire', 1, 'Wanwood Antlers', 630000, 'common', 270000, 1272714, 'bighead:#9aa3b8', false),
  ('sapphire', 2, 'Hooded Frostlord', 1800000, 'uncommon', 90000, 136802867, 'bighead:#9aa3b8', false),
  ('sapphire', 3, 'Cultural Item', 3240000, 'uncommon', 90000, 14462955, 'bighead:#9aa3b8', false),
  ('sapphire', 4, 'Steampunk Aetherspectacles', 4860000, 'rare', 90000, 12908119, 'bighead:#9aa3b8', false),
  ('sapphire', 5, '): Red Grind', 11700000, 'legendary', 31915, 20573086, 'bighead:#9aa3b8', true),
  ('sapphire', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 25532, 493476042, 'bighead:#9aa3b8', true),
  ('sapphire', 7, '): Euro 180', 22500000, 'legendary', 21277, 23705521, 'bighead:#9aa3b8', true),
  ('sapphire', 8, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 12766, 63043890, 'bighead:#9aa3b8', true),
  ('sapphire', 9, 'Domino Crown', 43200000, 'legendary', 6383, 1031429, 'bighead:#9aa3b8', true),
  ('sapphire', 10, 'Black Sparkle Time Fedora', 45000000, 'legendary', 2128, 259423244, 'bighead:#9aa3b8', true),
  ('sunset-remix', 0, 'JJ5x5''s White Top Hat', 243000, 'common', 380000, 1073690, 'bighead:#9aa3b8', false),
  ('sunset-remix', 1, 'Ice Valkyrie', 738000, 'common', 285000, 4390891467, 'bighead:#9aa3b8', false),
  ('sunset-remix', 2, 'Vaiobot''s Moneylicious Tie', 2250000, 'uncommon', 95000, 30371876, 'bighead:#9aa3b8', false),
  ('sunset-remix', 3, 'Green Glowing Eyes', 3780000, 'uncommon', 95000, 398676450, 'bighead:#9aa3b8', false),
  ('sunset-remix', 4, 'The Void Star', 5580000, 'rare', 95000, 1125510, 'bighead:#9aa3b8', false),
  ('sunset-remix', 5, 'The Wanwood Crown', 14400000, 'legendary', 15957, 9910070, 'bighead:#9aa3b8', true),
  ('sunset-remix', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 12766, 493476042, 'bighead:#9aa3b8', true),
  ('sunset-remix', 7, 'Domino Crown', 43200000, 'legendary', 10638, 1031429, 'bighead:#9aa3b8', true),
  ('sunset-remix', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 6383, 259423244, 'bighead:#9aa3b8', true),
  ('sunset-remix', 9, 'Dominus Astra', 108000000, 'legendary', 3191, 162067148, 'bighead:#9aa3b8', true),
  ('sunset-remix', 10, 'Dominus Empyreus', 198000000, 'legendary', 1064, 21070012, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 0, 'Silver King of the Night', 846000, 'common', 360000, 439945661, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 1, 'Chrononoctis: The Ominous Helm', 2790000, 'common', 270000, 161211371, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 2, 'Dominus Rex', 7920000, 'uncommon', 90000, 250395631, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 3, 'The Wanwood Crown', 14400000, 'uncommon', 90000, 9910070, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 4, 'Darkheart', 21600000, 'rare', 90000, 16895215, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 5, 'Black Sparkle Time Fedora', 45000000, 'legendary', 34091, 259423244, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 6, 'Dominus Astra', 108000000, 'legendary', 27273, 162067148, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 7, 'Dominus Infernus', 126000000, 'legendary', 22727, 31101391, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 8, 'Dominus Frigidus', 162000000, 'legendary', 13636, 48545806, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 9, 'Dominus Empyreus', 198000000, 'legendary', 2273, 21070012, 'bighead:#9aa3b8', true);

-- Leaderboard: admins can hide a player (their wagers stop counting and they vanish from the board)
alter table public.profiles add column if not exists lb_hidden boolean not null default false;

create or replace function public.add_wager(p_uid uuid, p_game text, p_amount bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set
    wagered         = wagered + p_amount,
    wager_cases     = wager_cases     + case when p_game = 'cases'     then p_amount else 0 end,
    wager_mines     = wager_mines     + case when p_game = 'mines'     then p_amount else 0 end,
    wager_battles   = wager_battles   + case when p_game = 'battles'   then p_amount else 0 end,
    wager_upgrader  = wager_upgrader  + case when p_game = 'upgrader'  then p_amount else 0 end,
    wager_blackjack = wager_blackjack + case when p_game = 'blackjack' then p_amount else 0 end
  where id = p_uid;
  if coalesce((select lb_hidden from public.profiles where id = p_uid), false) then return; end if;
  insert into public.weekly_wagers (week_start, user_id, wagered, updated_at)
  values (public.lb_week(), p_uid, p_amount, now())
  on conflict (week_start, user_id) do update
    set wagered = public.weekly_wagers.wagered + excluded.wagered, updated_at = now();
end $$;


create or replace function public.lb_settle()
returns void language plpgsql security definer set search_path = public as $$
declare w date; r record; prizes bigint[] := public.lb_prizes();
begin
  perform pg_advisory_xact_lock(424242);
  for w in
    select distinct week_start from public.weekly_wagers
     where week_start < public.lb_week()
       and week_start not in (select week_start from public.leaderboard_weeks)
     order by 1
  loop
    for r in
      select user_id, wagered, row_number() over (order by wagered desc, updated_at) as rank
        from public.weekly_wagers where week_start = w and wagered > 0 and user_id not in (select id from public.profiles where lb_hidden)
       order by wagered desc, updated_at limit 10
    loop
      insert into public.leaderboard_payouts (week_start, rank, user_id, wagered, prize)
      values (w, r.rank, r.user_id, r.wagered, prizes[r.rank]);
      update public.profiles set coins = coins + prizes[r.rank], rewards_claimed = rewards_claimed + prizes[r.rank] where id = r.user_id;
      perform public.tx(r.user_id, 'rewards', 'Weekly leaderboard #' || r.rank || ' prize', prizes[r.rank]);
    end loop;
    insert into public.leaderboard_weeks (week_start) values (w);
  end loop;
end $$;


create or replace function public.get_leaderboard()
returns json language plpgsql volatile security definer set search_path = public as $$
declare w date := public.lb_week(); prizes bigint[] := public.lb_prizes(); v_me json; v_top json; v_last json;
begin
  perform public.lb_settle();
  select coalesce(json_agg(t order by t.rank), '[]') into v_top from (
    select row_number() over (order by ww.wagered desc, ww.updated_at) as rank, ww.user_id, p.username, ww.wagered,
           public.level_of(p.wagered) as level
      from public.weekly_wagers ww join public.profiles p on p.id = ww.user_id
     where ww.week_start = w and ww.wagered > 0 and not p.lb_hidden
     order by ww.wagered desc, ww.updated_at limit 50) t;
  if auth.uid() is not null then
    select json_build_object('rank', t.rank, 'wagered', coalesce(t.wagered, 0)) into v_me from (
      select rank, wagered from (
        select user_id, wagered, row_number() over (order by wagered desc, updated_at) as rank
          from public.weekly_wagers where week_start = w and wagered > 0 and user_id not in (select id from public.profiles where lb_hidden)) x
       where user_id = auth.uid()) t;
    if v_me is null then v_me := json_build_object('rank', null, 'wagered', 0); end if;
  end if;
  select coalesce(json_agg(t order by t.rank), '[]') into v_last from (
    select lp.rank, lp.user_id, p.username, lp.wagered, lp.prize
      from public.leaderboard_payouts lp join public.profiles p on p.id = lp.user_id
     where lp.week_start = w - 7) t;
  return json_build_object('week_start', w, 'ends_at', (w + 7)::timestamp at time zone 'UTC',
                           'prizes', prizes, 'top', v_top, 'me', v_me, 'last_week', v_last);
end $$;


create or replace function public.admin_set_lb_hidden(p_user uuid, p_hidden boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  update public.profiles set lb_hidden = p_hidden where id = p_user;
end $$;

create or replace function public.admin_find(p_q text)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  return (select coalesce(json_agg(t order by t.wagered desc), '[]') from (
    select p.id, p.username, u.email, p.coins, p.wagered, p.created_at, p.is_admin, p.lb_hidden
      from public.profiles p left join auth.users u on u.id = p.id
     where p_q is null or p_q = '' or p.username ilike '%' || p_q || '%' or u.email ilike '%' || p_q || '%'
     order by p.wagered desc limit 25) t);
end $$;

-- (permissions are set by the later updates)


-- =====================================================================
-- EmpireBlox update 12: Borrow slider for case battles
-- Run once in Supabase → SQL Editor → New query → paste → Run.
-- If Supabase asks about RLS, choose "Run without RLS". Safe to run twice.
-- Borrow X% (1–90): you pay (100−X)% of the entry and receive (100−X)% of your winnings.
-- =====================================================================
alter table public.battles add column if not exists borrow int[] not null default '{}';
update public.battles set borrow = (select array_agg(case when h then 50 else 0 end) from unnest(half) h) where cardinality(half) > 0 and cardinality(borrow) = 0;
drop function if exists public.battle_fee(bigint, boolean);

create or replace function public.battle_seats(p_mode text)
returns int language sql immutable as $$
  select case p_mode when '1v1' then 2 when 'g2' then 2 when '3way' then 3 when 'g3' then 3
                     when '4way' then 4 when '2v2' then 4 when 'g4' then 4 else 6 end
$$;
create or replace function public.battle_teams(p_mode text)
returns int language sql immutable as $$
  select case when p_mode like 'g%' then 1 when p_mode = '3way' then 3 when p_mode = '4way' then 4
              when p_mode = '2v2v2' then 3 else 2 end
$$;
create or replace function public.battle_team(p_mode text, p_seat int)   -- p_seat is 1-based, result 0-based
returns int language sql immutable as $$
  select case when p_mode like 'g%' then 0 when p_mode in ('1v1','3way','4way') then p_seat - 1
              when p_mode = '3v3' then (p_seat - 1) / 3 else (p_seat - 1) / 2 end
$$;
create or replace function public.battle_fee(p_cost bigint, p_borrow int)
returns bigint language sql immutable as $$ select ceil(p_cost * (100 - least(90, greatest(0, coalesce(p_borrow, 0)))) / 100.0)::bigint $$;

drop function if exists public.battle_create(text, text[]);
drop function if exists public.battle_create(text, text[], boolean, boolean, boolean);
create or replace function public.battle_create(p_mode text, p_cases text[], p_crazy boolean default false, p_jackpot boolean default false, p_borrow int default 0)
returns json language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_cost bigint; v_fee bigint; v_found int; v_coins bigint; v_id uuid; n int; v_b int[];
begin
  if v_uid is null then raise exception 'Sign in to play'; end if;
  if p_mode not in ('1v1','3way','4way','2v2','3v3','2v2v2','g2','g3','g4') then raise exception 'Pick a mode'; end if;
  if cardinality(p_cases) is null or cardinality(p_cases) < 1 or cardinality(p_cases) > 20 then
    raise exception 'Add between 1 and 20 cases';
  end if;
  if p_mode like 'g%' then p_crazy := false; p_jackpot := false; end if;
  if p_crazy and p_jackpot then raise exception 'Pick Crazy or Jackpot, not both'; end if;
  select coalesce(sum(c.price), 0), count(c.id) into v_cost, v_found
    from unnest(p_cases) u(cid) join public.cases c on c.id = u.cid and c.active;
  if v_found <> cardinality(p_cases) then raise exception 'Unknown case'; end if;
  p_borrow := least(90, greatest(0, coalesce(p_borrow, 0)));
  v_fee := public.battle_fee(v_cost, p_borrow);
  update public.profiles set coins = coins - v_fee, battles_played = battles_played + 1
   where id = v_uid and coins >= v_fee returning coins into v_coins;
  if not found then raise exception 'Not enough coins'; end if;
  perform public.add_wager(v_uid, 'battles', v_fee);
  perform public.tx(v_uid, 'battles', 'Battle entry (' || p_mode || case when p_borrow > 0 then ', borrowed ' || p_borrow || '%' else '' end || ')', -v_fee);
  n := public.battle_seats(p_mode);
  v_b := array_fill(0, array[n]); v_b[1] := p_borrow;
  insert into public.battles (creator, mode, case_ids, cost, seats, crazy, jackpot, borrow)
  values (v_uid, p_mode, p_cases, v_cost, array[v_uid::text] || array_fill(null::text, array[n - 1]), p_crazy, p_jackpot, v_b)
  returning id into v_id;
  return json_build_object('id', v_id, 'coins', v_coins);
end $$;

drop function if exists public.battle_join(uuid, int);
drop function if exists public.battle_join(uuid, int, boolean);
create or replace function public.battle_join(p_id uuid, p_seat int, p_borrow int default 0)
returns json language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); b public.battles; v_coins bigint; v_fee bigint;
begin
  if v_uid is null then raise exception 'Sign in to play'; end if;
  select * into b from public.battles where id = p_id for update;
  if not found or b.status <> 'open' then raise exception 'This battle already started'; end if;
  if p_seat < 0 or p_seat >= cardinality(b.seats) then raise exception 'Bad seat'; end if;
  if b.seats[p_seat + 1] is not null then raise exception 'That seat was just taken'; end if;
  if v_uid::text = any (b.seats) then raise exception 'You are already in this battle'; end if;
  p_borrow := least(90, greatest(0, coalesce(p_borrow, 0)));
  v_fee := public.battle_fee(b.cost, p_borrow);
  update public.profiles set coins = coins - v_fee, battles_played = battles_played + 1
   where id = v_uid and coins >= v_fee returning coins into v_coins;
  if not found then raise exception 'Not enough coins'; end if;
  perform public.add_wager(v_uid, 'battles', v_fee);
  perform public.tx(v_uid, 'battles', 'Battle entry (' || b.mode || case when p_borrow > 0 then ', borrowed ' || p_borrow || '%' else '' end || ')', -v_fee);
  b.seats[p_seat + 1] := v_uid::text;
  b.borrow[p_seat + 1] := p_borrow;
  update public.battles set seats = b.seats, borrow = b.borrow where id = p_id;
  if array_position(b.seats, null) is null then perform public.battle_roll(p_id); end if;
  return json_build_object('coins', v_coins);
end $$;

create or replace function public.battle_cancel(p_id uuid)
returns json language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); b public.battles; i int; v_fee bigint; v_coins bigint;
begin
  select * into b from public.battles where id = p_id for update;
  if not found or b.status <> 'open' then raise exception 'This battle already started'; end if;
  if b.creator <> v_uid then raise exception 'Only the creator can cancel'; end if;
  for i in 1 .. cardinality(b.seats) loop
    if b.seats[i] is not null and b.seats[i] not like 'bot:%' then
      v_fee := public.battle_fee(b.cost, b.borrow[i]);
      update public.profiles set coins = coins + v_fee, battles_played = greatest(0, battles_played - 1) where id = b.seats[i]::uuid;
      perform public.add_wager(b.seats[i]::uuid, 'battles', -v_fee);
      perform public.tx(b.seats[i]::uuid, 'battles', 'Battle cancelled — refund', v_fee);
    end if;
  end loop;
  update public.battles set status = 'cancelled' where id = p_id;
  select coins into v_coins from public.profiles where id = v_uid;
  return json_build_object('coins', v_coins);
end $$;

-- Rolls every round, picks the winners for the battle's mode, pays them, starts the animation clock.
create or replace function public.battle_roll(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  b public.battles; n int; nt int; r int; s int; t int; v_idx int; v_val bigint;
  v_rows jsonb := '[]'; v_row jsonb; v_tot bigint[]; v_team bigint[] := '{0,0,0,0,0,0}';
  v_best bigint; v_wt int; v_roll numeric; v_acc numeric := 0; v_jp jsonb;
  v_winners int := 0; v_pot bigint := 0; v_share bigint; v_amt bigint; v_pay jsonb := '[]'; v_is boolean;
begin
  select * into b from public.battles where id = p_id for update;
  n := cardinality(b.seats); nt := public.battle_teams(b.mode);
  v_tot := array_fill(0::bigint, array[n]);
  for s in 1 .. n loop
    v_row := '[]';
    for r in 1 .. cardinality(b.case_ids) loop
      v_idx := public.pick_item(b.case_ids[r]);
      select value into v_val from public.case_items where case_id = b.case_ids[r] and idx = v_idx;
      v_row := v_row || to_jsonb(v_idx);
      v_tot[s] := v_tot[s] + v_val;
    end loop;
    v_rows := v_rows || jsonb_build_array(v_row);
    t := public.battle_team(b.mode, s) + 1;
    v_team[t] := v_team[t] + v_tot[s];
    v_pot := v_pot + v_tot[s];
  end loop;
  if nt > 1 and b.jackpot then
    v_roll := random();
    if v_pot = 0 then v_wt := floor(v_roll * nt)::int;
    else
      for t in 1 .. nt loop
        v_acc := v_acc + v_team[t]::numeric / v_pot;
        if v_roll < v_acc then v_wt := t - 1; exit; end if;
      end loop;
      if v_wt is null then v_wt := nt - 1; end if;
    end if;
    v_jp := jsonb_build_object('roll', v_roll, 'team', v_wt);
  elsif nt > 1 then
    if b.crazy then select min(x) into v_best from unnest(v_team[1 : nt]) x;
    else select max(x) into v_best from unnest(v_team[1 : nt]) x; end if;
  end if;
  for s in 1 .. n loop
    t := public.battle_team(b.mode, s);
    if nt = 1 or (v_jp is not null and t = v_wt) or (v_jp is null and v_team[t + 1] = v_best) then v_winners := v_winners + 1; end if;
  end loop;
  v_share := floor(v_pot / v_winners);
  for s in 1 .. n loop
    t := public.battle_team(b.mode, s);
    v_is := nt = 1 or (v_jp is not null and t = v_wt) or (v_jp is null and v_team[t + 1] = v_best);
    if v_is then
      v_amt := floor(v_share * (100 - least(90, coalesce(b.borrow[s], 0))) / 100.0);
      v_pay := v_pay || to_jsonb(v_amt);
      if b.seats[s] not like 'bot:%' and v_amt > 0 then
        update public.profiles set coins = coins + v_amt, returned = returned + v_amt where id = b.seats[s]::uuid;
        perform public.tx(b.seats[s]::uuid, 'battles', case when nt = 1 then 'Group unbox share' else 'Battle won (' || b.mode || ')' end, v_amt);
      end if;
    else
      v_pay := v_pay || to_jsonb(0);
    end if;
  end loop;
  update public.battles
     set results = v_rows, payouts = v_pay, jp = v_jp, status = 'rolling', started_at = now() + interval '3 seconds'
   where id = p_id;
end $$;


-- Who may call what
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.username_available(text), public.get_profile(uuid), public.get_leaderboard() to anon, authenticated;
grant execute on function
  public.my_profile(), public.set_username(text), public.claim_faucet(), public.open_case(text),
  public.mines_start(bigint, int, int), public.mines_reveal(bigint, int), public.mines_cashout(bigint), public.mines_resume(),
  public.battle_create(text, text[], boolean, boolean, int), public.battle_join(uuid, int, int), public.battle_add_bots(uuid, int), public.battle_cancel(uuid),
  public.send_chat(text), public.tip_user(uuid, bigint), public.upgrade(bigint, bigint, boolean), public.claim_pack(int),
  public.bj_start(bigint), public.bj_act(bigint, text), public.bj_resume(),
  public.admin_stats(), public.admin_find(text), public.admin_coins(uuid, bigint), public.admin_set_admin(uuid, boolean), public.admin_delete_chat(bigint), public.admin_set_lb_hidden(uuid, boolean)
  to authenticated;


-- =====================================================================
-- EmpireBlox update 13: every gold dice prize is worth at least 2.2x the case price
-- Run once in Supabase → SQL Editor → New query → paste → Run. Safe to run twice.
-- Only the gold dice items change; everything else stays the same.
-- =====================================================================
delete from public.case_items where case_id in ('peppermint','crystal-egg','faberge','zombie-horde','haunted-patch','fiesta','overgrown','dragon-hatch','orbit','martian','blue-grin','gearhead','gilded-night','spooky-beats','atlantis','ember','topaz','tide-blade','brass-samurai','bubblegum-grin','shogun','golden-snow','frostbite','pop-art','jurassic','midnight-holly','viking-ember','nevermoor','smiley','tropical-pop','retro-wave','eclipse','shadow-beats','arctic-moss','sunbeam','neon-pop','crystal-beats','lime-grin','mistletoe','winter-crown','violet-beats','glacier','evergreen','fire-ice','black-ice','amethyst','jade','sapphire','sunset-remix','ultimate-grin');
insert into public.case_items (case_id, idx, name, value, rarity, weight, catalog_id, art, top) values
  ('peppermint', 0, 'POW! To the Moon! Egg', 400, 'rare', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('peppermint', 1, 'Specular Egg of Red, No Blue', 400, 'rare', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('peppermint', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'rare', 95000, 24826811, 'bighead:#9aa3b8', false),
  ('peppermint', 3, 'Unassuming Egg of Shyness', 400, 'rare', 95000, 24826840, 'bighead:#9aa3b8', false),
  ('peppermint', 4, 'Chrome Egg of Speeding Bullet', 500, 'rare', 95000, 24826640, 'bighead:#9aa3b8', false),
  ('peppermint', 5, 'Blue Swashbuckler', 2200, 'legendary', 15957, 25535420, 'bighead:#9aa3b8', true),
  ('peppermint', 6, 'Bouncing Egg of Boing Boing', 2200, 'legendary', 12766, 1532384, 'bighead:#9aa3b8', true),
  ('peppermint', 7, 'Blue Winter Cap', 3500, 'legendary', 10638, 1309918, 'bighead:#9aa3b8', true),
  ('peppermint', 8, 'Sci-Fi Santa', 4500, 'legendary', 6383, 18729820, 'bighead:#9aa3b8', true),
  ('peppermint', 9, '2010 Party Cap', 7100, 'legendary', 3191, 20044751, 'bighead:#9aa3b8', true),
  ('peppermint', 10, 'Bucket', 18000, 'legendary', 1064, 1081239, 'bighead:#9aa3b8', true),
  ('crystal-egg', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('crystal-egg', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 270000, 24826800, 'bighead:#9aa3b8', false),
  ('crystal-egg', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 90000, 24826811, 'bighead:#9aa3b8', false),
  ('crystal-egg', 3, 'Unassuming Egg of Shyness', 400, 'uncommon', 90000, 24826840, 'bighead:#9aa3b8', false),
  ('crystal-egg', 4, 'Chrome Egg of Speeding Bullet', 500, 'rare', 90000, 24826640, 'bighead:#9aa3b8', false),
  ('crystal-egg', 5, 'American Baseball Cap', 2500, 'legendary', 31915, 29715020, 'bighead:#9aa3b8', true),
  ('crystal-egg', 6, 'Pumpkin Pi', 2500, 'legendary', 25532, 16986805, 'bighead:#9aa3b8', true),
  ('crystal-egg', 7, 'Red Baseball Cap', 2500, 'legendary', 21277, 1028606, 'bighead:#9aa3b8', true),
  ('crystal-egg', 8, 'Puzzling Egg of Enigma', 2600, 'legendary', 12766, 1532386, 'bighead:#9aa3b8', true),
  ('crystal-egg', 9, 'Green Fabergé Egg', 3300, 'legendary', 6383, 24832637, 'bighead:#9aa3b8', true),
  ('crystal-egg', 10, 'Invisible Egg of Shadow', 4900, 'legendary', 2128, 1532389, 'bighead:#9aa3b8', true),
  ('faberge', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('faberge', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('faberge', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 99000, 24826811, 'bighead:#9aa3b8', false),
  ('faberge', 3, 'Chrome Egg of Speeding Bullet', 500, 'uncommon', 99000, 24826640, 'bighead:#9aa3b8', false),
  ('faberge', 4, 'Guardia in Exile', 800, 'rare', 99000, 18174901, 'bighead:#9aa3b8', false),
  ('faberge', 5, 'Fried Egg Eye Patch', 3100, 'legendary', 3571, 63647492, 'bighead:#9aa3b8', true),
  ('faberge', 6, 'Invisible Egg of Shadow', 4900, 'legendary', 2857, 1532389, 'bighead:#9aa3b8', true),
  ('faberge', 7, 'Black Iron Warhelm of Pwnage', 10200, 'legendary', 1786, 10351018, 'bighead:#9aa3b8', true),
  ('faberge', 8, 'Mick McCann', 21100, 'legendary', 1071, 23264604, 'bighead:#9aa3b8', true),
  ('faberge', 9, 'Viridian Hood', 41200, 'legendary', 536, 16954107, 'bighead:#9aa3b8', true),
  ('faberge', 10, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 179, 47597760, 'bighead:#9aa3b8', true),
  ('zombie-horde', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('zombie-horde', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('zombie-horde', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 99000, 24826811, 'bighead:#9aa3b8', false),
  ('zombie-horde', 3, 'Rusty Egg of Magnetism', 600, 'uncommon', 99000, 24826787, 'bighead:#9aa3b8', false),
  ('zombie-horde', 4, 'Racing Helmet', 900, 'rare', 99000, 6379764, 'bighead:#9aa3b8', false),
  ('zombie-horde', 5, 'Halloween Harbinger', 3300, 'legendary', 3571, 15727771, 'bighead:#9aa3b8', true),
  ('zombie-horde', 6, 'Halloween Santa Hat', 7100, 'legendary', 2857, 1173851, 'bighead:#9aa3b8', true),
  ('zombie-horde', 7, 'Camoface', 12000, 'legendary', 1786, 24441888, 'bighead:#9aa3b8', true),
  ('zombie-horde', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 1071, 20980122, 'bighead:#9aa3b8', true),
  ('zombie-horde', 9, 'The Crown of Nachos', 44100, 'legendary', 536, 22547617, 'bighead:#9aa3b8', true),
  ('zombie-horde', 10, 'Lava Reactor', 101800, 'legendary', 179, 32858948, 'bighead:#9aa3b8', true),
  ('haunted-patch', 0, 'POW! To the Moon! Egg', 400, 'uncommon', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('haunted-patch', 1, 'Specular Egg of Red, No Blue', 400, 'uncommon', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('haunted-patch', 2, 'Agonizingly Ugly Egg of Screensplat', 400, 'uncommon', 95000, 24826811, 'bighead:#9aa3b8', false),
  ('haunted-patch', 3, 'Guardia in Exile', 800, 'uncommon', 95000, 18174901, 'bighead:#9aa3b8', false),
  ('haunted-patch', 4, 'Stationary Egg of Boring', 1200, 'rare', 95000, 1530795, 'bighead:#9aa3b8', false),
  ('haunted-patch', 5, 'Blue Winter Cap', 3500, 'legendary', 15957, 1309918, 'bighead:#9aa3b8', true),
  ('haunted-patch', 6, 'Sci-Fi Santa', 4500, 'legendary', 12766, 18729820, 'bighead:#9aa3b8', true),
  ('haunted-patch', 7, 'Halloween Santa Hat', 7100, 'legendary', 10638, 1173851, 'bighead:#9aa3b8', true),
  ('haunted-patch', 8, 'Camoface', 12000, 'legendary', 6383, 24441888, 'bighead:#9aa3b8', true),
  ('haunted-patch', 9, 'Failed Proofs of the Riemann Hypothesis', 23100, 'legendary', 3191, 1285300, 'bighead:#9aa3b8', true),
  ('haunted-patch', 10, 'The Crown of Nachos', 44100, 'legendary', 1064, 22547617, 'bighead:#9aa3b8', true),
  ('fiesta', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('fiesta', 1, 'Specular Egg of Red, No Blue', 400, 'common', 270000, 24826800, 'bighead:#9aa3b8', false),
  ('fiesta', 2, 'Rusty Egg of Magnetism', 600, 'uncommon', 90000, 24826787, 'bighead:#9aa3b8', false),
  ('fiesta', 3, 'Arctic Hood', 1000, 'uncommon', 90000, 18171366, 'bighead:#9aa3b8', false),
  ('fiesta', 4, 'Starry Egg of the Wild Ride', 1500, 'rare', 90000, 31151864, 'bighead:#9aa3b8', false),
  ('fiesta', 5, 'Gentlemen of Stratus', 4400, 'legendary', 31915, 34111862, 'bighead:#9aa3b8', true),
  ('fiesta', 6, 'Bloxxadore Domino Mask', 5200, 'legendary', 25532, 14492461, 'bighead:#9aa3b8', true),
  ('fiesta', 7, 'Black Paintball Mask', 6800, 'legendary', 21277, 9254521, 'bighead:#9aa3b8', true),
  ('fiesta', 8, '2010 Party Cap', 7100, 'legendary', 12766, 20044751, 'bighead:#9aa3b8', true),
  ('fiesta', 9, 'Black Iron Warhelm of Pwnage', 10200, 'legendary', 6383, 10351018, 'bighead:#9aa3b8', true),
  ('fiesta', 10, 'Bucket', 18000, 'legendary', 2128, 1081239, 'bighead:#9aa3b8', true),
  ('overgrown', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('overgrown', 1, 'Specular Egg of Red, No Blue', 400, 'common', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('overgrown', 2, 'Chaos Canyon Sugar Egg', 700, 'uncommon', 95000, 76692143, 'bighead:#9aa3b8', false),
  ('overgrown', 3, 'Turbo Builders Club Hard Hat', 1300, 'uncommon', 95000, 11844853, 'bighead:#9aa3b8', false),
  ('overgrown', 4, 'Blinking Egg of Relocation', 1800, 'rare', 95000, 1532381, 'bighead:#9aa3b8', false),
  ('overgrown', 5, 'Treehugger Visor', 5700, 'legendary', 15957, 9910514, 'bighead:#9aa3b8', true),
  ('overgrown', 6, 'Mandrake Root', 10400, 'legendary', 12766, 1191812, 'bighead:#9aa3b8', true),
  ('overgrown', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 10638, 14817131, 'bighead:#9aa3b8', true),
  ('overgrown', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('overgrown', 9, 'Viridian Hood', 41200, 'legendary', 3191, 16954107, 'bighead:#9aa3b8', true),
  ('overgrown', 10, 'Lava Reactor', 101800, 'legendary', 1064, 32858948, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 1, 'Specular Egg of Red, No Blue', 400, 'common', 285000, 24826800, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 2, 'Guardia in Exile', 800, 'uncommon', 95000, 18174901, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 3, 'Starry Egg of the Wild Ride', 1500, 'uncommon', 95000, 31151864, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 4, '2009 Graduation Cap', 2300, 'rare', 95000, 11721340, 'bighead:#9aa3b8', false),
  ('dragon-hatch', 5, 'One Star General''s Beret', 6700, 'legendary', 15957, 28039679, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 6, 'Robosquid', 9200, 'legendary', 12766, 37238566, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 10638, 14817131, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 8, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 9, 'The Crown of Nachos', 44100, 'legendary', 3191, 22547617, 'bighead:#9aa3b8', true),
  ('dragon-hatch', 10, 'Playful Vampire', 90000, 'legendary', 1064, 2409285794, 'bighead:#9aa3b8', true),
  ('orbit', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('orbit', 1, 'Specular Egg of Red, No Blue', 400, 'common', 297000, 24826800, 'bighead:#9aa3b8', false),
  ('orbit', 2, 'Arctic Hood', 1000, 'uncommon', 99000, 18171366, 'bighead:#9aa3b8', false),
  ('orbit', 3, 'Christmas Baseball Cap', 2000, 'uncommon', 99000, 1272713, 'bighead:#9aa3b8', false),
  ('orbit', 4, 'The Moon', 2900, 'rare', 99000, 7319168, 'bighead:#9aa3b8', false),
  ('orbit', 5, 'Bag O'' Noobs', 11800, 'legendary', 3571, 32355759, 'bighead:#9aa3b8', true),
  ('orbit', 6, 'Seeing Stars', 18700, 'legendary', 2857, 27599954, 'bighead:#9aa3b8', true),
  ('orbit', 7, 'Viridian Hood', 41200, 'legendary', 1786, 16954107, 'bighead:#9aa3b8', true),
  ('orbit', 8, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 1071, 47597760, 'bighead:#9aa3b8', true),
  ('orbit', 9, 'Super Super Happy Face', 162000, 'legendary', 536, 494291269, 'bighead:#9aa3b8', true),
  ('orbit', 10, 'Monstars Visor', 270000, 'legendary', 179, 1086815, 'bighead:#9aa3b8', true),
  ('martian', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('martian', 1, 'Chrome Egg of Speeding Bullet', 500, 'common', 270000, 24826640, 'bighead:#9aa3b8', false),
  ('martian', 2, 'Pink Penguin', 1400, 'uncommon', 90000, 16985920, 'bighead:#9aa3b8', false),
  ('martian', 3, 'Red Baseball Cap', 2500, 'uncommon', 90000, 1028606, 'bighead:#9aa3b8', false),
  ('martian', 4, 'Ultimate Slide Skateboard', 3700, 'rare', 90000, 52180878, 'bighead:#9aa3b8', false),
  ('martian', 5, 'Hollywood Sign', 11300, 'legendary', 31915, 17614445, 'bighead:#9aa3b8', true),
  ('martian', 6, 'Bag O'' Noobs', 11800, 'legendary', 25532, 32355759, 'bighead:#9aa3b8', true),
  ('martian', 7, 'Outlawed Vampumatiger Hybrid', 13800, 'legendary', 21277, 14817131, 'bighead:#9aa3b8', true),
  ('martian', 8, 'Bucket', 18000, 'legendary', 12766, 1081239, 'bighead:#9aa3b8', true),
  ('martian', 9, 'Burning Otaku, the Firesouled', 24600, 'legendary', 6383, 20980122, 'bighead:#9aa3b8', true),
  ('martian', 10, 'Viridian Hood', 41200, 'legendary', 2128, 16954107, 'bighead:#9aa3b8', true),
  ('blue-grin', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('blue-grin', 1, 'Chrome Egg of Speeding Bullet', 500, 'common', 285000, 24826640, 'bighead:#9aa3b8', false),
  ('blue-grin', 2, 'Starry Egg of the Wild Ride', 1500, 'uncommon', 95000, 31151864, 'bighead:#9aa3b8', false),
  ('blue-grin', 3, 'Puzzling Egg of Enigma', 2600, 'uncommon', 95000, 1532386, 'bighead:#9aa3b8', false),
  ('blue-grin', 4, 'Headrow', 3900, 'rare', 95000, 1082935, 'bighead:#9aa3b8', false),
  ('blue-grin', 5, 'Seeing Stars', 18700, 'legendary', 15957, 27599954, 'bighead:#9aa3b8', true),
  ('blue-grin', 6, 'Mick McCann', 21100, 'legendary', 12766, 23264604, 'bighead:#9aa3b8', true),
  ('blue-grin', 7, 'Hotdog Head', 35800, 'legendary', 10638, 15318156, 'bighead:#9aa3b8', true),
  ('blue-grin', 8, 'The Bluesteel Bathelm', 63000, 'legendary', 6383, 1172161, 'bighead:#9aa3b8', true),
  ('blue-grin', 9, 'Lava Reactor', 101800, 'legendary', 3191, 32858948, 'bighead:#9aa3b8', true),
  ('blue-grin', 10, 'The Ice Skull of Nevermoor', 180000, 'legendary', 1064, 6552254, 'bighead:#9aa3b8', true),
  ('gearhead', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('gearhead', 1, 'Chaos Canyon Sugar Egg', 700, 'common', 285000, 76692143, 'bighead:#9aa3b8', false),
  ('gearhead', 2, 'Blinking Egg of Relocation', 1800, 'uncommon', 95000, 1532381, 'bighead:#9aa3b8', false),
  ('gearhead', 3, 'Halloween Harbinger', 3300, 'uncommon', 95000, 15727771, 'bighead:#9aa3b8', false),
  ('gearhead', 4, 'Invisible Egg of Shadow', 4900, 'rare', 95000, 1532389, 'bighead:#9aa3b8', false),
  ('gearhead', 5, 'Bucket', 18000, 'legendary', 15957, 1081239, 'bighead:#9aa3b8', true),
  ('gearhead', 6, 'Burning Otaku, the Firesouled', 24600, 'legendary', 12766, 20980122, 'bighead:#9aa3b8', true),
  ('gearhead', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('gearhead', 8, 'Wildcard', 65400, 'legendary', 6383, 38322996, 'bighead:#9aa3b8', true),
  ('gearhead', 9, 'Even Eviler Jester', 106700, 'legendary', 3191, 40893465, 'bighead:#9aa3b8', true),
  ('gearhead', 10, 'Monstars Visor', 270000, 'legendary', 1064, 1086815, 'bighead:#9aa3b8', true),
  ('gilded-night', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('gilded-night', 1, 'Chaos Canyon Sugar Egg', 700, 'common', 297000, 76692143, 'bighead:#9aa3b8', false),
  ('gilded-night', 2, 'Blinking Egg of Relocation', 1800, 'uncommon', 99000, 1532381, 'bighead:#9aa3b8', false),
  ('gilded-night', 3, 'Halloween Harbinger', 3300, 'uncommon', 99000, 15727771, 'bighead:#9aa3b8', false),
  ('gilded-night', 4, 'The Viper Band', 5000, 'rare', 99000, 18482403, 'bighead:#9aa3b8', false),
  ('gilded-night', 5, 'Seeing Stars', 18700, 'legendary', 3571, 27599954, 'bighead:#9aa3b8', true),
  ('gilded-night', 6, 'Golden Headphones', 52700, 'legendary', 2857, 29051524, 'bighead:#9aa3b8', true),
  ('gilded-night', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 1786, 47597760, 'bighead:#9aa3b8', true),
  ('gilded-night', 8, 'Super Super Happy Face', 162000, 'legendary', 1071, 494291269, 'bighead:#9aa3b8', true),
  ('gilded-night', 9, 'Monstars Visor', 270000, 'legendary', 536, 1086815, 'bighead:#9aa3b8', true),
  ('gilded-night', 10, 'Valkyrie Helm', 540000, 'legendary', 179, 1365767, 'bighead:#9aa3b8', true),
  ('spooky-beats', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('spooky-beats', 1, 'Guardia in Exile', 800, 'common', 285000, 18174901, 'bighead:#9aa3b8', false),
  ('spooky-beats', 2, 'Bouncing Egg of Boing Boing', 2200, 'uncommon', 95000, 1532384, 'bighead:#9aa3b8', false),
  ('spooky-beats', 3, 'The Earth', 4100, 'uncommon', 95000, 10072631, 'bighead:#9aa3b8', false),
  ('spooky-beats', 4, 'Gold Buckle Capotain', 6200, 'rare', 95000, 5671970, 'bighead:#9aa3b8', false),
  ('spooky-beats', 5, 'Bucket', 18000, 'legendary', 15957, 1081239, 'bighead:#9aa3b8', true),
  ('spooky-beats', 6, 'Burning Otaku, the Firesouled', 24600, 'legendary', 12766, 20980122, 'bighead:#9aa3b8', true),
  ('spooky-beats', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('spooky-beats', 8, 'The Bluesteel Bathelm', 63000, 'legendary', 6383, 1172161, 'bighead:#9aa3b8', true),
  ('spooky-beats', 9, 'Even Eviler Jester', 106700, 'legendary', 3191, 40893465, 'bighead:#9aa3b8', true),
  ('spooky-beats', 10, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1064, 1073690, 'bighead:#9aa3b8', true),
  ('atlantis', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('atlantis', 1, 'Racing Helmet', 900, 'common', 270000, 6379764, 'bighead:#9aa3b8', false),
  ('atlantis', 2, 'Red Baseball Cap', 2500, 'uncommon', 90000, 1028606, 'bighead:#9aa3b8', false),
  ('atlantis', 3, 'Black Lightning', 4600, 'uncommon', 90000, 29532225, 'bighead:#9aa3b8', false),
  ('atlantis', 4, 'Black Paintball Mask', 6800, 'rare', 90000, 9254521, 'bighead:#9aa3b8', false),
  ('atlantis', 5, 'Mick McCann', 21100, 'legendary', 25532, 23264604, 'bighead:#9aa3b8', true),
  ('atlantis', 6, 'Failed Proofs of the Riemann Hypothesis', 23100, 'legendary', 31915, 1285300, 'bighead:#9aa3b8', true),
  ('atlantis', 7, 'Burning Otaku, the Firesouled', 24600, 'legendary', 21277, 20980122, 'bighead:#9aa3b8', true),
  ('atlantis', 8, 'Hotdog Head', 35800, 'legendary', 12766, 15318156, 'bighead:#9aa3b8', true),
  ('atlantis', 9, 'The Crown of Nachos', 44100, 'legendary', 6383, 22547617, 'bighead:#9aa3b8', true),
  ('atlantis', 10, 'The Bluesteel Bathelm', 63000, 'legendary', 2128, 1172161, 'bighead:#9aa3b8', true),
  ('ember', 0, 'POW! To the Moon! Egg', 400, 'common', 360000, 24826737, 'bighead:#9aa3b8', false),
  ('ember', 1, 'Arctic Hood', 1000, 'common', 270000, 18171366, 'bighead:#9aa3b8', false),
  ('ember', 2, 'Target Hat', 2700, 'uncommon', 90000, 1051578, 'bighead:#9aa3b8', false),
  ('ember', 3, 'Invisible Egg of Shadow', 4900, 'uncommon', 90000, 1532389, 'bighead:#9aa3b8', false),
  ('ember', 4, 'White Witch Hat', 7300, 'rare', 90000, 5207053, 'bighead:#9aa3b8', false),
  ('ember', 5, 'Burning Otaku, the Firesouled', 24600, 'legendary', 31915, 20980122, 'bighead:#9aa3b8', true),
  ('ember', 6, 'Hotdog Head', 35800, 'legendary', 25532, 15318156, 'bighead:#9aa3b8', true),
  ('ember', 7, 'Viridian Hood', 41200, 'legendary', 21277, 16954107, 'bighead:#9aa3b8', true),
  ('ember', 8, 'Imagine', 41400, 'legendary', 12766, 30394316, 'bighead:#9aa3b8', true),
  ('ember', 9, 'Golden Headphones', 52700, 'legendary', 6383, 29051524, 'bighead:#9aa3b8', true),
  ('ember', 10, 'Lava Reactor', 101800, 'legendary', 2128, 32858948, 'bighead:#9aa3b8', true),
  ('topaz', 0, 'POW! To the Moon! Egg', 400, 'common', 380000, 24826737, 'bighead:#9aa3b8', false),
  ('topaz', 1, 'Arctic Hood', 1000, 'common', 285000, 18171366, 'bighead:#9aa3b8', false),
  ('topaz', 2, 'White Ninja Headband of the Unimpeachable Soul', 2800, 'uncommon', 95000, 11297746, 'bighead:#9aa3b8', false),
  ('topaz', 3, 'The Viper Band', 5000, 'uncommon', 95000, 18482403, 'bighead:#9aa3b8', false),
  ('topaz', 4, 'White Witch Hat', 7300, 'rare', 95000, 5207053, 'bighead:#9aa3b8', false),
  ('topaz', 5, 'Failed Proofs of the Riemann Hypothesis', 23100, 'legendary', 15957, 1285300, 'bighead:#9aa3b8', true),
  ('topaz', 6, 'The Crown of Nachos', 44100, 'legendary', 12766, 22547617, 'bighead:#9aa3b8', true),
  ('topaz', 7, 'Golden Headphones', 52700, 'legendary', 10638, 29051524, 'bighead:#9aa3b8', true),
  ('topaz', 8, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 6383, 47597760, 'bighead:#9aa3b8', true),
  ('topaz', 9, 'Super Super Happy Face', 162000, 'legendary', 3191, 494291269, 'bighead:#9aa3b8', true),
  ('topaz', 10, 'Monstars Visor', 270000, 'legendary', 1064, 1086815, 'bighead:#9aa3b8', true),
  ('tide-blade', 0, 'POW! To the Moon! Egg', 400, 'common', 396000, 24826737, 'bighead:#9aa3b8', false),
  ('tide-blade', 1, 'Stationary Egg of Boring', 1200, 'common', 297000, 1530795, 'bighead:#9aa3b8', false),
  ('tide-blade', 2, 'Halloween Harbinger', 3300, 'uncommon', 99000, 15727771, 'bighead:#9aa3b8', false),
  ('tide-blade', 3, 'Gold Buckle Capotain', 6200, 'uncommon', 99000, 5671970, 'bighead:#9aa3b8', false),
  ('tide-blade', 4, 'Robosquid', 9200, 'rare', 99000, 37238566, 'bighead:#9aa3b8', false),
  ('tide-blade', 5, 'Hotdog Head', 35800, 'legendary', 3571, 15318156, 'bighead:#9aa3b8', true),
  ('tide-blade', 6, 'Sword of the Winter Winds', 57600, 'legendary', 2857, 42847923, 'bighead:#9aa3b8', true),
  ('tide-blade', 7, 'Even Eviler Jester', 106700, 'legendary', 1786, 40893465, 'bighead:#9aa3b8', true),
  ('tide-blade', 8, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1071, 1073690, 'bighead:#9aa3b8', true),
  ('tide-blade', 9, 'Valkyrie Helm', 540000, 'legendary', 536, 1365767, 'bighead:#9aa3b8', true),
  ('tide-blade', 10, 'Spec Beta Biograft Energy Sword', 1260000, 'legendary', 179, 14876573, 'bighead:#9aa3b8', true),
  ('brass-samurai', 0, 'Chrome Egg of Speeding Bullet', 500, 'common', 380000, 24826640, 'bighead:#9aa3b8', false),
  ('brass-samurai', 1, 'Starry Egg of the Wild Ride', 1500, 'common', 285000, 31151864, 'bighead:#9aa3b8', false),
  ('brass-samurai', 2, 'Golden Egg of Kings', 4200, 'uncommon', 95000, 1532387, 'bighead:#9aa3b8', false),
  ('brass-samurai', 3, 'White Witch Hat', 7300, 'uncommon', 95000, 5207053, 'bighead:#9aa3b8', false),
  ('brass-samurai', 4, 'Hollywood Sign', 11300, 'rare', 95000, 17614445, 'bighead:#9aa3b8', false),
  ('brass-samurai', 5, 'Hotdog Head', 35800, 'legendary', 15957, 15318156, 'bighead:#9aa3b8', true),
  ('brass-samurai', 6, 'Golden Headphones', 52700, 'legendary', 12766, 29051524, 'bighead:#9aa3b8', true),
  ('brass-samurai', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 10638, 47597760, 'bighead:#9aa3b8', true),
  ('brass-samurai', 8, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('brass-samurai', 9, 'JJ5x5''s White Top Hat', 243000, 'legendary', 3191, 1073690, 'bighead:#9aa3b8', true),
  ('brass-samurai', 10, 'Valkyrie Helm', 540000, 'legendary', 1064, 1365767, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 0, 'Chrome Egg of Speeding Bullet', 500, 'common', 380000, 24826640, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 1, 'Outrageous Builders Club Hard Hat', 1600, 'common', 285000, 17408283, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 2, 'Sci-Fi Santa', 4500, 'uncommon', 95000, 18729820, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 3, 'Das Deutschlandlied', 8400, 'uncommon', 95000, 26018282, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 4, 'Camoface', 12000, 'rare', 95000, 24441888, 'bighead:#9aa3b8', false),
  ('bubblegum-grin', 5, 'Bubble Trouble', 57600, 'legendary', 15957, 19264845, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 6, 'Sundae Best', 74600, 'legendary', 12766, 35685322, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 7, 'Lava Reactor', 101800, 'legendary', 10638, 32858948, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 8, 'Super Super Happy Face', 162000, 'legendary', 6383, 494291269, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 9, 'Monstars Visor', 270000, 'legendary', 3191, 1086815, 'bighead:#9aa3b8', true),
  ('bubblegum-grin', 10, 'Wanwood Antlers', 630000, 'legendary', 1064, 1272714, 'bighead:#9aa3b8', true),
  ('shogun', 0, 'Rusty Egg of Magnetism', 600, 'common', 380000, 24826787, 'bighead:#9aa3b8', false),
  ('shogun', 1, 'Christmas Baseball Cap', 2000, 'common', 285000, 1272713, 'bighead:#9aa3b8', false),
  ('shogun', 2, 'Ladies Who Lunch', 5600, 'uncommon', 95000, 35167841, 'bighead:#9aa3b8', false),
  ('shogun', 3, 'Black Iron Warhelm of Pwnage', 10200, 'uncommon', 95000, 10351018, 'bighead:#9aa3b8', false),
  ('shogun', 4, 'Outlawed Vampumatiger Hybrid', 13800, 'rare', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('shogun', 5, 'The Bluesteel Bathelm', 63000, 'legendary', 15957, 1172161, 'bighead:#9aa3b8', true),
  ('shogun', 6, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 12766, 47597760, 'bighead:#9aa3b8', true),
  ('shogun', 7, 'Even Eviler Jester', 106700, 'legendary', 10638, 40893465, 'bighead:#9aa3b8', true),
  ('shogun', 8, 'Picklace', 192600, 'legendary', 6383, 33615415, 'bighead:#9aa3b8', true),
  ('shogun', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('shogun', 10, 'Helm of the Sacred Earth', 900000, 'legendary', 1064, 22157971, 'bighead:#9aa3b8', true),
  ('golden-snow', 0, 'Rusty Egg of Magnetism', 600, 'common', 380000, 24826787, 'bighead:#9aa3b8', false),
  ('golden-snow', 1, 'Kind Egg of Sharing', 2100, 'common', 285000, 1532395, 'bighead:#9aa3b8', false),
  ('golden-snow', 2, 'Santa Hat', 5800, 'uncommon', 95000, 1098277, 'bighead:#9aa3b8', false),
  ('golden-snow', 3, 'Mandrake Root', 10400, 'uncommon', 95000, 1191812, 'bighead:#9aa3b8', false),
  ('golden-snow', 4, 'Outlawed Vampumatiger Hybrid', 13800, 'rare', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('golden-snow', 5, 'Golden Headphones', 52700, 'legendary', 15957, 29051524, 'bighead:#9aa3b8', true),
  ('golden-snow', 6, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 12766, 47597760, 'bighead:#9aa3b8', true),
  ('golden-snow', 7, 'Even Eviler Jester', 106700, 'legendary', 10638, 40893465, 'bighead:#9aa3b8', true),
  ('golden-snow', 8, 'Korblox King', 168200, 'legendary', 6383, 52492417, 'bighead:#9aa3b8', true),
  ('golden-snow', 9, 'Monstars Visor', 270000, 'legendary', 3191, 1086815, 'bighead:#9aa3b8', true),
  ('golden-snow', 10, 'Wanwood Antlers', 630000, 'legendary', 1064, 1272714, 'bighead:#9aa3b8', true),
  ('frostbite', 0, 'Chaos Canyon Sugar Egg', 700, 'common', 396000, 76692143, 'bighead:#9aa3b8', false),
  ('frostbite', 1, 'Bouncing Egg of Boing Boing', 2200, 'common', 297000, 1532384, 'bighead:#9aa3b8', false),
  ('frostbite', 2, 'Gold Buckle Capotain', 6200, 'uncommon', 99000, 5671970, 'bighead:#9aa3b8', false),
  ('frostbite', 3, 'Ochre Ogre', 10900, 'uncommon', 99000, 16723499, 'bighead:#9aa3b8', false),
  ('frostbite', 4, 'Bucket', 18000, 'rare', 99000, 1081239, 'bighead:#9aa3b8', false),
  ('frostbite', 5, 'The Bluesteel Bathelm', 63000, 'legendary', 3571, 1172161, 'bighead:#9aa3b8', true),
  ('frostbite', 6, 'The Ice Skull of Nevermoor', 180000, 'legendary', 2857, 6552254, 'bighead:#9aa3b8', true),
  ('frostbite', 7, 'JJ5x5''s White Top Hat', 243000, 'legendary', 1786, 1073690, 'bighead:#9aa3b8', true),
  ('frostbite', 8, 'Valkyrie Helm', 540000, 'legendary', 1071, 1365767, 'bighead:#9aa3b8', true),
  ('frostbite', 9, 'Green Ice Crown', 954000, 'legendary', 536, 193696233, 'bighead:#9aa3b8', true),
  ('frostbite', 10, 'Hooded Frostlord', 1800000, 'legendary', 179, 136802867, 'bighead:#9aa3b8', true),
  ('pop-art', 0, 'Chaos Canyon Sugar Egg', 700, 'common', 360000, 76692143, 'bighead:#9aa3b8', false),
  ('pop-art', 1, '2009 Graduation Cap', 2300, 'common', 270000, 11721340, 'bighead:#9aa3b8', false),
  ('pop-art', 2, 'For the Ages: Abraham Lincoln', 6400, 'uncommon', 90000, 46363235, 'bighead:#9aa3b8', false),
  ('pop-art', 3, 'Hollywood Sign', 11300, 'uncommon', 90000, 17614445, 'bighead:#9aa3b8', false),
  ('pop-art', 4, 'Bucket', 18000, 'rare', 90000, 1081239, 'bighead:#9aa3b8', false),
  ('pop-art', 5, 'Wildcard', 65400, 'legendary', 31915, 38322996, 'bighead:#9aa3b8', true),
  ('pop-art', 6, 'Sundae Best', 74600, 'legendary', 25532, 35685322, 'bighead:#9aa3b8', true),
  ('pop-art', 7, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 21277, 47597760, 'bighead:#9aa3b8', true),
  ('pop-art', 8, 'Playful Vampire', 90000, 'legendary', 12766, 2409285794, 'bighead:#9aa3b8', true),
  ('pop-art', 9, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('pop-art', 10, 'Super Super Happy Face', 162000, 'legendary', 2128, 494291269, 'bighead:#9aa3b8', true),
  ('jurassic', 0, 'Guardia in Exile', 800, 'common', 360000, 18174901, 'bighead:#9aa3b8', false),
  ('jurassic', 1, 'Red Baseball Cap', 2500, 'common', 270000, 1028606, 'bighead:#9aa3b8', false),
  ('jurassic', 2, '2010 Party Cap', 7100, 'uncommon', 90000, 20044751, 'bighead:#9aa3b8', false),
  ('jurassic', 3, 'Kid Robot', 12500, 'uncommon', 90000, 29283299, 'bighead:#9aa3b8', false),
  ('jurassic', 4, 'Seeing Stars', 18700, 'rare', 90000, 27599954, 'bighead:#9aa3b8', false),
  ('jurassic', 5, 'Pin Head', 56100, 'legendary', 25532, 25880554, 'bighead:#9aa3b8', true),
  ('jurassic', 6, 'Bubble Trouble', 57600, 'legendary', 31915, 19264845, 'bighead:#9aa3b8', true),
  ('jurassic', 7, 'Sundae Best', 74600, 'legendary', 21277, 35685322, 'bighead:#9aa3b8', true),
  ('jurassic', 8, 'Playful Vampire', 90000, 'legendary', 12766, 2409285794, 'bighead:#9aa3b8', true),
  ('jurassic', 9, 'Even Eviler Jester', 106700, 'legendary', 6383, 40893465, 'bighead:#9aa3b8', true),
  ('jurassic', 10, 'Picklace', 192600, 'legendary', 2128, 33615415, 'bighead:#9aa3b8', true),
  ('midnight-holly', 0, 'Racing Helmet', 900, 'common', 380000, 6379764, 'bighead:#9aa3b8', false),
  ('midnight-holly', 1, 'The Moon', 2900, 'common', 285000, 7319168, 'bighead:#9aa3b8', false),
  ('midnight-holly', 2, 'Das Deutschlandlied', 8400, 'uncommon', 95000, 26018282, 'bighead:#9aa3b8', false),
  ('midnight-holly', 3, 'Outlawed Vampumatiger Hybrid', 13800, 'uncommon', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('midnight-holly', 4, 'Mick McCann', 21100, 'rare', 95000, 23264604, 'bighead:#9aa3b8', false),
  ('midnight-holly', 5, 'Even Eviler Jester', 106700, 'legendary', 15957, 40893465, 'bighead:#9aa3b8', true),
  ('midnight-holly', 6, 'Super Super Happy Face', 162000, 'legendary', 12766, 494291269, 'bighead:#9aa3b8', true),
  ('midnight-holly', 7, 'Korblox King', 168200, 'legendary', 10638, 52492417, 'bighead:#9aa3b8', true),
  ('midnight-holly', 8, 'Monstars Visor', 270000, 'legendary', 6383, 1086815, 'bighead:#9aa3b8', true),
  ('midnight-holly', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('midnight-holly', 10, 'Pink Queen of the Night', 1026000, 'legendary', 1064, 553971558, 'bighead:#9aa3b8', true),
  ('viking-ember', 0, 'Arctic Hood', 1000, 'common', 380000, 18171366, 'bighead:#9aa3b8', false),
  ('viking-ember', 1, 'Blue Winter Cap', 3500, 'common', 285000, 1309918, 'bighead:#9aa3b8', false),
  ('viking-ember', 2, 'Cyborg Soldier', 9400, 'uncommon', 95000, 27052155, 'bighead:#9aa3b8', false),
  ('viking-ember', 3, 'Bucket', 18000, 'uncommon', 95000, 1081239, 'bighead:#9aa3b8', false),
  ('viking-ember', 4, 'Burning Otaku, the Firesouled', 24600, 'rare', 95000, 20980122, 'bighead:#9aa3b8', false),
  ('viking-ember', 5, 'Golden Chakram of the Sky Palace', 77000, 'legendary', 15957, 47597760, 'bighead:#9aa3b8', true),
  ('viking-ember', 6, 'Lava Reactor', 101800, 'legendary', 12766, 32858948, 'bighead:#9aa3b8', true),
  ('viking-ember', 7, 'Korblox King', 168200, 'legendary', 10638, 52492417, 'bighead:#9aa3b8', true),
  ('viking-ember', 8, 'Monstars Visor', 270000, 'legendary', 6383, 1086815, 'bighead:#9aa3b8', true),
  ('viking-ember', 9, 'Valkyrie Helm', 540000, 'legendary', 3191, 1365767, 'bighead:#9aa3b8', true),
  ('viking-ember', 10, 'Helm of the Sacred Earth', 900000, 'legendary', 1064, 22157971, 'bighead:#9aa3b8', true),
  ('nevermoor', 0, 'Starry Egg of the Wild Ride', 1500, 'common', 380000, 31151864, 'bighead:#9aa3b8', false),
  ('nevermoor', 1, 'The Viper Band', 5000, 'common', 285000, 18482403, 'bighead:#9aa3b8', false),
  ('nevermoor', 2, 'Outlawed Vampumatiger Hybrid', 13800, 'uncommon', 95000, 14817131, 'bighead:#9aa3b8', false),
  ('nevermoor', 3, 'Burning Otaku, the Firesouled', 24600, 'uncommon', 95000, 20980122, 'bighead:#9aa3b8', false),
  ('nevermoor', 4, 'Hotdog Head', 35800, 'rare', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('nevermoor', 5, 'Super Super Happy Face', 162000, 'legendary', 15957, 494291269, 'bighead:#9aa3b8', true),
  ('nevermoor', 6, 'The Ice Skull of Nevermoor', 180000, 'legendary', 12766, 6552254, 'bighead:#9aa3b8', true),
  ('nevermoor', 7, 'JJ5x5''s White Top Hat', 243000, 'legendary', 10638, 1073690, 'bighead:#9aa3b8', true),
  ('nevermoor', 8, 'Valkyrie Helm', 540000, 'legendary', 6383, 1365767, 'bighead:#9aa3b8', true),
  ('nevermoor', 9, 'Ice Valkyrie', 738000, 'legendary', 3191, 4390891467, 'bighead:#9aa3b8', true),
  ('nevermoor', 10, 'Hooded Frostlord', 1800000, 'legendary', 1064, 136802867, 'bighead:#9aa3b8', true),
  ('smiley', 0, 'Christmas Baseball Cap', 2000, 'common', 360000, 1272713, 'bighead:#9aa3b8', false),
  ('smiley', 1, 'For the Ages: Abraham Lincoln', 6400, 'common', 270000, 46363235, 'bighead:#9aa3b8', false),
  ('smiley', 2, 'Bucket', 18000, 'uncommon', 90000, 1081239, 'bighead:#9aa3b8', false),
  ('smiley', 3, 'Hotdog Head', 35800, 'uncommon', 90000, 15318156, 'bighead:#9aa3b8', false),
  ('smiley', 4, 'Golden Headphones', 52700, 'rare', 90000, 29051524, 'bighead:#9aa3b8', false),
  ('smiley', 5, 'Super Super Happy Face', 162000, 'legendary', 34091, 494291269, 'bighead:#9aa3b8', true),
  ('smiley', 6, 'Korblox King', 168200, 'legendary', 27273, 52492417, 'bighead:#9aa3b8', true),
  ('smiley', 7, 'The Ice Skull of Nevermoor', 180000, 'legendary', 22727, 6552254, 'bighead:#9aa3b8', true),
  ('smiley', 8, 'Monstars Visor', 270000, 'legendary', 13636, 1086815, 'bighead:#9aa3b8', true),
  ('smiley', 9, 'Valkyrie Helm', 540000, 'legendary', 2273, 1365767, 'bighead:#9aa3b8', true),
  ('tropical-pop', 0, 'Christmas Baseball Cap', 2000, 'common', 380000, 1272713, 'bighead:#9aa3b8', false),
  ('tropical-pop', 1, 'Black Paintball Mask', 6800, 'common', 285000, 9254521, 'bighead:#9aa3b8', false),
  ('tropical-pop', 2, 'Seeing Stars', 18700, 'uncommon', 95000, 27599954, 'bighead:#9aa3b8', false),
  ('tropical-pop', 3, 'Hotdog Head', 35800, 'uncommon', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('tropical-pop', 4, 'Golden Headphones', 52700, 'rare', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('tropical-pop', 5, 'JJ5x5''s White Top Hat', 243000, 'legendary', 15957, 1073690, 'bighead:#9aa3b8', true),
  ('tropical-pop', 6, 'Monstars Visor', 270000, 'legendary', 12766, 1086815, 'bighead:#9aa3b8', true),
  ('tropical-pop', 7, 'Valkyrie Helm', 540000, 'legendary', 10638, 1365767, 'bighead:#9aa3b8', true),
  ('tropical-pop', 8, 'Wanwood Antlers', 630000, 'legendary', 6383, 1272714, 'bighead:#9aa3b8', true),
  ('tropical-pop', 9, 'Collision Top Hat', 990000, 'legendary', 3191, 158068251, 'bighead:#9aa3b8', true),
  ('tropical-pop', 10, 'Red Crown of Ozymandias', 1980000, 'legendary', 1064, 9465511, 'bighead:#9aa3b8', true),
  ('retro-wave', 0, 'Bouncing Egg of Boing Boing', 2200, 'common', 380000, 1532384, 'bighead:#9aa3b8', false),
  ('retro-wave', 1, 'Traffic Cone', 7200, 'common', 285000, 1082932, 'bighead:#9aa3b8', false),
  ('retro-wave', 2, 'Mick McCann', 21100, 'uncommon', 95000, 23264604, 'bighead:#9aa3b8', false),
  ('retro-wave', 3, 'Hotdog Head', 35800, 'uncommon', 95000, 15318156, 'bighead:#9aa3b8', false),
  ('retro-wave', 4, 'Golden Headphones', 52700, 'rare', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('retro-wave', 5, 'Monstars Visor', 270000, 'legendary', 21429, 1086815, 'bighead:#9aa3b8', true),
  ('retro-wave', 6, 'Valkyrie Helm', 540000, 'legendary', 14286, 1365767, 'bighead:#9aa3b8', true),
  ('retro-wave', 7, 'Glorious Purple Party Queen', 936000, 'legendary', 8571, 258184056, 'bighead:#9aa3b8', true),
  ('retro-wave', 8, 'Clockwork''s Headphones', 1440000, 'legendary', 4286, 1235488, 'bighead:#9aa3b8', true),
  ('retro-wave', 9, 'Retro 80s Headphones', 2520000, 'legendary', 1429, 29844011, 'bighead:#9aa3b8', true),
  ('eclipse', 0, '2009 Graduation Cap', 2300, 'common', 396000, 11721340, 'bighead:#9aa3b8', false),
  ('eclipse', 1, 'White Witch Hat', 7300, 'common', 297000, 5207053, 'bighead:#9aa3b8', false),
  ('eclipse', 2, 'Mick McCann', 21100, 'uncommon', 99000, 23264604, 'bighead:#9aa3b8', false),
  ('eclipse', 3, 'Hotdog Head', 35800, 'uncommon', 99000, 15318156, 'bighead:#9aa3b8', false),
  ('eclipse', 4, 'Pin Head', 56100, 'rare', 99000, 25880554, 'bighead:#9aa3b8', false),
  ('eclipse', 5, 'JJ5x5''s White Top Hat', 243000, 'legendary', 3571, 1073690, 'bighead:#9aa3b8', true),
  ('eclipse', 6, 'Valkyrie Helm', 540000, 'legendary', 2857, 1365767, 'bighead:#9aa3b8', true),
  ('eclipse', 7, 'Silver King of the Night', 846000, 'legendary', 1786, 439945661, 'bighead:#9aa3b8', true),
  ('eclipse', 8, 'Dark Cerulean Crown of Ozymandias', 1512000, 'legendary', 1071, 13370505, 'bighead:#9aa3b8', true),
  ('eclipse', 9, 'Crown of Om Nom Nom', 3060000, 'legendary', 536, 21070350, 'bighead:#9aa3b8', true),
  ('eclipse', 10, 'Gaze of Socom1880', 6120000, 'legendary', 179, 14671091, 'bighead:#9aa3b8', true),
  ('shadow-beats', 0, 'Halloween Harbinger', 3300, 'common', 396000, 15727771, 'bighead:#9aa3b8', false),
  ('shadow-beats', 1, 'Ochre Ogre', 10900, 'common', 297000, 16723499, 'bighead:#9aa3b8', false),
  ('shadow-beats', 2, 'Hotdog Head', 35800, 'uncommon', 99000, 15318156, 'bighead:#9aa3b8', false),
  ('shadow-beats', 3, 'Pin Head', 56100, 'uncommon', 99000, 25880554, 'bighead:#9aa3b8', false),
  ('shadow-beats', 4, 'Golden Chakram of the Sky Palace', 77000, 'rare', 99000, 47597760, 'bighead:#9aa3b8', false),
  ('shadow-beats', 5, 'Monstars Visor', 270000, 'legendary', 3571, 1086815, 'bighead:#9aa3b8', true),
  ('shadow-beats', 6, 'Silver King of the Night', 846000, 'legendary', 2857, 439945661, 'bighead:#9aa3b8', true),
  ('shadow-beats', 7, 'Pink Queen of the Night', 1026000, 'legendary', 1786, 553971558, 'bighead:#9aa3b8', true),
  ('shadow-beats', 8, 'Vaiobot''s Moneylicious Tie', 2250000, 'legendary', 1071, 30371876, 'bighead:#9aa3b8', true),
  ('shadow-beats', 9, 'Sword Cane', 4320000, 'legendary', 536, 25740034, 'bighead:#9aa3b8', true),
  ('shadow-beats', 10, 'Black Iron King of the Night', 10800000, 'legendary', 179, 439946249, 'bighead:#9aa3b8', true),
  ('arctic-moss', 0, 'Ladies Who Lunch', 5600, 'common', 380000, 35167841, 'bighead:#9aa3b8', false),
  ('arctic-moss', 1, 'Bucket', 18000, 'common', 285000, 1081239, 'bighead:#9aa3b8', false),
  ('arctic-moss', 2, 'Golden Headphones', 52700, 'uncommon', 95000, 29051524, 'bighead:#9aa3b8', false),
  ('arctic-moss', 3, 'Playful Vampire', 90000, 'uncommon', 95000, 2409285794, 'bighead:#9aa3b8', false),
  ('arctic-moss', 4, 'Super Super Happy Face', 162000, 'rare', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('arctic-moss', 5, 'Wanwood Antlers', 630000, 'legendary', 15957, 1272714, 'bighead:#9aa3b8', true),
  ('arctic-moss', 6, 'Ice Valkyrie', 738000, 'legendary', 12766, 4390891467, 'bighead:#9aa3b8', true),
  ('arctic-moss', 7, 'Green Ice Crown', 954000, 'legendary', 10638, 193696233, 'bighead:#9aa3b8', true),
  ('arctic-moss', 8, 'Helm of the Great Tree', 1350000, 'legendary', 6383, 9910420, 'bighead:#9aa3b8', true),
  ('arctic-moss', 9, 'Green Bow Tie', 2700000, 'legendary', 3191, 16598513, 'bighead:#9aa3b8', true),
  ('arctic-moss', 10, 'The Ice Crown', 7200000, 'legendary', 1064, 1323384, 'bighead:#9aa3b8', true),
  ('sunbeam', 0, 'One Star General''s Beret', 6700, 'common', 360000, 28039679, 'bighead:#9aa3b8', false),
  ('sunbeam', 1, 'Mick McCann', 21100, 'common', 270000, 23264604, 'bighead:#9aa3b8', false),
  ('sunbeam', 2, 'The Bluesteel Bathelm', 63000, 'uncommon', 90000, 1172161, 'bighead:#9aa3b8', false),
  ('sunbeam', 3, 'Even Eviler Jester', 106700, 'uncommon', 90000, 40893465, 'bighead:#9aa3b8', false),
  ('sunbeam', 4, 'Super Super Happy Face', 162000, 'rare', 90000, 494291269, 'bighead:#9aa3b8', false),
  ('sunbeam', 5, 'Valkyrie Helm', 540000, 'legendary', 31915, 1365767, 'bighead:#9aa3b8', true),
  ('sunbeam', 6, 'Ice Valkyrie', 738000, 'legendary', 25532, 4390891467, 'bighead:#9aa3b8', true),
  ('sunbeam', 7, 'Helm of the Sacred Earth', 900000, 'legendary', 21277, 22157971, 'bighead:#9aa3b8', true),
  ('sunbeam', 8, 'Goldlika: Hero', 936000, 'legendary', 12766, 323419455, 'bighead:#9aa3b8', true),
  ('sunbeam', 9, 'Headdress of Aken-Aten, the Sun King', 1080000, 'legendary', 6383, 18482398, 'bighead:#9aa3b8', true),
  ('sunbeam', 10, 'GoldLika: Troll', 1530000, 'legendary', 2128, 398674241, 'bighead:#9aa3b8', true),
  ('neon-pop', 0, 'Cyborg Soldier', 9400, 'common', 380000, 27052155, 'bighead:#9aa3b8', false),
  ('neon-pop', 1, 'Hotdog Head', 35800, 'common', 285000, 15318156, 'bighead:#9aa3b8', false),
  ('neon-pop', 2, 'Playful Vampire', 90000, 'uncommon', 95000, 2409285794, 'bighead:#9aa3b8', false),
  ('neon-pop', 3, 'Super Super Happy Face', 162000, 'uncommon', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('neon-pop', 4, 'JJ5x5''s White Top Hat', 243000, 'rare', 95000, 1073690, 'bighead:#9aa3b8', false),
  ('neon-pop', 5, 'Neon Purple Crazy Crown', 1116000, 'legendary', 15957, 376805769, 'bighead:#9aa3b8', true),
  ('neon-pop', 6, 'Crazy Glasses', 1350000, 'legendary', 12766, 16646369, 'bighead:#9aa3b8', true),
  ('neon-pop', 7, 'CW Ultimate: Sapphire Serenity', 1890000, 'legendary', 10638, 188888052, 'bighead:#9aa3b8', true),
  ('neon-pop', 8, 'Neon Green Crazy Crown', 2430000, 'legendary', 6383, 321346616, 'bighead:#9aa3b8', true),
  ('neon-pop', 9, 'WC Ultimates: Pink Diamond Distraction', 6300000, 'legendary', 3191, 315549204, 'bighead:#9aa3b8', true),
  ('neon-pop', 10, '): Red Grind', 11700000, 'legendary', 1064, 20573086, 'bighead:#9aa3b8', true),
  ('crystal-beats', 0, 'Cyborg Soldier', 9400, 'common', 396000, 27052155, 'bighead:#9aa3b8', false),
  ('crystal-beats', 1, 'Hotdog Head', 35800, 'common', 297000, 15318156, 'bighead:#9aa3b8', false),
  ('crystal-beats', 2, 'Playful Vampire', 90000, 'uncommon', 99000, 2409285794, 'bighead:#9aa3b8', false),
  ('crystal-beats', 3, 'Super Super Happy Face', 162000, 'uncommon', 99000, 494291269, 'bighead:#9aa3b8', false),
  ('crystal-beats', 4, 'JJ5x5''s White Top Hat', 243000, 'rare', 99000, 1073690, 'bighead:#9aa3b8', false),
  ('crystal-beats', 5, 'Green Ice Crown', 954000, 'legendary', 3571, 193696233, 'bighead:#9aa3b8', true),
  ('crystal-beats', 6, 'Retro 80s Headphones', 2520000, 'legendary', 2857, 29844011, 'bighead:#9aa3b8', true),
  ('crystal-beats', 7, 'Yellow Glowing Eyes', 3240000, 'legendary', 1786, 416846000, 'bighead:#9aa3b8', true),
  ('crystal-beats', 8, 'WC Ultimates: Pink Diamond Distraction', 6300000, 'legendary', 1071, 315549204, 'bighead:#9aa3b8', true),
  ('crystal-beats', 9, 'WC Ultimates: Aquamarine Attitude', 17100000, 'legendary', 536, 323417812, 'bighead:#9aa3b8', true),
  ('crystal-beats', 10, 'Eerie Pumpkin Head', 36000000, 'legendary', 179, 1158416, 'bighead:#9aa3b8', true),
  ('lime-grin', 0, 'Camoface', 12000, 'common', 380000, 24441888, 'bighead:#9aa3b8', false),
  ('lime-grin', 1, 'Viridian Hood', 41200, 'common', 285000, 16954107, 'bighead:#9aa3b8', false),
  ('lime-grin', 2, 'Even Eviler Jester', 106700, 'uncommon', 95000, 40893465, 'bighead:#9aa3b8', false),
  ('lime-grin', 3, 'Picklace', 192600, 'uncommon', 95000, 33615415, 'bighead:#9aa3b8', false),
  ('lime-grin', 4, 'Monstars Visor', 270000, 'rare', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('lime-grin', 5, 'Clockwork''s Headphones', 1440000, 'legendary', 15957, 1235488, 'bighead:#9aa3b8', true),
  ('lime-grin', 6, 'GoldLika: Troll', 1530000, 'legendary', 12766, 398674241, 'bighead:#9aa3b8', true),
  ('lime-grin', 7, 'Neon Green Crazy Crown', 2430000, 'legendary', 10638, 321346616, 'bighead:#9aa3b8', true),
  ('lime-grin', 8, 'Yellow Glowing Eyes', 3240000, 'legendary', 6383, 416846000, 'bighead:#9aa3b8', true),
  ('lime-grin', 9, 'Gaze of Socom1880', 6120000, 'legendary', 3191, 14671091, 'bighead:#9aa3b8', true),
  ('lime-grin', 10, '): Red Grind', 11700000, 'legendary', 1064, 20573086, 'bighead:#9aa3b8', true),
  ('mistletoe', 0, 'Bucket', 18000, 'common', 360000, 1081239, 'bighead:#9aa3b8', false),
  ('mistletoe', 1, 'Golden Headphones', 52700, 'common', 270000, 29051524, 'bighead:#9aa3b8', false),
  ('mistletoe', 2, 'Super Super Happy Face', 162000, 'uncommon', 90000, 494291269, 'bighead:#9aa3b8', false),
  ('mistletoe', 3, 'Monstars Visor', 270000, 'uncommon', 90000, 1086815, 'bighead:#9aa3b8', false),
  ('mistletoe', 4, 'Valkyrie Helm', 540000, 'rare', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('mistletoe', 5, 'Fancy St. Patrick''s Fedora', 1350000, 'legendary', 31915, 149594212, 'bighead:#9aa3b8', true),
  ('mistletoe', 6, 'Immortal Sword: Endless Ice Slasher', 1800000, 'legendary', 25532, 568920951, 'bighead:#9aa3b8', true),
  ('mistletoe', 7, 'CW Ultimate: Sapphire Serenity', 1890000, 'legendary', 21277, 188888052, 'bighead:#9aa3b8', true),
  ('mistletoe', 8, 'Neon Green Crazy Crown', 2430000, 'legendary', 12766, 321346616, 'bighead:#9aa3b8', true),
  ('mistletoe', 9, 'Green Bow Tie', 2700000, 'legendary', 6383, 16598513, 'bighead:#9aa3b8', true),
  ('mistletoe', 10, 'Sparkle Time Fedora', 4500000, 'legendary', 2128, 1285307, 'bighead:#9aa3b8', true),
  ('winter-crown', 0, 'Bucket', 18000, 'common', 380000, 1081239, 'bighead:#9aa3b8', false),
  ('winter-crown', 1, 'Pin Head', 56100, 'common', 285000, 25880554, 'bighead:#9aa3b8', false),
  ('winter-crown', 2, 'Super Super Happy Face', 162000, 'uncommon', 95000, 494291269, 'bighead:#9aa3b8', false),
  ('winter-crown', 3, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('winter-crown', 4, 'Valkyrie Helm', 540000, 'rare', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('winter-crown', 5, 'Red Crown of Ozymandias', 1980000, 'legendary', 15957, 9465511, 'bighead:#9aa3b8', true),
  ('winter-crown', 6, 'Neon Green Crazy Crown', 2430000, 'legendary', 12766, 321346616, 'bighead:#9aa3b8', true),
  ('winter-crown', 7, 'Crown of Om Nom Nom', 3060000, 'legendary', 10638, 21070350, 'bighead:#9aa3b8', true),
  ('winter-crown', 8, 'The Void Star', 5580000, 'legendary', 6383, 1125510, 'bighead:#9aa3b8', true),
  ('winter-crown', 9, 'Black Iron King of the Night', 10800000, 'legendary', 3191, 439946249, 'bighead:#9aa3b8', true),
  ('winter-crown', 10, 'Darkheart', 21600000, 'legendary', 1064, 16895215, 'bighead:#9aa3b8', true),
  ('violet-beats', 0, 'Hotdog Head', 35800, 'common', 360000, 15318156, 'bighead:#9aa3b8', false),
  ('violet-beats', 1, 'Lava Reactor', 101800, 'common', 270000, 32858948, 'bighead:#9aa3b8', false),
  ('violet-beats', 2, 'Monstars Visor', 270000, 'uncommon', 90000, 1086815, 'bighead:#9aa3b8', false),
  ('violet-beats', 3, 'Valkyrie Helm', 540000, 'uncommon', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('violet-beats', 4, 'Ice Valkyrie', 738000, 'rare', 90000, 4390891467, 'bighead:#9aa3b8', false),
  ('violet-beats', 5, 'CW Ultimate: Amethyst Addiction', 2520000, 'legendary', 31915, 188004500, 'bighead:#9aa3b8', true),
  ('violet-beats', 6, 'Crown of the Undead Hoard', 2610000, 'legendary', 25532, 31046644, 'bighead:#9aa3b8', true),
  ('violet-beats', 7, 'Chrononoctis: The Ominous Helm', 2790000, 'legendary', 21277, 161211371, 'bighead:#9aa3b8', true),
  ('violet-beats', 8, 'CW Ultimate: Rose Quartz Rebellion', 3600000, 'legendary', 12766, 228449574, 'bighead:#9aa3b8', true),
  ('violet-beats', 9, 'Steampunk Aetherspectacles', 4860000, 'legendary', 6383, 12908119, 'bighead:#9aa3b8', true),
  ('violet-beats', 10, 'Dominus Rex', 7920000, 'legendary', 2128, 250395631, 'bighead:#9aa3b8', true),
  ('glacier', 0, 'Hotdog Head', 35800, 'common', 380000, 15318156, 'bighead:#9aa3b8', false),
  ('glacier', 1, 'Lava Reactor', 101800, 'common', 285000, 32858948, 'bighead:#9aa3b8', false),
  ('glacier', 2, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('glacier', 3, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('glacier', 4, 'Ice Valkyrie', 738000, 'rare', 95000, 4390891467, 'bighead:#9aa3b8', false),
  ('glacier', 5, 'Frozen Horns of the Frigid Planes', 3600000, 'legendary', 15957, 74891470, 'bighead:#9aa3b8', true),
  ('glacier', 6, 'Fiery Horns of the Netherworld', 3960000, 'legendary', 12766, 215718515, 'bighead:#9aa3b8', true),
  ('glacier', 7, 'Steampunk Aetherspectacles', 4860000, 'legendary', 10638, 12908119, 'bighead:#9aa3b8', true),
  ('glacier', 8, 'The Ice Crown', 7200000, 'legendary', 6383, 1323384, 'bighead:#9aa3b8', true),
  ('glacier', 9, 'The Wanwood Crown', 14400000, 'legendary', 3191, 9910070, 'bighead:#9aa3b8', true),
  ('glacier', 10, 'Eerie Pumpkin Head', 36000000, 'legendary', 1064, 1158416, 'bighead:#9aa3b8', true),
  ('evergreen', 0, 'Hotdog Head', 35800, 'common', 380000, 15318156, 'bighead:#9aa3b8', false),
  ('evergreen', 1, 'Lava Reactor', 101800, 'common', 285000, 32858948, 'bighead:#9aa3b8', false),
  ('evergreen', 2, 'Monstars Visor', 270000, 'uncommon', 95000, 1086815, 'bighead:#9aa3b8', false),
  ('evergreen', 3, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('evergreen', 4, 'Ice Valkyrie', 738000, 'rare', 95000, 4390891467, 'bighead:#9aa3b8', false),
  ('evergreen', 5, 'Green Glowing Eyes', 3780000, 'legendary', 15957, 398676450, 'bighead:#9aa3b8', true),
  ('evergreen', 6, 'CW Ultimate: Emerald Entropy', 4320000, 'legendary', 12766, 271015154, 'bighead:#9aa3b8', true),
  ('evergreen', 7, 'Gaze of Socom1880', 6120000, 'legendary', 10638, 14671091, 'bighead:#9aa3b8', true),
  ('evergreen', 8, 'Red Glowing Eyes', 8280000, 'legendary', 6383, 180660043, 'bighead:#9aa3b8', true),
  ('evergreen', 9, 'Bluesteel Bling $$ Necklace', 18900000, 'legendary', 3191, 489196035, 'bighead:#9aa3b8', true),
  ('evergreen', 10, 'Domino Crown', 43200000, 'legendary', 1064, 1031429, 'bighead:#9aa3b8', true),
  ('fire-ice', 0, 'The Crown of Nachos', 44100, 'common', 360000, 22547617, 'bighead:#9aa3b8', false),
  ('fire-ice', 1, 'Super Super Happy Face', 162000, 'common', 270000, 494291269, 'bighead:#9aa3b8', false),
  ('fire-ice', 2, 'Valkyrie Helm', 540000, 'uncommon', 90000, 1365767, 'bighead:#9aa3b8', false),
  ('fire-ice', 3, 'Silver King of the Night', 846000, 'uncommon', 90000, 439945661, 'bighead:#9aa3b8', false),
  ('fire-ice', 4, 'Crown of Tones', 1188000, 'rare', 90000, 152173424, 'bighead:#9aa3b8', false),
  ('fire-ice', 5, 'Fiery Horns of the Netherworld', 3960000, 'legendary', 31915, 215718515, 'bighead:#9aa3b8', true),
  ('fire-ice', 6, ':( Front Stand', 4050000, 'legendary', 25532, 321346550, 'bighead:#9aa3b8', true),
  ('fire-ice', 7, 'Sparkle Time Fedora', 4500000, 'legendary', 21277, 1285307, 'bighead:#9aa3b8', true),
  ('fire-ice', 8, 'The Ice Crown', 7200000, 'legendary', 12766, 1323384, 'bighead:#9aa3b8', true),
  ('fire-ice', 9, 'Red Glowing Eyes', 8280000, 'legendary', 6383, 180660043, 'bighead:#9aa3b8', true),
  ('fire-ice', 10, '): Red Grind', 11700000, 'legendary', 2128, 20573086, 'bighead:#9aa3b8', true),
  ('black-ice', 0, 'Golden Headphones', 52700, 'common', 380000, 29051524, 'bighead:#9aa3b8', false),
  ('black-ice', 1, 'Korblox King', 168200, 'common', 285000, 52492417, 'bighead:#9aa3b8', false),
  ('black-ice', 2, 'Valkyrie Helm', 540000, 'uncommon', 95000, 1365767, 'bighead:#9aa3b8', false),
  ('black-ice', 3, 'Silver King of the Night', 846000, 'uncommon', 95000, 439945661, 'bighead:#9aa3b8', false),
  ('black-ice', 4, 'Spec Beta Biograft Energy Sword', 1260000, 'rare', 95000, 14876573, 'bighead:#9aa3b8', false),
  ('black-ice', 5, 'Green Glowing Eyes', 3780000, 'legendary', 15957, 398676450, 'bighead:#9aa3b8', true),
  ('black-ice', 6, 'The Ice Crown', 7200000, 'legendary', 12766, 1323384, 'bighead:#9aa3b8', true),
  ('black-ice', 7, 'Black Iron King of the Night', 10800000, 'legendary', 10638, 439946249, 'bighead:#9aa3b8', true),
  ('black-ice', 8, 'The Crown of Roses', 13500000, 'legendary', 6383, 17449820, 'bighead:#9aa3b8', true),
  ('black-ice', 9, 'Darkheart', 21600000, 'legendary', 3191, 16895215, 'bighead:#9aa3b8', true),
  ('black-ice', 10, 'Black Sparkle Time Fedora', 45000000, 'legendary', 1064, 259423244, 'bighead:#9aa3b8', true),
  ('amethyst', 0, 'Playful Vampire', 90000, 'common', 396000, 2409285794, 'bighead:#9aa3b8', false),
  ('amethyst', 1, 'Monstars Visor', 270000, 'common', 297000, 1086815, 'bighead:#9aa3b8', false),
  ('amethyst', 2, 'Ice Valkyrie', 738000, 'uncommon', 99000, 4390891467, 'bighead:#9aa3b8', false),
  ('amethyst', 3, 'Dominus Praefectus', 1422000, 'uncommon', 99000, 527365852, 'bighead:#9aa3b8', false),
  ('amethyst', 4, 'Red Crown of Ozymandias', 1980000, 'rare', 99000, 9465511, 'bighead:#9aa3b8', false),
  ('amethyst', 5, 'Countess of the Federation', 9000000, 'legendary', 3571, 188003914, 'bighead:#9aa3b8', true),
  ('amethyst', 6, 'Orange Sparkle Time Fedora', 17100000, 'legendary', 2857, 215751161, 'bighead:#9aa3b8', true),
  ('amethyst', 7, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 1786, 63043890, 'bighead:#9aa3b8', true),
  ('amethyst', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 1071, 259423244, 'bighead:#9aa3b8', true),
  ('amethyst', 9, 'Dominus Astra', 108000000, 'legendary', 536, 162067148, 'bighead:#9aa3b8', true),
  ('amethyst', 10, 'Dominus Empyreus', 198000000, 'legendary', 179, 21070012, 'bighead:#9aa3b8', true),
  ('jade', 0, 'Super Super Happy Face', 162000, 'common', 380000, 494291269, 'bighead:#9aa3b8', false),
  ('jade', 1, 'Valkyrie Helm', 540000, 'common', 285000, 1365767, 'bighead:#9aa3b8', false),
  ('jade', 2, 'Dominus Praefectus', 1422000, 'uncommon', 95000, 527365852, 'bighead:#9aa3b8', false),
  ('jade', 3, 'Clockwork''s Shades', 2520000, 'uncommon', 95000, 11748356, 'bighead:#9aa3b8', false),
  ('jade', 4, 'Green Glowing Eyes', 3780000, 'rare', 95000, 398676450, 'bighead:#9aa3b8', false),
  ('jade', 5, 'Teal Sparkle Time Fedora', 18000000, 'legendary', 15957, 147180077, 'bighead:#9aa3b8', true),
  ('jade', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 12766, 493476042, 'bighead:#9aa3b8', true),
  ('jade', 7, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 10638, 63043890, 'bighead:#9aa3b8', true),
  ('jade', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 6383, 259423244, 'bighead:#9aa3b8', true),
  ('jade', 9, 'Dominus Astra', 108000000, 'legendary', 3191, 162067148, 'bighead:#9aa3b8', true),
  ('jade', 10, 'Dominus Empyreus', 198000000, 'legendary', 1064, 21070012, 'bighead:#9aa3b8', true),
  ('sapphire', 0, 'Picklace', 192600, 'common', 360000, 33615415, 'bighead:#9aa3b8', false),
  ('sapphire', 1, 'Wanwood Antlers', 630000, 'common', 270000, 1272714, 'bighead:#9aa3b8', false),
  ('sapphire', 2, 'Hooded Frostlord', 1800000, 'uncommon', 90000, 136802867, 'bighead:#9aa3b8', false),
  ('sapphire', 3, 'Cultural Item', 3240000, 'uncommon', 90000, 14462955, 'bighead:#9aa3b8', false),
  ('sapphire', 4, 'Steampunk Aetherspectacles', 4860000, 'rare', 90000, 12908119, 'bighead:#9aa3b8', false),
  ('sapphire', 5, 'Archduke of the Federation', 14400000, 'legendary', 31915, 293316452, 'bighead:#9aa3b8', true),
  ('sapphire', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 25532, 493476042, 'bighead:#9aa3b8', true),
  ('sapphire', 7, '): Euro 180', 22500000, 'legendary', 21277, 23705521, 'bighead:#9aa3b8', true),
  ('sapphire', 8, 'Purple Sparkle Time Fedora', 36000000, 'legendary', 12766, 63043890, 'bighead:#9aa3b8', true),
  ('sapphire', 9, 'Domino Crown', 43200000, 'legendary', 6383, 1031429, 'bighead:#9aa3b8', true),
  ('sapphire', 10, 'Black Sparkle Time Fedora', 45000000, 'legendary', 2128, 259423244, 'bighead:#9aa3b8', true),
  ('sunset-remix', 0, 'JJ5x5''s White Top Hat', 243000, 'common', 380000, 1073690, 'bighead:#9aa3b8', false),
  ('sunset-remix', 1, 'Ice Valkyrie', 738000, 'common', 285000, 4390891467, 'bighead:#9aa3b8', false),
  ('sunset-remix', 2, 'Vaiobot''s Moneylicious Tie', 2250000, 'uncommon', 95000, 30371876, 'bighead:#9aa3b8', false),
  ('sunset-remix', 3, 'Green Glowing Eyes', 3780000, 'uncommon', 95000, 398676450, 'bighead:#9aa3b8', false),
  ('sunset-remix', 4, 'The Void Star', 5580000, 'rare', 95000, 1125510, 'bighead:#9aa3b8', false),
  ('sunset-remix', 5, 'Dominus Pittacium', 17100000, 'legendary', 15957, 335080779, 'bighead:#9aa3b8', true),
  ('sunset-remix', 6, 'Sky Blue Sparkle Time Fedora', 21600000, 'legendary', 12766, 493476042, 'bighead:#9aa3b8', true),
  ('sunset-remix', 7, 'Domino Crown', 43200000, 'legendary', 10638, 1031429, 'bighead:#9aa3b8', true),
  ('sunset-remix', 8, 'Black Sparkle Time Fedora', 45000000, 'legendary', 6383, 259423244, 'bighead:#9aa3b8', true),
  ('sunset-remix', 9, 'Dominus Astra', 108000000, 'legendary', 3191, 162067148, 'bighead:#9aa3b8', true),
  ('sunset-remix', 10, 'Dominus Empyreus', 198000000, 'legendary', 1064, 21070012, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 0, 'Silver King of the Night', 846000, 'common', 360000, 439945661, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 1, 'Chrononoctis: The Ominous Helm', 2790000, 'common', 270000, 161211371, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 2, 'Dominus Rex', 7920000, 'uncommon', 90000, 250395631, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 3, 'The Wanwood Crown', 14400000, 'uncommon', 90000, 9910070, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 4, 'Darkheart', 21600000, 'rare', 90000, 16895215, 'bighead:#9aa3b8', false),
  ('ultimate-grin', 5, 'Dominus Astra', 108000000, 'legendary', 41380, 162067148, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 6, 'Dominus Infernus', 126000000, 'legendary', 34482, 31101391, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 7, 'Dominus Frigidus', 162000000, 'legendary', 20689, 48545806, 'bighead:#9aa3b8', true),
  ('ultimate-grin', 8, 'Dominus Empyreus', 198000000, 'legendary', 3449, 21070012, 'bighead:#9aa3b8', true);


-- =====================================================================
-- EmpireBlox update 14: Provably fair
-- Run once in Supabase → SQL Editor → New query → paste → Run.
-- If Supabase asks about RLS, choose "Run without RLS". Safe to run twice.
--
-- How it works
--  • Every player has a secret SERVER SEED (only its SHA-256 hash is shown),
--    a CLIENT SEED they can change, and a NONCE that goes up by 1 every bet.
--  • Every random number = first 4 bytes of HMAC-SHA256(server seed, "client:nonce:n") ÷ 2^32,
--    for n = 0, 1, 2 … — so results are fixed before you bet and can't be changed.
--  • Changing your client seed reveals the old server seed, so you can check every past bet.
--  • Case battles use their own seed per battle: the hash shows while the battle is open,
--    and the seed is revealed once it rolls (client seed = the battle id, nonce = 0).
-- =====================================================================

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.pf_seeds (
  user_id     uuid primary key references public.profiles(id) on delete cascade,
  server_seed text not null,
  client_seed text not null,
  nonce       bigint not null default 0
);
create table if not exists public.pf_revealed (
  hash text primary key,
  seed text not null,
  revealed_at timestamptz not null default now()
);
create table if not exists public.pf_bets (
  id          bigint generated always as identity primary key,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  game        text not null,
  client_seed text not null,
  nonce       bigint not null,
  seed_hash   text not null,
  detail      jsonb not null default '{}',
  created_at  timestamptz not null default now()
);
create index if not exists pf_bets_user on public.pf_bets (user_id, id desc);
create table if not exists public.battle_seeds (
  battle_id uuid primary key references public.battles(id) on delete cascade,
  seed text not null
);
alter table public.battles add column if not exists pf_hash text;
alter table public.battles add column if not exists pf_seed text;
alter table public.pf_seeds enable row level security;
alter table public.pf_revealed enable row level security;
alter table public.pf_bets enable row level security;
alter table public.battle_seeds enable row level security;
drop policy if exists "revealed seeds are public" on public.pf_revealed;
create policy "revealed seeds are public" on public.pf_revealed for select using (true);
revoke all on public.pf_seeds, public.pf_revealed, public.pf_bets, public.battle_seeds from anon, authenticated;
grant select on public.pf_revealed to anon, authenticated;

create or replace function public.pf_hash(p text)
returns text language sql immutable set search_path = public, extensions as $$ select encode(digest(p, 'sha256'), 'hex') $$;

-- next fair random number in [0, 1); falls back to random() when no seed is active
create or replace function public.pf_rand()
returns double precision language plpgsql volatile set search_path = public, extensions as $$
declare s text := current_setting('eb.pf_seed', true); c int; h bytea;
begin
  if s is null or s = '' then return random(); end if;
  c := coalesce(nullif(current_setting('eb.pf_cursor', true), ''), '0')::int;
  perform set_config('eb.pf_cursor', (c + 1)::text, true);
  h := hmac(current_setting('eb.pf_client', true) || ':' || current_setting('eb.pf_nonce', true) || ':' || c, s, 'sha256');
  return (get_byte(h, 0)::bigint * 16777216 + get_byte(h, 1) * 65536 + get_byte(h, 2) * 256 + get_byte(h, 3)) / 4294967296.0;
end $$;

create or replace function public.pf_set(p_seed text, p_client text, p_nonce bigint)
returns void language plpgsql volatile as $$
begin
  perform set_config('eb.pf_seed', coalesce(p_seed, ''), true);
  perform set_config('eb.pf_client', coalesce(p_client, ''), true);
  perform set_config('eb.pf_nonce', coalesce(p_nonce, 0)::text, true);
  perform set_config('eb.pf_cursor', '0', true);
end $$;

create or replace function public.pf_ensure(p_uid uuid)
returns public.pf_seeds language plpgsql security definer set search_path = public, extensions as $$
declare r public.pf_seeds;
begin
  insert into public.pf_seeds (user_id, server_seed, client_seed)
  values (p_uid, encode(gen_random_bytes(32), 'hex'), encode(gen_random_bytes(8), 'hex'))
  on conflict (user_id) do nothing;
  select * into r from public.pf_seeds where user_id = p_uid for update;
  return r;
end $$;

-- start a fair bet: load the player's seeds, log the bet, move the nonce on
create or replace function public.pf_begin(p_uid uuid, p_game text, p_detail jsonb default '{}')
returns void language plpgsql security definer set search_path = public, extensions as $$
declare r public.pf_seeds;
begin
  if p_uid is null then return; end if;
  r := public.pf_ensure(p_uid);
  perform public.pf_set(r.server_seed, r.client_seed, r.nonce);
  insert into public.pf_bets (user_id, game, client_seed, nonce, seed_hash, detail)
  values (p_uid, p_game, r.client_seed, r.nonce, public.pf_hash(r.server_seed), coalesce(p_detail, '{}'));
  update public.pf_seeds set nonce = nonce + 1 where user_id = p_uid;
end $$;

-- ---------------------------------------------------------------------
-- Point every game's randomness at pf_rand(), then wrap the games so each
-- bet starts from the player's seeds. (Rewrites the live function bodies.)
-- ---------------------------------------------------------------------
do $$
declare f text; def text;
begin
  foreach f in array array['public.pick_item(text)', 'public.pick_pack_item(integer)', 'public.open_case(text)',
    'public.mines_start(bigint,integer,integer)', 'public.upgrade(bigint,bigint,boolean)', 'public.bj_start(bigint)',
    'public.battle_roll(uuid)', 'public.claim_pack(integer)'] loop
    if to_regprocedure(f) is not null then
      def := pg_get_functiondef(to_regprocedure(f));
      if position('random()' in def) > 0 then execute replace(def, 'random()', 'public.pf_rand()'); end if;
    end if;
  end loop;
  -- rename once; the wrappers below take the original names
  if to_regprocedure('public.open_case_impl(text)') is null then alter function public.open_case(text) rename to open_case_impl; end if;
  if to_regprocedure('public.mines_start_impl(bigint,integer,integer)') is null then alter function public.mines_start(bigint, int, int) rename to mines_start_impl; end if;
  if to_regprocedure('public.upgrade_impl(bigint,bigint,boolean)') is null then alter function public.upgrade(bigint, bigint, boolean) rename to upgrade_impl; end if;
  if to_regprocedure('public.bj_start_impl(bigint)') is null then alter function public.bj_start(bigint) rename to bj_start_impl; end if;
  if to_regprocedure('public.claim_pack_impl(integer)') is null then alter function public.claim_pack(int) rename to claim_pack_impl; end if;
  if to_regprocedure('public.battle_roll_impl(uuid)') is null then alter function public.battle_roll(uuid) rename to battle_roll_impl; end if;
  if to_regprocedure('public.battle_create_impl(text,text[],boolean,boolean,integer)') is null then
    alter function public.battle_create(text, text[], boolean, boolean, int) rename to battle_create_impl; end if;
end $$;

create or replace function public.open_case(p_case text)
returns json language plpgsql security definer set search_path = public as $$
begin
  perform public.pf_begin(auth.uid(), 'cases', jsonb_build_object('case', p_case));
  return public.open_case_impl(p_case);
end $$;

create or replace function public.mines_start(p_bet bigint, p_size int, p_mines int)
returns json language plpgsql security definer set search_path = public as $$
begin
  perform public.pf_begin(auth.uid(), 'mines', jsonb_build_object('size', p_size, 'mines', p_mines));
  return public.mines_start_impl(p_bet, p_size, p_mines);
end $$;

create or replace function public.upgrade(p_bet bigint, p_item bigint, p_over boolean)
returns json language plpgsql security definer set search_path = public as $$
begin
  perform public.pf_begin(auth.uid(), 'upgrader', jsonb_build_object('item', p_item, 'over', p_over, 'bet', p_bet));
  return public.upgrade_impl(p_bet, p_item, p_over);
end $$;

create or replace function public.bj_start(p_bet bigint)
returns json language plpgsql security definer set search_path = public as $$
begin
  perform public.pf_begin(auth.uid(), 'blackjack', '{}');
  return public.bj_start_impl(p_bet);
end $$;

create or replace function public.claim_pack(p_level int)
returns json language plpgsql security definer set search_path = public as $$
begin
  perform public.pf_begin(auth.uid(), 'rewards', jsonb_build_object('level', p_level));
  return public.claim_pack_impl(p_level);
end $$;

-- battles: one seed per battle, hash shown up front, seed revealed after the roll
create or replace function public.battle_create(p_mode text, p_cases text[], p_crazy boolean default false, p_jackpot boolean default false, p_borrow int default 0)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare r json; s text := encode(gen_random_bytes(32), 'hex');
begin
  r := public.battle_create_impl(p_mode, p_cases, p_crazy, p_jackpot, p_borrow);
  insert into public.battle_seeds (battle_id, seed) values ((r->>'id')::uuid, s);
  update public.battles set pf_hash = public.pf_hash(s) where id = (r->>'id')::uuid;
  return r;
end $$;

create or replace function public.battle_roll(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare s text;
begin
  select seed into s from public.battle_seeds where battle_id = p_id;
  if s is not null then perform public.pf_set(s, p_id::text, 0); end if;
  perform public.battle_roll_impl(p_id);
  perform public.pf_set('', '', 0);
  if s is not null then update public.battles set pf_seed = s where id = p_id; end if;
end $$;

-- ---------------------------------------------------------------------
-- What the player sees
-- ---------------------------------------------------------------------
create or replace function public.pf_state()
returns json language plpgsql volatile security definer set search_path = public as $$
declare r public.pf_seeds;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  r := public.pf_ensure(auth.uid());
  return json_build_object('hash', public.pf_hash(r.server_seed), 'client', r.client_seed, 'nonce', r.nonce);
end $$;

-- new client seed → reveals the old server seed and starts a fresh one
create or replace function public.pf_rotate(p_client text)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare r public.pf_seeds; v_client text := btrim(coalesce(p_client, ''));
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if v_client = '' then v_client := encode(gen_random_bytes(8), 'hex'); end if;
  if v_client !~ '^[A-Za-z0-9_-]{1,64}$' then raise exception 'Client seed: use 1-64 letters, numbers, - or _'; end if;
  r := public.pf_ensure(auth.uid());
  insert into public.pf_revealed (hash, seed) values (public.pf_hash(r.server_seed), r.server_seed) on conflict do nothing;
  update public.pf_seeds set server_seed = encode(gen_random_bytes(32), 'hex'), client_seed = v_client, nonce = 0 where user_id = auth.uid();
  return json_build_object('revealed', r.server_seed, 'revealed_hash', public.pf_hash(r.server_seed));
end $$;

create or replace function public.pf_my_bets(p_limit int default 30)
returns json language sql stable security definer set search_path = public as $$
  select coalesce(json_agg(t order by t.id desc), '[]') from (
    select b.id, b.game, b.client_seed, b.nonce, b.seed_hash, b.detail, b.created_at, v.seed as server_seed
      from public.pf_bets b left join public.pf_revealed v on v.hash = b.seed_hash
     where b.user_id = auth.uid() order by b.id desc limit least(greatest(p_limit, 1), 100)) t
$$;

-- Who may call what
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.username_available(text), public.get_profile(uuid), public.get_leaderboard() to anon, authenticated;
grant execute on function
  public.my_profile(), public.set_username(text), public.claim_faucet(), public.open_case(text),
  public.mines_start(bigint, int, int), public.mines_reveal(bigint, int), public.mines_cashout(bigint), public.mines_resume(),
  public.battle_create(text, text[], boolean, boolean, int), public.battle_join(uuid, int, int), public.battle_add_bots(uuid, int), public.battle_cancel(uuid),
  public.send_chat(text), public.tip_user(uuid, bigint), public.upgrade(bigint, bigint, boolean), public.claim_pack(int),
  public.bj_start(bigint), public.bj_act(bigint, text), public.bj_resume(),
  public.admin_stats(), public.admin_find(text), public.admin_coins(uuid, bigint), public.admin_set_admin(uuid, boolean), public.admin_delete_chat(bigint), public.admin_set_lb_hidden(uuid, boolean),
  public.pf_state(), public.pf_rotate(text), public.pf_my_bets(int)
  to authenticated;


