# EmpireBlox

Play-money Roblox-limiteds site: Mines, Cases and multiplayer Case Battles, with accounts and live chat.
Coins are play money only — nothing can be bought, sold, deposited or withdrawn.

- **Front end:** plain HTML/CSS/JS (no build step) — `index.html`, `app.js`, `config.js`, `assets/`
- **Back end:** Supabase — accounts (username + email + password), coins, games, battles and chat.
  All coin changes run as database functions in `supabase/schema.sql`, so players can't cheat from the browser.

---

## 1. Set up Supabase (about 5 minutes, free)

1. Go to <https://supabase.com>, sign in and click **New project**. Pick any name, a strong database password and the region closest to your players.
2. When it's ready, open **SQL Editor → New query**, paste the whole of `supabase/schema.sql`, and click **Run**. You should see "Success".
   (`schema.sql` already includes every update. The `update-*.sql` files are only for databases set up before that update.)
3. Open **Project Settings → API** and copy:
   - **Project URL** (looks like `https://abcd1234.supabase.co`)
   - **anon public** key
4. Paste both into `config.js`:
   ```js
   export const SUPABASE_URL = 'https://abcd1234.supabase.co';
   export const SUPABASE_ANON_KEY = 'eyJhbGciOi...';
   ```
   Both are safe to publish. Never put the `service_role` key in this project.

## 2. Deploy to Vercel

In a terminal, inside this folder:

```bash
npx vercel          # first time: log in, accept the defaults ("Other" framework, no build command)
npx vercel --prod   # publishes to your live URL
```

Vercel prints your live address, e.g. `https://empireblox.vercel.app`.

## 3. Point Supabase sign-in emails at your site

In Supabase, open **Authentication → URL Configuration**:

- **Site URL:** your Vercel address, e.g. `https://empireblox.vercel.app`
- **Redirect URLs:** add the same address (and `http://localhost:3000` if you test locally)

This makes the confirmation and password-reset emails send people back to your site.

**Email limits:** Supabase's built-in email sender only allows a few emails per hour, which is fine for testing.
Before opening to lots of players, add your own email sender under **Project Settings → Authentication → SMTP**
(Resend, Postmark and SendGrid all have free tiers).

---

## How it works

| Thing | Where |
|---|---|
| Sign up / log in / reset password | Supabase Auth (email + password, email confirmation on) |
| Username + coins | `profiles` table — new players start with 60,000 coins |
| Free coins | `claim_faucet()` — 6,000 coins once a minute |
| Cases | `cases` + `case_items` tables, `open_case()` — price = average item value ÷ 0.95 |
| Mines | `mines_start()`, `mines_reveal()`, `mines_cashout()` — mine positions stay on the server until the round ends; an unfinished round comes back after a refresh |
| Battles | `battles` table + `battle_create/join/add_bots/cancel()`; the server rolls every round and pays the winning team when the last seat fills |
| Live chat | `chat_messages` + `send_chat()` — 3-second slowmode, keeps the latest 500 messages |
| Levels | `levels` table — level 1 at 0 coins wagered, 2 at 6,000, 3 at 16,000, 4 at 26,000, 5 at 40,000, then each level needs 8% more (level 100 ≈ 283M wagered) |
| Profiles | `get_profile()` — level, total wagered, favourite game, rewards; your own page also shows email, password change, statistics and transactions |
| Upgrader | `upgrade_items` (233 limiteds) + `upgrade()` — chance = bet ÷ item value × 95%, capped at 80%; Roll Under or Roll Over |
| House edge | 5% on every game: cases and battles through case prices, Mines payouts × 0.95, Upgrader chance × 0.95, Blackjack wins pay 0.9 to 1 |
| Rewards | `reward_packs` + `reward_pack_items` + `claim_pack()` — a free pack every 10 levels (10–100), each openable once every 24 hours |
| Blackjack | `bj_games` + `bj_start()` / `bj_act()` / `bj_resume()` — 6 decks, dealer stands on all 17s, hit / stand / double / split / insurance; the hole card and shoe never leave the server |
| Cases | 30 cases (`cases.image` = the case picture in `assets/cases/`). Each case's best pull is about 3.6× its price, 5% house edge. Items marked `top` hide behind a gold dice on the spinner (3% per open; 8.75% for Ultimate Grin); landing it respins between just those items at their normal odds. The 4 original cases are retired (`active = false`) |
| Update 8 | 120 cheaper limiteds; cases rebalanced (cheap pulls well under the price, ~30% chance to profit, 5% edge); rewards 99.2% low / 0.6% good / 0.2% best; Blackjack pays 1 to 1 and 3 to 2; battle modes (3 way, 4 way, Group Unbox, Crazy, Jackpot, Borrow); admin page (`profiles.is_admin`, Emperor is admin) |
| Update 9 | 50 cases from 600 coins up, each with a risk style (steady / classic / junk / longshot) and a 5%, 10% or 15% house edge; coin pulls; named bots (Emperor, Mr Bacon, Whale, Rookie, High Roller, Lucky); Blackjack totals count up as cards land; admin can hide a player from the weekly leaderboard (`profiles.lb_hidden`) |
| Weekly leaderboard | `weekly_wagers` + `get_leaderboard()` — every wager counts toward the week (Monday 00:00 UTC). When a week ends the top 10 split 500,000 coins (150K, 100K, 70K, 50K, 40K, 30K, 20K, 15K, 15K, 10K), paid automatically the next time anyone opens the site |
| Tips | `tip_user()` — send play coins to another player (level 2+, minimum 100) |
| Transactions | `transactions` table — every bet, win, refund, free coins and tip; each player only sees their own |
| Live updates | Supabase Realtime on `battles`, `chat_messages` and your own `transactions` |

**Values:** each item's coin value is its Rolimons Robux value × $3 per 1,000 Robux × 600 coins per $1 ($10 = 6,000 coins).
To change items or values, edit the rows in the `case_items` table in Supabase (Table Editor), then re-run the
"Case price" update at the bottom of the seed section in `schema.sql` so case prices follow.

**Item pictures:** items with a Roblox catalog ID load their real thumbnail; the rest use built-in drawings.

## Moderating chat

In Supabase **Table Editor → chat_messages**, delete any message. To stop someone playing or chatting,
delete their user under **Authentication → Users** (this also removes their profile).

## Testing locally

```bash
npx serve .        # then open the address it prints
```
