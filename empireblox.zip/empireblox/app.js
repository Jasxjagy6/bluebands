/* EmpireBlox front end. Talks to Supabase for accounts, coins, games, battles and chat.
   All coin changes happen in database functions (supabase/schema.sql), never in the browser. */
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

/* ---------- helpers ---------- */
const $ = id => document.getElementById(id);
const fmt = v => Math.round(+v || 0).toLocaleString();
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const COIN = '<svg class="coin" viewBox="0 0 20 20" aria-hidden="true"><ellipse cx="10" cy="15.2" rx="7.4" ry="2.6" fill="#b97a07"/><rect x="2.6" y="12.6" width="14.8" height="2.6" fill="#d9960f"/><ellipse cx="10" cy="12.6" rx="7.4" ry="2.6" fill="#f7c948"/><ellipse cx="9.4" cy="10.4" rx="7.4" ry="2.6" fill="#b97a07"/><rect x="2" y="7.8" width="14.8" height="2.6" fill="#d9960f"/><ellipse cx="9.4" cy="7.8" rx="7.4" ry="2.6" fill="#f7c948"/><ellipse cx="10.4" cy="5.6" rx="7.4" ry="2.6" fill="#b97a07"/><rect x="3" y="3" width="14.8" height="2.6" fill="#d9960f"/><ellipse cx="10.4" cy="3" rx="7.4" ry="2.6" fill="#ffd95e"/><ellipse cx="8.6" cy="2.5" rx="3.2" ry=".9" fill="#fff3b8" opacity=".75"/></svg>';
const fmtS = v => { v = Number(v) || 0; const A = Math.abs(v); return A >= 1e9 ? +(v / 1e9).toFixed(2) + 'B' : A >= 1e6 ? +(v / 1e6).toFixed(2) + 'M' : A >= 1e5 ? +(v / 1e3).toFixed(1) + 'K' : fmt(v); };
const cvS = v => `<span class="cv">${COIN}<span>${fmtS(v)}</span></span>`;
const cv = v => `<span class="cv">${COIN}<span>${fmt(v)}</span></span>`;
const IC = {
  mines: '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="14" r="7" fill="currentColor"/><path d="M14.5 8.5l3-3" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><circle cx="19.5" cy="3.8" r="1.8" fill="currentColor"/></svg>',
  cases: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 8.5l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8.5l9 5 9-5M12 13.5v8"/></svg>',
  swords: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 17.5L3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2M9.5 17.5L21 6V3h-3L6.5 14.5M11 19l-6-6M8 16l-4 4M5 21l-2-2"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>',
  back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M4 5h16v11H9l-5 4z"/></svg>',
  send: '<svg viewBox="0 0 24 24"><path d="M3 11.5L21 4l-7.5 18-2.5-7.5z" fill="currentColor"/></svg>',
  cards: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linejoin="round"><rect x="3" y="6" width="11" height="15" rx="2" transform="rotate(-10 8.5 13.5)"/><rect x="10" y="4" width="11" height="15" rx="2" fill="currentColor" fill-opacity=".25"/></svg>',
  hit: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="3" width="12" height="17" rx="2.5" transform="rotate(-12 11 11.5)"/><path d="M14 15h7M17.5 11.5v7" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>',
  stand: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 11V5.5a1.5 1.5 0 0 1 3 0V10V4a1.5 1.5 0 0 1 3 0v6V5a1.5 1.5 0 0 1 3 0v6.5V8a1.5 1.5 0 0 1 3 0v7c0 4-3 7-7 7h-1c-2.5 0-4-1-5.5-3L3.6 14.4a1.6 1.6 0 0 1 2.5-2z"/></svg>',
  split: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="2.5" y="5" width="9" height="14" rx="2" opacity=".55"/><rect x="12.5" y="5" width="9" height="14" rx="2"/></svg>',
  dbl: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="currentColor"/><text x="12" y="16" text-anchor="middle" font-size="10" font-weight="900" fill="#0d0f13" font-family="Inter,Arial">×2</text></svg>',
  trophy: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 3h10v3h3.5v2.5A4.5 4.5 0 0 1 16.4 13 5.5 5.5 0 0 1 13 15.8V18h3v3H8v-3h3v-2.2A5.5 5.5 0 0 1 7.6 13 4.5 4.5 0 0 1 3.5 8.5V6H7zm10 5v3a2.4 2.4 0 0 0 1.5-2.2V8zM7 8H5.5v.8A2.4 2.4 0 0 0 7 11z"/></svg>',
  crown: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 7l4.5 4L12 4l4.5 7L21 7l-2 11H5z"/></svg>',
  gift: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="9" width="18" height="4" rx="1"/><rect x="4.5" y="13" width="15" height="8" rx="1"/><rect x="11" y="9" width="2" height="12" fill="#0d0f13"/><path d="M12 9C10 5 6.5 4.5 6.2 6.6 6 8.2 9 8.8 12 9zM12 9c2-4 5.5-4.5 5.8-2.4.2 1.6-2.8 2.2-5.8 2.4z"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" stroke="currentColor" stroke-width="2.4" fill="none"/></svg>',
  up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 16V8M8.5 11.5L12 8l3.5 3.5"/></svg>',
  pad: '<svg viewBox="0 0 24 24"><path d="M7 6.5h10a5 5 0 0 1 4.9 6l-.8 3.6a2.6 2.6 0 0 1-4.4 1.2L14.4 15H9.6l-2.3 2.3a2.6 2.6 0 0 1-4.4-1.2l-.8-3.6A5 5 0 0 1 7 6.5z" fill="currentColor"/><path d="M7.3 9.6v4.2M5.2 11.7h4.2" stroke="#0d0f13" stroke-width="1.9" stroke-linecap="round"/><circle cx="16.2" cy="10.4" r="1.3" fill="#0d0f13"/><circle cx="18.4" cy="12.8" r="1.3" fill="#0d0f13"/></svg>',
  chev: '<svg class="chev" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  bot: '<svg viewBox="0 0 24 24"><rect x="4" y="8" width="16" height="12" rx="4" fill="currentColor"/><circle cx="9.5" cy="14" r="1.7" fill="#0d0f13"/><circle cx="14.5" cy="14" r="1.7" fill="#0d0f13"/><path d="M12 3.5V8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="3.5" r="1.6" fill="currentColor"/></svg>'
};
/* every player's character: a blocky avatar with bacon-style hair (an original drawing) */
const BACON = '<img src="assets/bacon.png" alt="" draggable="false">';
document.querySelectorAll('[data-coin]').forEach(e => e.outerHTML = COIN);

document.querySelectorAll('[data-ic]').forEach(e => e.outerHTML = IC[e.dataset.ic]);
$('authAv').innerHTML = BACON;
let toastT;
/* ---------- sound effects (synthesised in the browser, no files) ---------- */
const SFX = (() => {
  let ctx = null, out = null, verb = null;
  function ac() {
    if (!ctx) {
      try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; }
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 4; comp.connect(ctx.destination);
      out = ctx.createGain(); out.gain.value = .55; out.connect(comp);
      verb = ctx.createGain(); verb.gain.value = .22;   // small room tail
      [0.031, 0.047].forEach((t, k) => { const d = ctx.createDelay(); d.delayTime.value = t; const fb = ctx.createGain(); fb.gain.value = .35; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3200 - k * 800; verb.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(out); });
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(f, d, { type = 'sine', vol = .2, at = 0, to = null, attack = .005, wet = .3 } = {}) {
    const c = ac(); if (!c) return;
    const t = c.currentTime + at, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(out); if (wet) { const w = c.createGain(); w.gain.value = wet; g.connect(w); w.connect(verb); }
    o.start(t); o.stop(t + d + .05);
  }
  function noise(d, { vol = .15, at = 0, f = 1400, type = 'lowpass', q = .7, to = null } = {}) {
    const c = ac(); if (!c) return;
    const b = c.createBuffer(1, Math.max(1, Math.floor(c.sampleRate * d)), c.sampleRate), x = b.getChannelData(0); for (let i = 0; i < x.length; i++) x[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource(), g = c.createGain(), fl = c.createBiquadFilter(), t = c.currentTime + at;
    fl.type = type; fl.Q.value = q; fl.frequency.setValueAtTime(f, t); if (to) fl.frequency.exponentialRampToValueAtTime(to, t + d);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    s.buffer = b; s.connect(fl); fl.connect(g); g.connect(out); s.start(t);
  }
  const chord = (fs, d, o = {}) => fs.forEach((f, i) => tone(f, d, { ...o, at: (o.at || 0) + i * (o.step || 0) }));
  let spinT = [];
  const clear = () => { spinT.forEach(clearTimeout); spinT = []; };
  return {
    tick(p = 1) { noise(.03, { vol: .22, f: 2600 * p, type: 'bandpass', q: 6 }); tone(1900 * p, .025, { type: 'triangle', vol: .05, wet: 0 }); },
    spin(ms) {
      clear(); if (ms < 300) return;
      let t = 0, gap = 42; while (t < ms - 120) { const r = t / ms; spinT.push(setTimeout(() => this.tick(1 - r * .25), t)); t += gap; gap = Math.min(420, gap * 1.07); }
      spinT.push(setTimeout(() => this.land(), ms));
    },
    land() { noise(.08, { vol: .25, f: 900, q: 2 }); tone(220, .12, { vol: .1, wet: .2 }); },
    stop: clear,
    upgrade(ms) {   // rising whoosh + tension hum, electric ticks, heartbeat at the end
      clear(); if (!ac()) return;
      noise(ms / 1000 * .55, { vol: .12, f: 400, to: 3500, type: 'bandpass', q: 1.2 });
      tone(90, ms / 1000, { type: 'sawtooth', vol: .05, to: 300, attack: .3, wet: .1 });
      tone(180, ms / 1000, { vol: .07, to: 720, attack: .3, wet: .2 });
      let t = 0, gap = 70; while (t < ms - 200) { const r = t / ms; spinT.push(setTimeout(() => tone(700 + r * 900, .04, { type: 'square', vol: .03, wet: 0 }), t)); t += gap; gap = Math.min(520, gap * 1.11); }
      [ms - 900, ms - 450].forEach(at => at > 0 && spinT.push(setTimeout(() => { tone(70, .18, { vol: .3, to: 45, wet: 0 }); tone(70, .14, { vol: .2, to: 45, at: .16, wet: 0 }); }, at)));
    },
    upWin() { clear(); tone(300, .5, { type: 'sawtooth', vol: .06, to: 1500 }); chord([784, 988, 1175, 1568], .7, { type: 'triangle', vol: .12, step: .06, at: .3 }); noise(.6, { vol: .08, f: 6000, type: 'highpass', at: .3 }); },
    upLose() { clear(); tone(440, .5, { type: 'triangle', vol: .12, to: 110, wet: .25 }); noise(.25, { vol: .12, f: 3000, to: 300, type: 'bandpass', q: 2 }); },
    win() { chord([659, 784, 988, 1319], .45, { type: 'triangle', vol: .11, step: .07 }); tone(2637, .5, { vol: .03, at: .28 }); },
    big() { chord([523, 659, 784, 1047, 1319, 1568], .6, { type: 'triangle', vol: .12, step: .07 }); chord([1047, 1319, 1568], 1.2, { vol: .05, at: .45 }); noise(1, { vol: .06, f: 7000, type: 'highpass', at: .4 }); },
    lose() { tone(392, .22, { type: 'triangle', vol: .1 }); tone(294, .38, { type: 'triangle', vol: .1, at: .14 }); },
    gem() { tone(1568, .25, { type: 'triangle', vol: .11 }); tone(2349, .35, { vol: .06, at: .05 }); },
    boom() { noise(.9, { vol: .5, f: 1800, to: 120 }); tone(110, .7, { vol: .45, to: 35, wet: .1 }); },
    card() { noise(.06, { vol: .3, f: 3500, to: 1200, type: 'bandpass', q: 1.5 }); },
    flip() { noise(.09, { vol: .25, f: 2500, to: 5000, type: 'bandpass', q: 1.2 }); },
    dice() { noise(1.1, { vol: .12, f: 300, to: 6000, type: 'bandpass', q: 1 }); tone(220, 1.1, { type: 'sawtooth', vol: .05, to: 880, attack: .2 }); chord([1047, 1319, 1568, 2093], .7, { type: 'triangle', vol: .1, step: .07, at: 1 }); },
  };
})();

/* winnings show as +amount next to your balance instead of a pop-up */
let balReady = false;
function winPop(n) {
  if (!(n > 0)) return;
  const w = document.querySelector('.wallet'); if (!w) return;
  const el = document.createElement('span'); el.className = 'winpop'; el.innerHTML = `+${COIN}${fmt(n)}`;
  w.appendChild(el); setTimeout(() => el.remove(), 2200);
  w.classList.remove('flash'); void w.offsetWidth; w.classList.add('flash');
  if (upSound) upSound = false; else if (n >= 5 * Math.max(1, lastBet)) SFX.big(); else SFX.win();
}
let lastBet = 0, upSound = false;
function losePop(n) {
  if (!(n > 0)) return;
  const w = document.querySelector('.wallet'); if (!w) return;
  const el = document.createElement('span'); el.className = 'winpop lose'; el.innerHTML = `−${COIN}${fmt(n)}`;
  w.appendChild(el); setTimeout(() => el.remove(), 2200);
  w.classList.remove('flash', 'flashl'); void w.offsetWidth; w.classList.add('flashl');
}
function toast(html, kind = '') {
  if (kind === 'lose') { SFX.lose(); if (/class="cv"/.test(html)) return; }
  if (kind === 'win' && /class="cv"/.test(html)) return;   // the +amount by the balance covers it
 const t = $('toast'); t.innerHTML = html; t.className = 'show ' + kind; clearTimeout(toastT); toastT = setTimeout(() => { t.className = kind; }, 3000); }
function gamesMenu(open) { $('gmenu').hidden = !open; $('gamesBtn').setAttribute('aria-expanded', open); }
const GAME_PAGES = ['mines', 'cases', 'battles', 'upgrader', 'blackjack'];
function nav(p) {
  document.querySelectorAll('#gmenu [data-p]').forEach(x => x.classList.toggle('on', x.dataset.p === p));
  $('gamesBtn').classList.toggle('on', GAME_PAGES.includes(p)); $('rewardsBtn').classList.toggle('on', p === 'rewards'); $('lbBtn').classList.toggle('on', p === 'leaderboard');
  if (p === 'leaderboard' && typeof loadLb === 'function') loadLb();
  if (p === 'rewards' && typeof renderRewards === 'function') { showRw(false); renderRewards(); }
  document.querySelectorAll('.page').forEach(x => x.classList.toggle('on', x.id === p));
  gamesMenu(false);
}
$('lbBtn').onclick = e => { e.stopPropagation(); nav('leaderboard'); };
$('rewardsBtn').onclick = e => { e.stopPropagation(); nav('rewards'); };
$('gamesBtn').onclick = e => { e.stopPropagation(); gamesMenu($('gmenu').hidden); };
document.querySelectorAll('#gmenu [data-p]').forEach(b => b.onclick = e => { e.stopPropagation(); nav(b.dataset.p); });
document.addEventListener('click', e => { if (!e.target.closest('.games')) gamesMenu(false); });
addEventListener('keydown', e => { if (e.key === 'Escape') gamesMenu(false); });

/* ---------- Supabase ---------- */
const configured = /^https:\/\//.test(SUPABASE_URL || '') && !/YOUR/.test(SUPABASE_URL) && SUPABASE_ANON_KEY && !/YOUR/.test(SUPABASE_ANON_KEY);
if (!configured) $('setup').hidden = false;
const sb = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }) : null;
const niceErr = e => {
  const m = String((e && e.message) || e || 'Something went wrong');
  if (/duplicate key|already registered|already been registered/i.test(m)) return /username/i.test(m) ? 'That username is taken' : 'An account with that email already exists';
  if (/Database error saving new user/i.test(m)) return 'That username is taken or not allowed';
  if (/Failed to fetch|NetworkError/i.test(m)) return "Can't reach the server. Check your connection";
  return m.replace(/^.*?ERROR:\s*/, '');
};
async function call(fn, args = {}) {
  if (!sb) throw new Error('The site is not set up yet');
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw new Error(niceErr(error));
  return data;
}

/* ---------- account ---------- */
let me = null;              // { id, username, coins, faucet_at }
let bal = 0;
function showBal(v) {
  if (v !== undefined && v !== null) {
    const nv = Number(v), d = nv - bal;
    if (balReady && me && d > 0) winPop(d); else if (me && d < 0) lastBet = -d;
    bal = nv; if (me) balReady = true;
  }
  $('bal').textContent = me ? fmt(bal) : '0';
}
async function refreshMe() {
  if (!sb) return;
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { me = null; showBal(0); renderAuth(); return; }
  try { const p = await call('my_profile'); me = p; if (p) { me.email = session.user && session.user.email; showBal(p.coins); } } catch (e) { me = null; }
  renderAuth(); renderChatInput(); lobbySig = ''; if (vs) vs.sig = '';
}
function requireAuth() { if (me) return true; openAuth(sb ? 'signup' : null); return false; }
function renderAuth() {
  const a = $('auth');
  if (me) {
    a.innerHTML = `<div class="me-chip" id="meChip" tabindex="0" role="button" aria-haspopup="menu"><span class="av bacon">${BACON}</span><span class="nm"></span>${lvlBadge(levelInfo(PW[me.id] || 0).level)}${IC.chev}</div>`;
    a.querySelector('.nm').textContent = me.username;
    $('meChip').onclick = e => {
      e.stopPropagation(); const m = $('meMenu'); if (m) { m.remove(); return; }
      $('meChip').insertAdjacentHTML('beforeend', '<div class="menu" id="meMenu" role="menu"><button data-a="profile">Profile</button>' + (me.admin ? '<button data-a="admin">Admin</button>' : '') + '<button data-a="out">Sign out</button></div>');
      $('meMenu').onclick = async ev => {
        ev.stopPropagation(); const b = ev.target.closest('[data-a]'); if (!b) return; $('meMenu').remove();
        if (b.dataset.a === 'profile') openMyProfile();
        else if (b.dataset.a === 'admin') { nav('admin'); loadAdmin(); }
        else { await sb.auth.signOut(); toast('Signed out'); }
      };
    };
  } else a.innerHTML = '<button class="btn gold signin" id="signBtn">Sign in</button>';
  if ($('signBtn')) $('signBtn').onclick = () => openAuth('login');
  showBal();
}
document.addEventListener('click', () => { const m = $('meMenu'); if (m) m.remove(); });

const VIEWS = { signup: 'fSignup', login: 'fLogin', forgot: 'fForgot', reset: 'fReset', sent: 'fSent' };
const TITLES = { signup: 'Create your account', login: 'Welcome back', forgot: 'Reset your password', reset: 'Set a new password', sent: 'Check your email' };
let lastEmail = '';
function openAuth(view) {
  if (!sb) { $('setup').hidden = false; return; }
  view = view || 'signup';
  Object.entries(VIEWS).forEach(([k, id]) => $(id).hidden = k !== view);
  $('authTabs').hidden = !(view === 'signup' || view === 'login');
  document.querySelectorAll('#authTabs button').forEach(b => b.classList.toggle('on', b.dataset.v === view));
  $('authTitle').textContent = TITLES[view]; $('authErr').textContent = '';
  $('authModal').hidden = false;
  const first = $(VIEWS[view]).querySelector('input'); if (first) setTimeout(() => first.focus(), 30);
}
function closeAuth() { $('authModal').hidden = true; }
function sent(msg, canResend) { openAuth('sent'); $('sentMsg').textContent = msg; $('resend').hidden = !canResend; }
const authErr = m => { $('authErr').textContent = m; };
function busyBtn(btn, on, label) { btn.disabled = on; if (label) btn.textContent = on ? 'Please wait…' : label; }
$('authTabs').onclick = e => { const b = e.target.closest('[data-v]'); if (b) openAuth(b.dataset.v); };
$('authClose').onclick = closeAuth;
$('authModal').onclick = e => { if (e.target === $('authModal')) closeAuth(); };
$('toForgot').onclick = () => { openAuth('forgot'); $('fpEmail').value = $('liEmail').value; };
$('backLogin').onclick = () => openAuth('login');
$('sentOk').onclick = closeAuth;
addEventListener('keydown', e => { if (e.key === 'Escape') { closeAuth(); $('nameModal').hidden = true; } });
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

$('fSignup').onsubmit = async e => {
  e.preventDefault(); authErr('');
  const name = $('suName').value.trim(), email = $('suEmail').value.trim(), pass = $('suPass').value;
  if (!/^[A-Za-z0-9_]{2,20}$/.test(name)) return authErr('Username: 2 to 20 letters, numbers or underscores.');
  if (!emailOk(email)) return authErr('Enter a valid email address.');
  if (pass.length < 8) return authErr('Password must be at least 8 characters.');
  if (!$('suAge').checked) return authErr('Please confirm you are 13 or older.');
  busyBtn($('suGo'), true, 'Create account');
  try {
    const free = await call('username_available', { p_name: name });
    if (!free) { busyBtn($('suGo'), false, 'Create account'); return authErr('That username is taken. Try another.'); }
    const { data, error } = await sb.auth.signUp({ email, password: pass, options: { data: { username: name }, emailRedirectTo: location.origin + location.pathname } });
    if (error) throw error;
    if (data && data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) throw new Error('An account with that email already exists. Try logging in.');
    lastEmail = email;
    if (data.session) { closeAuth(); toast(`Welcome, <b>${esc(name)}</b>! You start with ${cv(60000)}`, 'win'); }
    else sent(`We sent a confirmation link to ${email}. Click it to finish creating your account, then come back here.`, true);
  } catch (err) { authErr(niceErr(err)); }
  busyBtn($('suGo'), false, 'Create account');
};
$('fLogin').onsubmit = async e => {
  e.preventDefault(); authErr('');
  const email = $('liEmail').value.trim(), pass = $('liPass').value;
  if (!emailOk(email) || !pass) return authErr('Enter your email and password.');
  busyBtn($('liGo'), true, 'Log in');
  const { error } = await sb.auth.signInWithPassword({ email, password: pass });
  busyBtn($('liGo'), false, 'Log in');
  if (error) {
    lastEmail = email;
    if (/confirm/i.test(error.message)) return sent(`Confirm your email first. We sent a link to ${email}.`, true);
    return authErr(/invalid/i.test(error.message) ? 'Wrong email or password.' : niceErr(error));
  }
  closeAuth(); $('liPass').value = '';
};
$('fForgot').onsubmit = async e => {
  e.preventDefault(); authErr('');
  const email = $('fpEmail').value.trim(); if (!emailOk(email)) return authErr('Enter a valid email address.');
  busyBtn($('fpGo'), true, 'Send reset link');
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
  busyBtn($('fpGo'), false, 'Send reset link');
  if (error) return authErr(niceErr(error));
  sent(`If an account uses ${email}, a password reset link is on its way.`, false);
};
$('fReset').onsubmit = async e => {
  e.preventDefault(); authErr('');
  const pass = $('rpPass').value; if (pass.length < 8) return authErr('Password must be at least 8 characters.');
  busyBtn($('rpGo'), true, 'Save new password');
  const { error } = await sb.auth.updateUser({ password: pass });
  busyBtn($('rpGo'), false, 'Save new password');
  if (error) return authErr(niceErr(error));
  closeAuth(); toast('Password updated', 'win');
};
$('resend').onclick = async () => {
  if (!lastEmail) return;
  const { error } = await sb.auth.resend({ type: 'signup', email: lastEmail, options: { emailRedirectTo: location.origin + location.pathname } });
  toast(error ? niceErr(error) : 'Confirmation email sent again', error ? 'lose' : 'win');
};
$('nameForm').onsubmit = async e => {
  e.preventDefault();
  const n = $('nmInput').value.trim();
  if (!/^[A-Za-z0-9_]{2,20}$/.test(n)) return $('nmErr').textContent = 'Use 2 to 20 letters, numbers or underscores.';
  $('nmGo').disabled = true;
  try { await call('set_username', { p_name: n }); me.username = n; PN[me.id] = n; namesVer++; renderAuth(); if (myProf) { myProf.username = n; renderProfilePage(); } $('nameModal').hidden = true; toast(`You're now <b>${esc(n)}</b>`, 'win'); }
  catch (err) { $('nmErr').textContent = niceErr(err); }
  $('nmGo').disabled = false;
};
$('nmCancel').onclick = () => { $('nameModal').hidden = true; };

/* ---------- faucet ---------- */
$('faucet').onclick = async () => {
  if (!requireAuth()) return;
  try {
    const r = await call('claim_faucet');
    if (r.ok) { showBal(r.coins); bumpMe(); toast(`+${cv(r.amount)} free coins`, 'win'); }
    else toast(`Free coins again in ${r.wait}s`);
  } catch (e) { toast(niceErr(e), 'lose'); }
};

/* ---------- item art: original SVG icons drawn in-page ---------- */
const SV=b=>`<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><ellipse cx="32" cy="59" rx="20" ry="3.5" fill="#000" opacity=".3"/>${b}</svg>`;
const MIR=b=>`${b}<g transform="matrix(-1 0 0 1 64 0)">${b}</g>`;
const star=(x,y,r,c)=>`<path d="M${x} ${y-r}Q${x} ${y} ${x+r} ${y}Q${x} ${y} ${x} ${y+r}Q${x} ${y} ${x-r} ${y}Q${x} ${y} ${x} ${y-r}Z" fill="${c}"/>`;
const shine=(d)=>`<path d="${d}" stroke="#fff" stroke-opacity=".45" stroke-width="3" fill="none" stroke-linecap="round"/>`;
const ART={
 coins:()=>SV(`<ellipse cx="32" cy="50" rx="22" ry="7" fill="#9a6a06"/><ellipse cx="32" cy="46" rx="22" ry="7" fill="#e0a412"/><ellipse cx="32" cy="45" rx="22" ry="7" fill="#f7c948"/>
  <ellipse cx="25" cy="37" rx="16" ry="5.5" fill="#9a6a06"/><ellipse cx="25" cy="33" rx="16" ry="5.5" fill="#e0a412"/><ellipse cx="25" cy="32" rx="16" ry="5.5" fill="#ffd95e"/>
  <ellipse cx="38" cy="24" rx="13" ry="4.5" fill="#9a6a06"/><ellipse cx="38" cy="21" rx="13" ry="4.5" fill="#e0a412"/><ellipse cx="38" cy="20" rx="13" ry="4.5" fill="#ffe27a"/>
  <path d="M48 8l1.4 3.4 3.6 1.4-3.6 1.4L48 18l-1.4-3.8-3.6-1.4 3.6-1.4z" fill="#fff"/>`),
 pumpkin:c=>SV(`<path d="M31 16c0-5 3-9 8-10" stroke="#3d7a2a" stroke-width="4" fill="none" stroke-linecap="round"/>
  <ellipse cx="21" cy="37" rx="13" ry="18" fill="${c}"/><ellipse cx="43" cy="37" rx="13" ry="18" fill="${c}"/>
  <ellipse cx="32" cy="37" rx="12" ry="19" fill="${c}"/><ellipse cx="32" cy="37" rx="12" ry="19" fill="#fff" opacity=".12"/>
  <path d="M19 33l6-7 5 7zM34 33l5-7 6 7zM18 41q14 13 28 0q-14 5-28 0z" fill="#2a1200"/>`),
 helm:(c,w)=>SV(`${w?MIR(`<path d="M15 38C5 32 2 18 6 8c3 9 8 14 15 17z" fill="${w}"/><path d="M8 14c2 6 5 10 10 13" stroke="#000" stroke-opacity=".15" stroke-width="2" fill="none"/>`):''}
  <path d="M12 46a20 24 0 0 1 40 0v8H12z" fill="${c}"/>${shine('M18 32a16 16 0 0 1 13-10')}
  <rect x="17" y="40" width="30" height="6" rx="3" fill="#0c0f1c" opacity=".75"/>
  <rect x="12" y="50" width="40" height="4" rx="2" fill="#000" opacity=".22"/>`),
 crown:(c,g)=>SV(`<path d="M10 50L8 20l12 12 12-18 12 18 12-12-2 30z" fill="${c}"/>
  <rect x="9" y="44" width="46" height="8" rx="2" fill="${c}"/><rect x="9" y="48" width="46" height="4" rx="2" fill="#000" opacity=".2"/>
  <circle cx="8" cy="19" r="3" fill="${g}"/><circle cx="32" cy="13" r="3.5" fill="${g}"/><circle cx="56" cy="19" r="3" fill="${g}"/>
  <circle cx="32" cy="38" r="4" fill="${g}"/><circle cx="20" cy="40" r="2.5" fill="${g}"/><circle cx="44" cy="40" r="2.5" fill="${g}"/>`),
 shades:(c,l)=>SV(`<path d="M4 27h56" stroke="${c}" stroke-width="4" stroke-linecap="round"/>
  ${MIR(`<path d="M7 25h22v6c0 8-4 11-11 11S7 38 7 31z" fill="${l}" stroke="${c}" stroke-width="2.5"/><path d="M12 29l5-3" stroke="#fff" stroke-opacity=".6" stroke-width="2.5" stroke-linecap="round"/>`)}`),
 phones:(c,p)=>SV(`<path d="M14 40V30a18 18 0 0 1 36 0v10" stroke="${c}" stroke-width="6" fill="none"/>
  ${MIR(`<rect x="7" y="32" width="15" height="22" rx="6" fill="${c}"/><rect x="18" y="35" width="5" height="16" rx="2" fill="${p}"/><circle cx="14" cy="43" r="4.5" fill="none" stroke="${p}" stroke-width="3" stroke-dasharray="2.2 1.6"/>`)}
  ${shine('M20 22a16 16 0 0 1 10-5')}`),
 face:c=>SV(`<circle cx="32" cy="32" r="24" fill="${c}"/><path d="M8 34a24 24 0 0 0 48 0a24 20 0 0 1-48 0z" fill="#000" opacity=".1"/>
  <path d="M19 26q4-5 8 0M37 26q4-5 8 0" stroke="#2a1d00" stroke-width="3.5" fill="none" stroke-linecap="round"/>
  <path d="M15 34h34q-2 16-17 16T15 34z" fill="#2a1d00"/><path d="M20 35h24v4H20z" fill="#fff"/><path d="M25 46q7 4 14 0q-7-5-14 0z" fill="#ff6b7a"/>
  ${shine('M16 22a18 18 0 0 1 10-9')}`),
 bighead:c=>SV(`<rect x="27" y="46" width="10" height="10" rx="3" fill="${c}"/><circle cx="32" cy="27" r="23" fill="${c}"/><path d="M9 29a23 23 0 0 0 46 0a23 19 0 0 1-46 0z" fill="#000" opacity=".1"/>
  <ellipse cx="24" cy="25" rx="3" ry="4" fill="#1d1d24"/><ellipse cx="40" cy="25" rx="3" ry="4" fill="#1d1d24"/>
  <path d="M25 35q7 5 14 0" stroke="#1d1d24" stroke-width="3" fill="none" stroke-linecap="round"/>${shine('M16 18a20 20 0 0 1 10-10')}`),
 antlers:c=>SV(`${MIR(`<path d="M27 52C24 40 18 30 12 12M17 27L7 23M14 19l5-10M21 36l-12 2" stroke="${c}" stroke-width="5" fill="none" stroke-linecap="round"/>`)}
  <rect x="20" y="48" width="24" height="7" rx="3.5" fill="#5a3a20"/>`),
 fedora:(c,b,s)=>SV(`<ellipse cx="32" cy="46" rx="28" ry="8" fill="${c}"/><ellipse cx="32" cy="48" rx="28" ry="6" fill="#000" opacity=".2"/>
  <path d="M16 46c0-18 4-28 16-28s16 10 16 28z" fill="${c}"/><path d="M25 19q7 7 14 0" stroke="#000" stroke-opacity=".25" stroke-width="3" fill="none"/>
  <rect x="16" y="37" width="32" height="6" fill="${b}"/>${shine('M21 33c0-6 2-10 6-12')}
  ${s?star(12,16,6,s)+star(52,24,4.5,s)+star(46,9,3,s):''}`),
 tophat:(c,b)=>SV(`<ellipse cx="32" cy="48" rx="27" ry="7" fill="${c}"/><rect x="17" y="10" width="30" height="38" rx="3" fill="${c}"/>
  <ellipse cx="32" cy="10" rx="15" ry="3" fill="#fff" opacity=".12"/><rect x="17" y="36" width="30" height="7" fill="${b}"/>
  <rect x="41" y="10" width="6" height="38" fill="#000" opacity=".2"/>${shine('M22 16v14')}`),
 vampire:()=>SV(`${MIR(`<path d="M32 56L4 56 8 30l14 12z" fill="#b3122e"/>`)}<path d="M18 54h28l-4-10H22z" fill="#25131f"/>
  <ellipse cx="32" cy="30" rx="15" ry="18" fill="#efe3f2"/>
  <path d="M17 28c-2-14 6-20 15-20s17 6 15 20c-4-4-8-9-15-5-7-4-11 1-15 5z" fill="#25131f"/>
  <ellipse cx="26" cy="30" rx="2.8" ry="3.2" fill="#d4183a"/><ellipse cx="38" cy="30" rx="2.8" ry="3.2" fill="#d4183a"/>
  <path d="M25 39q7 5 14 0" stroke="#25131f" stroke-width="2.5" fill="none" stroke-linecap="round"/>
  <path d="M28 40l1.5 5 1.5-4zM33 41l1.5 4 1.5-5z" fill="#fff"/>`),
 horns:(c,g)=>SV(`<ellipse cx="32" cy="44" rx="26" ry="14" fill="${g}" opacity=".25"/>
  ${MIR(`<path d="M27 50C14 47 5 34 9 10c4 15 10 23 21 28z" fill="${c}"/><path d="M12 22c2 9 6 15 13 19" stroke="#fff" stroke-opacity=".4" stroke-width="2.5" fill="none" stroke-linecap="round"/>`)}
  <rect x="17" y="46" width="30" height="8" rx="4" fill="#2a2d3d"/>${star(10,8,4,g)+star(54,8,4,g)}`),
 hood:(c,t,e)=>SV(`<path d="M32 5C14 9 8 30 10 56h44c2-26-4-47-22-51z" fill="${c}"/>
  <path d="M32 5C20 8 14 22 13 40" stroke="#fff" stroke-opacity=".3" stroke-width="3" fill="none" stroke-linecap="round"/>
  <path d="M54 56c1-20-3-40-16-48 8 12 10 28 9 48z" fill="#000" opacity=".2"/>
  <path d="M32 19c-10 2-12 14-10 30h20c2-16 0-28-10-30z" fill="#07080f" stroke="${t}" stroke-width="3"/>
  <ellipse cx="27" cy="32" rx="3" ry="2" fill="${e}"/><ellipse cx="37" cy="32" rx="3" ry="2" fill="${e}"/>
  <ellipse cx="32" cy="32" rx="10" ry="5" fill="${e}" opacity=".15"/>`)
};


/* ---------- cases & items (loaded from the database) ---------- */
const RC = { common: '#9aa3b8', uncommon: '#3ee8a8', rare: '#5b8cff', epic: '#a66bff', legendary: '#f7c948' };
let CASES = [];
const artFrom = spec => { const [fn, ...args] = String(spec).split(':'); return (ART[fn] || ART.bighead)(...(fn in ART ? args : ['#9aa3b8'])); };
const caseById = id => CASES.find(c => c.id === id);
function pick(c) { let t = Math.random() * c.tot; for (const it of c.items) { t -= it.w; if (t <= 0) return it; } return c.items[c.items.length - 1]; }
const pic = it => it.img ? `<img src="${esc(it.img)}" alt="">` : it.art;
/* a case's own picture (falls back to its best item) */
const cpic = c => c.image ? `<img src="${esc(c.image)}" alt="" class="cimg">` : pic(c.top);
const onSale = () => CASES.filter(c => c.active);
/* gold dice: the case's top pulls hide behind it on the spinner */
const DICE = { dice: true, n: 'Top pull', r: 'legendary', v: 0 };
const DICE_ART = '<img src="assets/dice-top.webp" alt="" class="dicei">';
const shown = it => it && it.top ? DICE : it;
function pickTop(c) { let t = Math.random() * c.ttot; for (const it of c.tops) { t -= it.w; if (t <= 0) return it; } return c.tops[c.tops.length - 1]; }
const reelSet = c => { const s = c.items.filter(it => !it.top); if (c.tops && c.tops.length) s.splice(Math.floor(s.length / 2), 0, DICE); return s; };
async function loadCases() {
  if (!sb) return;
  const [c, i] = await Promise.all([
    sb.from('cases').select('id,name,price,sort,image,active').order('sort'),
    sb.from('case_items').select('case_id,idx,name,value,rarity,weight,catalog_id,art,top').order('idx')
  ]);
  if (c.error || i.error) { $('caseGrid').innerHTML = '<div class="loading">Could not load cases. Refresh to try again.</div>'; return; }
  CASES = c.data.map(x => {
    const items = i.data.filter(y => y.case_id === x.id).sort((a, b) => a.idx - b.idx)
      .map(y => ({ idx: y.idx, n: y.name, v: Number(y.value), r: y.rarity, w: y.weight, id: Number(y.catalog_id) || 0, art: artFrom(y.art), img: null, top: !!y.top }));
    const tops = items.filter(it => it.top), best = items.reduce((m, it) => it.v > m.v ? it : m, items[0]);
    return { id: x.id, name: x.name, price: Number(x.price), items, tot: items.reduce((s, it) => s + it.w, 0), top: best, tops, ttot: tops.reduce((s, it) => s + it.w, 0), image: x.image || null, active: x.active !== false };
  });
  renderCaseGrid(); loadThumbs();
}
/* real item pictures by Roblox catalog ID; falls back to the drawings if unavailable */
async function loadThumbs() {
  const all = CASES.flatMap(c => c.items).filter(i => i.id > 0);
  if (!all.length) return;
  await thumbsFor(all);
  renderCaseGrid(); if (cur && !spinning) openCase(cur.id);
  if (vs && BT[vs.id]) { vs.sig = ''; tickView(true); }
}

/* ---------- cases page ---------- */
const hcard = it => it.dice ? `<div class="hc dice" style="--rc:${RC.legendary}"><span class="art">${DICE_ART}</span><span>Top pull</span><em>Gold dice</em></div>`
  : `<div class="hc ${it.top ? 'tp' : ''}" style="--rc:${RC[it.r]}"><span class="art">${pic(it)}</span><span>${esc(it.n)}</span>${cv(it.v)}</div>`;
let cur = null, spinning = false;
function renderCaseGrid() {
  $('caseGrid').innerHTML = CASES.length ? onSale().map(c => `<button class="ccard" data-case="${c.id}" style="--g:${RC[c.top.r]}"><span class="art">${cpic(c)}</span><b>${esc(c.name)}</b><span class="meta">${c.items.length} items · top ${cv(c.top.v)}</span><span class="price">${cv(c.price)}</span>${volBar(c)}</button>`).join('')
    : `<div class="loading">${sb ? 'Loading cases…' : 'Cases appear once the site is connected to Supabase.'}</div>`;
}
$('caseGrid').onclick = e => { const t = e.target.closest('[data-case]'); if (t) openCase(t.dataset.case); };
function idleH(reel, c) { reel.style.transition = 'none'; reel.style.transform = 'translateX(0)'; reel.parentElement.classList.remove('goldmode'); const s = reelSet(c); reel.innerHTML = s.concat(s, s).map(hcard).join(''); }
async function hspin(reel, c, winner, dur) {
  const box = reel.parentElement; box.classList.remove('goldmode');
  if (!winner.top) return hroll(reel, () => shown(pick(c)), winner, dur);
  await hroll(reel, () => shown(pick(c)), DICE, dur - 900);
  await flare(reel.children[50], box);
  box.classList.add('goldmode');
  await hroll(reel, () => pickTop(c), winner, 3800);
  reel.children[50].classList.add('jack'); confetti(false);
}
function hroll(reel, fill, winner, dur) {
  SFX.spin(dur - 450);
  const N = 60, W = 50; let h = ''; for (let i = 0; i < N; i++) h += hcard(i === W ? winner : fill()); reel.innerHTML = h;
  reel.style.transition = 'none'; reel.style.transform = 'translateX(0)'; void reel.offsetWidth;
  const box = reel.parentElement.clientWidth, x0 = 12 + W * 162 + 75 - box / 2, off = (Math.random() < .5 ? -1 : 1) * (20 + Math.random() * 45), run = dur - 500;
  reel.style.transition = `transform ${run}ms cubic-bezier(.1,.75,.15,1)`; reel.style.transform = `translateX(${-(x0 + off)}px)`;
  setTimeout(() => { reel.style.transition = 'transform .45s cubic-bezier(.3,1.35,.5,1)'; reel.style.transform = `translateX(${-x0}px)`; reel.children[W].classList.add('won'); }, run + 40);
  return sleep(dur + 150);
}
/* the gold dice bursts and spins before the top-pull respin */
function flare(card, box, ms = 1500) {
  if (!card) return sleep(ms);
  card.classList.add('flare'); box.classList.add('flaring'); if (!box.querySelector('#vr1') || box.querySelector('#vr0')) SFX.dice();
  const fx = document.createElement('div'); fx.className = 'dflare'; fx.innerHTML = '<i class="rays"></i><i class="dfr"></i><i class="dfr r2"></i>' + Array.from({ length: 14 }, (_, k) => `<b style="--a:${k * 360 / 14}deg;--d:${(k % 3) * 60}ms"></b>`).join('') + DICE_ART;
  card.appendChild(fx);
  return sleep(ms).then(() => { box.classList.remove('flaring'); });
}
function openCase(id) {
  cur = caseById(id); if (!cur) return;
  $('caseList').hidden = true; $('caseView').hidden = false;
  $('cvIcon').innerHTML = cpic(cur); $('cvName').textContent = cur.name;
  $('cvMeta').textContent = `${cur.items.length} items` + (cur.tops.length ? ` · gold dice ${(cur.ttot / cur.tot * 100).toFixed(2)}%` : '');
  $('cvOpen').innerHTML = `Open for ${cv(cur.price)}`;
  $('cvItems').innerHTML = cur.items.slice().sort((a, b) => b.v - a.v).map(i => `<div class="ic2 ${i.top ? 'tp' : ''}" style="--rc:${RC[i.r]}">${i.top ? '<span class="tpb" title="Behind the gold dice">' + DICE_ART + '</span>' : ''}<span class="odds">${(i.w / cur.tot * 100).toFixed(2)}%</span><span class="art">${pic(i)}</span><b>${esc(i.n)}</b>${cv(i.v)}</div>`).join('');
  idleH($('cvReel'), cur);
}
$('cvBack').onclick = () => { if (spinning) return; $('caseView').hidden = true; $('caseList').hidden = false; };
$('cvOpen').onclick = async () => {
  if (spinning || !requireAuth()) return;
  if (bal < cur.price) return toast('Not enough coins. Tap + for free coins', 'lose');
  spinning = true; $('cvOpen').disabled = true; $('cvBack').disabled = true;
  try {
    const r = await call('open_case', { p_case: cur.id });
    showBal(bal - cur.price);
    const w = cur.items.find(i => i.idx === r.idx) || cur.items[0];
    await hspin($('cvReel'), cur, w, 4600);
    showBal(r.coins); bumpMe();
    const p = r.value - r.price;
    if (p < 0) losePop(-p);
    toast(`${w.top ? '🎲 TOP PULL! ' : ''}You unboxed <b>${esc(w.n)}</b> ${cv(w.v)} <span class="mut">(${p >= 0 ? '+' : '−'}${fmt(Math.abs(p))})</span>`, p >= 0 ? 'win' : 'lose');
  } catch (e) { toast(niceErr(e), 'lose'); }
  spinning = false; $('cvOpen').disabled = false; $('cvBack').disabled = false;
};

/* ---------- mines (the server decides where mines are) ---------- */
const MARK = '<span class="mark" aria-hidden="true"></span>';
const GEM = '<svg class="ic" viewBox="0 0 64 64"><path d="M6 26L18 13H46L58 26L32 57Z" fill="#c98a0c"/><path d="M6 26L18 13L22 26Z" fill="#ffd955"/><path d="M18 13H32L22 26Z" fill="#fff0a6"/><path d="M32 13L22 26H42Z" fill="#ffe170"/><path d="M32 13H46L42 26Z" fill="#ffeb94"/><path d="M46 13L58 26H42Z" fill="#f6c432"/><path d="M6 26H22L32 57Z" fill="#f0b21c"/><path d="M22 26H42L32 57Z" fill="url(#gemMid)"/><path d="M42 26H58L32 57Z" fill="#d6950b"/><path d="M6 26L18 13H46L58 26L32 57Z" fill="none" stroke="#a56f05" stroke-width="1.6" stroke-linejoin="round"/><path d="M21 17l-5 6" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".85"/><path d="M50 9l1.3 3 3 1.3-3 1.3L50 18l-1.3-3.4-3-1.3 3-1.3z" fill="#fff"/></svg>';
const BOMB = '<svg class="ic" viewBox="0 0 64 64"><path d="M40 16c4-6 9-8 13-5" stroke="#8a5a2b" stroke-width="3.2" fill="none" stroke-linecap="round"/><path d="M53 3c4 3 5 7 2 11-2 2-6 2-7-1-1-2 1-3 1-5 2 1 3 0 4-5z" fill="#ff4b2b"/><path d="M53 8c2 2 2 4 1 6-1 1-3 1-3-1 0-1 1-2 2-5z" fill="#ffc53a"/><g transform="rotate(40 41 20)"><rect x="34" y="14" width="14" height="10" rx="3" fill="#3b3f9e"/><rect x="34" y="14" width="14" height="4" rx="2" fill="#6b70e0"/></g><circle cx="29" cy="38" r="21" fill="url(#bombG)"/><circle cx="29" cy="38" r="21" fill="none" stroke="#1d1e5c" stroke-width="2"/><image href="assets/dice-white.png" x="18" y="27" width="22" height="22" opacity=".92" transform="rotate(-12 29 38)"/><ellipse cx="20" cy="28" rx="7" ry="4.5" fill="#fff" opacity=".45" transform="rotate(-35 20 28)"/></svg>';
const MN = { size: 25, m: 3, on: false, id: null, bet: 0, rev: new Set(), mode: 'manual', running: false, busy: false, tiles: [] };
function mult(k, m, N) { if (k === 0) return 1; let x = .95; for (let i = 0; i < k; i++) x *= (N - i) / (N - m - i); return x; }
function setRange(el) { el.style.setProperty('--p', ((el.value - el.min) / (el.max - el.min || 1) * 100) + '%'); }
function drawBoard() {
  const b = $('board'); b.style.setProperty('--n', Math.sqrt(MN.size)); b.innerHTML = ''; MN.tiles = [];
  for (let i = 0; i < MN.size; i++) { const t = document.createElement('button'); t.className = 'tile'; t.innerHTML = MARK; t.setAttribute('aria-label', 'Tile ' + (i + 1)); t.onclick = () => tap(i); b.appendChild(t); MN.tiles.push(t); }
  updM();
}
function readBet() {
  const bet = Math.round(+$('mBet').value);
  if (!(bet > 0)) { toast('Enter a bet amount', 'lose'); return null; }
  if (bet > bal) { toast('Not enough coins. Tap + for free coins', 'lose'); return null; }
  return bet;
}
async function startRound(bet) {
  MN.busy = true; updM();
  try {
    const r = await call('mines_start', { p_bet: bet, p_size: MN.size, p_mines: MN.m });
    Object.assign(MN, { on: true, id: r.id, bet: r.bet, rev: new Set() });
    MN.tiles.forEach(t => { t.className = 'tile'; t.innerHTML = MARK; });
    showBal(r.coins); bumpMe();
  } catch (e) { toast(niceErr(e), 'lose'); }
  MN.busy = false; updM(); return MN.on;
}
async function tap(i) {
  if (!MN.on || MN.busy || MN.rev.has(i)) return;
  const t = MN.tiles[i]; MN.busy = true; t.classList.add('pending');
  try {
    const r = await call('mines_reveal', { p_id: MN.id, p_tile: i });
    t.classList.remove('pending');
    if (r.result === 'mine') { SFX.boom(); t.className = 'tile bomb hit'; t.innerHTML = BOMB; endMines(r.mines); showBal(r.coins); losePop(MN.bet); toast(`Boom! Lost ${cv(MN.bet)}`, 'lose'); }
    else {
      MN.rev = new Set(r.revealed); t.className = 'tile gem pop'; t.innerHTML = GEM; SFX.gem();
      if (r.result === 'cashed') { endMines(r.mines); showBal(r.coins); toast(`Board cleared! ${cv(r.payout)}`, 'win'); }
    }
  } catch (e) { t.classList.remove('pending'); toast(niceErr(e), 'lose'); if (/No active game/.test(String(e.message))) { MN.on = false; } }
  MN.busy = false; updM();
}
function endMines(mines) {
  const set = new Set(mines || []);
  MN.on = false;
  MN.tiles.forEach((t, i) => { if (!MN.rev.has(i) && !t.classList.contains('hit')) { const b = set.has(i); t.className = 'tile dim ' + (b ? 'bomb' : 'gem'); t.innerHTML = b ? BOMB : GEM; } });
  updM();
}
async function cashMines() {
  if (!MN.on || MN.rev.size === 0 || MN.busy) return;
  MN.busy = true; updM();
  try { const r = await call('mines_cashout', { p_id: MN.id }); MN.busy = false; endMines(r.mines); showBal(r.coins); toast(`Cashed out ${cv(r.payout)} <span class="mut">(${Number(r.multiplier).toFixed(2)}×)</span>`, 'win'); }
  catch (e) { MN.busy = false; toast(niceErr(e), 'lose'); }
  updM();
}
function updM() {
  const N = MN.size, k = MN.rev.size, x = mult(k, MN.m, N), nx = k < N - MN.m ? mult(k + 1, MN.m, N) : null;
  const lock = MN.on || MN.running, bet = MN.on ? MN.bet : (Math.round(+$('mBet').value) || 0);
  $('board').classList.toggle('live', MN.on && !MN.busy);
  $('sMult').textContent = x.toFixed(2) + '×';
  $('sNext').textContent = nx ? nx.toFixed(2) + '×' : '0.00×';
  $('sProfitL').textContent = MN.on && k > 0 ? 'Profit if you cash out' : 'Profit on first gem';
  $('sProfit').innerHTML = cv(MN.on && k > 0 ? bet * x - bet : bet * mult(1, MN.m, N) - bet);
  ['mBet', 'mCount', 'aTiles', 'aCount'].forEach(id => $(id).disabled = lock);
  document.querySelectorAll('#mGrid button,#mMode button,.amt [data-b]').forEach(b => b.disabled = lock);
  const p = $('mPlay');
  if (MN.mode === 'auto') { p.className = 'btn big ' + (MN.running ? 'redb' : 'gold'); p.textContent = MN.running ? 'Stop autobet' : 'Start autobet'; p.disabled = false; }
  else if (MN.on) { p.className = 'btn big mint'; p.innerHTML = k ? `Cash out ${cv(bet * x)}` : 'Pick a tile'; p.disabled = k === 0 || MN.busy; }
  else { p.className = 'btn big gold'; p.textContent = 'Play'; p.disabled = MN.busy; }
  $('mRand').hidden = !(MN.mode === 'manual' && MN.on);
}
$('mPlay').onclick = async () => {
  if (!requireAuth()) return;
  if (MN.mode === 'auto') { if (MN.running) { MN.running = false; updM(); } else autoRun(); return; }
  if (MN.on) return cashMines();
  const bet = readBet(); if (bet !== null) startRound(bet);
};
$('mRand').onclick = () => { const free = [...Array(MN.size).keys()].filter(i => !MN.rev.has(i)); if (free.length) tap(free[Math.floor(Math.random() * free.length)]); };
async function autoRun() {
  let left = Math.max(0, Math.floor(+$('aCount').value || 0)); const inf = left === 0;
  MN.running = true; updM();
  while (MN.running && (inf || left > 0)) {
    const bet = readBet(); if (bet === null) break;
    if (!await startRound(bet)) break;
    const want = Math.min(+$('aTiles').value, MN.size - MN.m);
    const picks = [...Array(MN.size).keys()].sort(() => Math.random() - .5).slice(0, want);
    for (const i of picks) { await sleep(120); if (!MN.on) break; await tap(i); }
    if (MN.on) await cashMines();
    if (!inf) left--;
    await sleep(650);
  }
  MN.running = false; updM();
}
function syncRanges() {
  const mc = $('mCount'); mc.max = MN.size - 1; if (MN.m > MN.size - 1) MN.m = MN.size - 1; mc.value = MN.m; $('mCountV').textContent = MN.m; setRange(mc);
  const at = $('aTiles'); at.max = MN.size - MN.m; if (+at.value > MN.size - MN.m) at.value = MN.size - MN.m; $('aTilesV').textContent = at.value; setRange(at);
}
$('mCount').oninput = e => { MN.m = +e.target.value; syncRanges(); updM(); };
$('aTiles').oninput = e => { $('aTilesV').textContent = e.target.value; setRange(e.target); };
$('mGrid').onclick = e => { const b = e.target.closest('[data-g]'); if (!b || MN.on || MN.running) return; MN.size = +b.dataset.g; document.querySelectorAll('#mGrid button').forEach(x => x.classList.toggle('on', x === b)); syncRanges(); drawBoard(); };
$('mMode').onclick = e => { const b = e.target.closest('[data-m]'); if (!b || MN.on || MN.running) return; MN.mode = b.dataset.m; document.querySelectorAll('#mMode button').forEach(x => x.classList.toggle('on', x === b)); $('autoOpts').hidden = MN.mode !== 'auto'; updM(); };
document.querySelectorAll('.amt [data-b]').forEach(b => b.onclick = () => { if (MN.on || MN.running) return; const el = $('mBet'); el.value = b.dataset.b === 'max' ? Math.floor(bal) : Math.max(1, Math.round(+el.value * +b.dataset.b)); updM(); });
$('mBet').oninput = updM;
async function resumeMines() {
  if (!me) return;
  try {
    const g = await call('mines_resume'); if (!g) return;
    MN.size = g.size; MN.m = g.mines;
    document.querySelectorAll('#mGrid button').forEach(x => x.classList.toggle('on', +x.dataset.g === g.size));
    syncRanges(); drawBoard();
    Object.assign(MN, { on: true, id: g.id, bet: Number(g.bet), rev: new Set(g.revealed || []) });
    MN.rev.forEach(i => { MN.tiles[i].className = 'tile gem'; MN.tiles[i].innerHTML = GEM; });
    updM(); toast('Your unfinished Mines round is back');
  } catch (e) { /* nothing to resume */ }
}
syncRanges(); drawBoard();

/* ---------- case battles ---------- */
const MODES = { '1v1': [[0], [1]], '3way': [[0], [1], [2]], '4way': [[0], [1], [2], [3]], '2v2': [[0, 1], [2, 3]], '3v3': [[0, 1, 2], [3, 4, 5]], '2v2v2': [[0, 1], [2, 3], [4, 5]], g2: [[0, 1]], g3: [[0, 1, 2]], g4: [[0, 1, 2, 3]] };
const MODE_NAME = { '1v1': '1v1', '3way': '3 way', '4way': '4 way', '2v2': '2v2', '3v3': '3v3', '2v2v2': '2v2v2', g2: 'Group 2p', g3: 'Group 3p', g4: 'Group 4p' };
const isGroup = m => /^g/.test(m);
const TEAM_COL = ['#5b8cff', '#ff5a6e', '#3ee8a8', '#a66bff'];
const JP_SPIN = 5200, JP_MS = 7200;
const modeTags = b => (b.crazy ? '<span class="mtag crazy" title="Crazy: lowest total wins">Crazy</span>' : '') + (b.jackpot ? '<span class="mtag jp" title="Jackpot: winner drawn by chance">Jackpot</span>' : '') + (b.borrow && b.borrow.some(x => x > 0) ? '<span class="mtag bw" title="Someone borrowed: they paid less and win less">Borrow</span>' : '');
const ROUND_MS = 6600, SPIN_MS = 5400, MAX_ROUNDS = 20, PITCH = 140, FLARE_MS = 1500, TOP_SPIN = 4200, BONUS_MS = FLARE_MS + TOP_SPIN;
const BT = {}, PN = {}, PW = {}, announced = new Set();
let namesVer = 0, draft = { mode: '1v1', cases: [], crazy: false, jackpot: false, borrow: 0 }, vs = null, busy = false, lobbySig = '';
const ME = () => me ? me.id : '__nobody__';
function norm(row) {
  if (!row || !MODES[row.mode]) return null;
  const cases = (row.case_ids || []).map(caseById).filter(Boolean);
  if (!cases.length || cases.length !== (row.case_ids || []).length) return null;
  const n = MODES[row.mode].flat().length;
  const seats = Array.from({ length: n }, (_, i) => (row.seats && typeof row.seats[i] === 'string' && row.seats[i]) || null);
  const results = row.status === 'rolling' && Array.isArray(row.results)
    ? seats.map((_, i) => cases.map((c, r) => { const k = +(row.results[i] || [])[r]; return c.items.find(it => it.idx === k) || c.items[0]; })) : null;
  const payouts = Array.isArray(row.payouts) ? row.payouts.map(Number) : seats.map(() => 0);
  /* a round where anyone hits the gold dice runs longer for the respin */
  const bonus = cases.map((_, r) => results && results.some(s => s[r].top) ? BONUS_MS : 0), rs = []; let acc = 0;
  bonus.forEach((x, r) => { rs[r] = acc; acc += ROUND_MS + x; });
  const roundsEnd = acc, jackpot = !!row.jackpot && !isGroup(row.mode); if (jackpot && results) acc += JP_MS;
  return { pfHash: row.pf_hash || null, pfSeed: row.pf_seed || null, crazy: !!row.crazy, jackpot, borrow: Array.isArray(row.borrow) ? row.borrow.map(Number) : [], jp: row.jp || null, roundsEnd, id: row.id, mode: row.mode, cases, seats, status: row.status, results, payouts, creator: row.creator, cost: Number(row.cost),
    createdAt: Date.parse(row.created_at) || 0, startedAt: Date.parse(row.started_at) || 0, bonus, rs, total: acc };
}
function ingest(row) { const b = norm(row); if (b) BT[b.id] = b; lobbySig = ''; if (vs && vs.id === row.id) vs.sig = ''; }
function prog(b, now = Date.now()) {
  if (b.status === 'cancelled') return { ph: 'cancelled', revealed: 0, spinning: -1 };
  if (b.status !== 'rolling' || !b.results) return { ph: 'open', revealed: 0, spinning: -1 };
  const t = now - b.startedAt, n = b.cases.length;
  if (t < 0) return { ph: 'starting', revealed: 0, spinning: -1, count: Math.ceil(-t / 1000) };
  if (t >= b.total) return { ph: 'done', revealed: n, spinning: -1 };
  if (t >= b.roundsEnd) return { ph: 'jackpot', revealed: n, spinning: -1, jpLeft: b.total - t };
  let r = 0; while (r < n - 1 && t >= b.rs[r + 1]) r++;
  const inSpin = (t - b.rs[r]) < SPIN_MS + b.bonus[r];
  return { ph: 'rolling', revealed: inSpin ? r : r + 1, spinning: inSpin ? r : -1 };
}
const totals = (b, upto) => b.seats.map((_, i) => b.results ? b.results[i].slice(0, upto).reduce((s, it) => s + it.v, 0) : 0);
function winners(b) { const seats = b.payouts.map((p, i) => p > 0 ? i : -1).filter(i => i >= 0); return { seats, share: Math.max(0, ...b.payouts), pot: totals(b, b.cases.length).reduce((a, c) => a + c, 0) }; }

const baseName = s => (me && s === me.id) ? me.username : (PN[s] || 'Player');
/* bots: seat "bot:1" … "bot:5" */
const BOTS = [
  { n: 'Guest', img: 'assets/bots/guest666.png' },
  { n: 'John', img: 'assets/bots/johndoe.png' },
  { n: 'Baddie', img: 'assets/bots/baddie.png' },
  { n: 'Bacon', img: 'assets/bacon.png' },
  { n: 'Emperor', img: 'assets/dice-top.webp' },
];
const botOf = s => BOTS[(Math.max(1, +s.slice(4) || 1) - 1) % BOTS.length];
const nameOf = s => !s ? '' : s.startsWith('bot:') ? botOf(s).n : baseName(s) + (me && s === me.id ? ' (you)' : '');
const avatar = (s, lg) => s.startsWith('bot:') ? `<span class="av bot ${lg ? 'lg' : ''}" title="${esc(botOf(s).n)} (bot)">${botOf(s).img ? `<img src="${botOf(s).img}" alt="">` : botOf(s).svg}</span>` : `<span class="av bacon ${lg ? 'lg' : ''}" data-uid="${esc(s)}" title="View profile">${BACON}</span>`;
async function resolveNames(ids) {
  ids = [...new Set(ids)].filter(x => x && !x.startsWith('bot:') && !(x in PN));
  if (!ids.length || !sb) return;
  ids.forEach(i => PN[i] = '');
  const { data } = await sb.from('profiles').select('id,username,wagered').in('id', ids);
  (data || []).forEach(p => { PN[p.id] = p.username; PW[p.id] = Number(p.wagered) || 0; });
  namesVer++; lobbySig = ''; if (vs) vs.sig = ''; renderChat();
}

async function act(fn, args) { if (!requireAuth()) return null; if (busy) return null; busy = true; if (vs) vs.sig = ''; try { return await call(fn, args); } catch (e) { toast(niceErr(e), 'lose'); return null; } finally { busy = false; lobbySig = ''; if (vs) vs.sig = ''; } }
async function refetch(id) { const { data } = await sb.from('battles').select('*').eq('id', id).maybeSingle(); if (data) ingest(data); }
async function createBattle() {
  if (!requireAuth()) return;
  const cases = draft.cases.map(caseById).filter(Boolean);
  if (!cases.length) return toast('Add at least one case', 'lose');
  const cost = Math.ceil(cases.reduce((s, c) => s + c.price, 0) * (100 - draft.borrow) / 100);
  if (bal < cost) return toast('Not enough coins. Tap + for free coins', 'lose');
  const r = await act('battle_create', { p_mode: draft.mode, p_cases: cases.map(c => c.id), p_crazy: draft.crazy, p_jackpot: draft.jackpot, p_borrow: draft.borrow });
  if (!r) return renderCreate();
  showBal(r.coins); bumpMe(); await refetch(r.id); draft.cases = []; draft.borrow = 0; openBattle(r.id);
}
async function joinSeat(id, i, pct = 0) {
  const b = BT[id]; if (!b || !requireAuth()) return;
  if (b.seats.includes(ME())) return toast("You're already in this battle");
  const fee = Math.ceil(b.cost * (100 - pct) / 100);
  if (bal < fee) return toast('Not enough coins to join. Tap + for free coins', 'lose');
  const r = await act('battle_join', { p_id: id, p_seat: i, p_borrow: pct });
  if (r) { showBal(r.coins); bumpMe(); }
  await refetch(id);
}
async function addBots(id, seat) { const r = await act('battle_add_bots', { p_id: id, p_seat: seat === undefined ? null : seat }); await refetch(id); return r; }
async function cancelBattle(id) { const r = await act('battle_cancel', { p_id: id }); if (r) { showBal(r.coins); toast(`Battle cancelled, refunded ${cv(BT[id].cost)}`); } await refetch(id); showB('bLobby'); }

/* when a battle you're in finishes, pick up your new balance */
async function settleSeen() {
  if (!me) return;
  const now = Date.now();
  for (const b of Object.values(BT)) {
    if (announced.has(b.id) || !b.seats.includes(me.id) || prog(b, now).ph !== 'done') continue;
    announced.add(b.id);
    const mine = b.payouts[b.seats.indexOf(me.id)] || 0;
    if (Date.now() - (b.startedAt + b.total) < 60000) {
      const p = await call('my_profile').catch(() => null); if (p) showBal(p.coins);
      if (mine > 0) toast(`You won the battle! +${cv(mine)}`, 'win');
      else { const fee = Math.ceil(b.cost * (100 - ((b.borrow || [])[b.seats.indexOf(me.id)] || 0)) / 100); losePop(fee); SFX.lose(); }
      bumpMe();
    }
  }
}

function showB(which) { ['bLobby', 'bCreate', 'bView'].forEach(id => $(id).hidden = id !== which); if (which !== 'bView') vs = null; lobbySig = ''; }
const LF = { tab: 'all', afford: false, sort: 'high' };
function renderLobby(force) {
  const now = Date.now();
  const list = Object.values(BT).filter(b => {
    if (b.status === 'cancelled') return false;
    const ph = prog(b, now).ph;
    if (LF.tab === 'open' && ph !== 'open') return false;
    if (LF.tab === 'progress' && ph !== 'starting' && ph !== 'rolling') return false;
    if (LF.tab === 'mine' && !b.seats.includes(ME())) return false;
    if (LF.afford && b.cost > bal) return false;
    return true;
  }).sort((a, b) => {
    if (LF.tab !== 'mine') { const pa = prog(a, now).ph === 'done', pb = prog(b, now).ph === 'done'; if (pa !== pb) return pa - pb; }
    return LF.sort === 'new' ? b.createdAt - a.createdAt : LF.sort === 'low' ? a.cost - b.cost || b.createdAt - a.createdAt : b.cost - a.cost || b.createdAt - a.createdAt;
  }).slice(0, 60);
  const sig = list.map(b => { const p = prog(b, now); return b.id + p.ph + p.revealed + p.spinning + b.seats.join(); }).join('|') + busy + namesVer + LF.tab + LF.afford + LF.sort + (me ? me.id : '') + (LF.afford ? Math.floor(bal) : '');
  if (!force && sig === lobbySig) return; lobbySig = sig;
  $('bHead').hidden = !list.length;
  if (!list.length) { $('bList').innerHTML = `<div class="bempty"><h3>No battles found</h3><p>Create a battle or check another tab.</p><button class="btn gold" data-create="1">Create Battle</button></div>`; return; }
  $('bList').innerHTML = list.map(b => {
    const p = prog(b, now), n = b.seats.length, filled = b.seats.filter(Boolean).length, mine = b.seats.includes(ME());
    const st = p.ph === 'open' ? `Waiting ${filled}/${n}` : p.ph === 'starting' ? 'Starting' : p.ph === 'jackpot' ? 'Jackpot spin' : p.ph === 'rolling' ? `Round ${p.spinning >= 0 ? p.spinning + 1 : p.revealed}/${b.cases.length}` : 'Finished';
    const join = p.ph === 'open' && !mine;
    const btn = join ? `<button class="btn mint" data-open="${esc(b.id)}" data-join="1">Join ${cv(b.cost)}</button>` : `<button class="btn dark" data-open="${esc(b.id)}">${mine && p.ph === 'open' ? 'Open' : 'Watch'}</button>`;
    const players = MODES[b.mode].map(t => t.map(i => b.seats[i] ? avatar(b.seats[i]) : '<span class="av slot"></span>').join('')).join('<i class="sep">VS</i>');
    const ptag = p.ph === 'jackpot' ? 'rolling' : p.ph;
    return `<div class="brow ${ptag}"><div class="bm"><b>${MODE_NAME[b.mode]}</b><small>${b.cases.length} round${b.cases.length > 1 ? 's' : ''}</small>${modeTags(b) ? `<span class="mtags">${modeTags(b)}</span>` : ''}</div><div class="bc">${b.cases.slice(0, 7).map(c => `<span class="mini" title="${esc(c.name)}">${cpic(c)}</span>`).join('')}${b.cases.length > 7 ? `<span class="more">+${b.cases.length - 7}</span>` : ''}</div><div class="bp">${players}</div><div class="bk">${cv(b.cost)}</div><div class="bs"><span class="pill ${ptag}">${st}</span></div><div class="ba">${btn}</div></div>`;
  }).join('');
}
function renderCreate() {
  const g = isGroup(draft.mode); if (g) { draft.crazy = false; draft.jackpot = false; }
  document.querySelectorAll('#bCreate [data-tg]').forEach(t => { const k = t.dataset.tg; t.classList.toggle('on', !!draft[k]); t.classList.toggle('off', g && k !== 'borrow'); });
  document.querySelectorAll('#bCreate [data-mode]').forEach(x => x.classList.toggle('on', x.dataset.mode === draft.mode));
  document.querySelectorAll('#bCreate .cbtype').forEach(x => x.classList.toggle('on', !!x.querySelector(`[data-mode="${draft.mode}"]`)));
  const counts = new Map(); draft.cases.forEach(id => counts.set(id, (counts.get(id) || 0) + 1));
  $('bRounds').innerHTML = '<button class="cbadd" data-pick="1"><b>+</b>Add a case</button>' + [...counts].map(([id, q]) => { const c = caseById(id); return `<div class="cbcase"><span class="art">${cpic(c)}</span><b>${esc(c.name)}</b>${cv(c.price)}<span class="qty"><button data-dec="${id}" aria-label="One less">−</button><em>${q}</em><button data-inc="${id}" aria-label="One more">+</button></span></div>`; }).join('');
  const cost = draft.cases.reduce((s, id) => s + caseById(id).price, 0), pay = Math.ceil(cost * (100 - draft.borrow) / 100);
  $('bFoot').innerHTML = `${draft.cases.length} case${draft.cases.length === 1 ? '' : 's'} · ${cv(cost)}${draft.borrow ? ` <span class="mut">· you pay ${cv(pay)}</span>` : ''}`;
  $('bBorrow').hidden = !draft.borrow; if (draft.borrow) borrowPanel($('bBorrow'), cost, draft.borrow, v => { draft.borrow = v; renderCreate(); });
  $('bMake').disabled = !draft.cases.length || busy;
  $('bMake').textContent = 'Create battle';
}
/* volatility = how spread out a case's pulls are (0 calm … 1 wild) */
const caseVol = c => { if (c._vol != null) return c._vol; const t = c.tot, m = c.items.reduce((s, i) => s + i.v * i.w, 0) / t, sd = Math.sqrt(c.items.reduce((s, i) => s + i.w * (i.v - m) ** 2, 0) / t); return c._vol = sd / c.price; };
function volBar(c) {
  const all = onSale().map(caseVol).sort((x, y) => x - y), r = all.length > 1 ? all.indexOf(caseVol(c)) / (all.length - 1) : .5;
  const col = r < .25 ? '#3ee8a8' : r < .5 ? '#5b8cff' : r < .75 ? '#f7a23b' : '#ff4d6a';
  return `<span class="vol" style="--vc:${col};--vx:calc(${(r * 100).toFixed(1)}% - 1.5px)" title="Volatility">${[0, 1, 2, 3].map(k => `<i class="${k <= Math.floor(r * 3.999) ? 'f' : ''}"></i>`).join('')}<em></em></span>`;
}
let PK = { sel: [], sort: 'new' };
function openPicker() { PK.sel = []; $('pkQ').value = ''; $('pickModal').hidden = false; renderPicker(); setTimeout(() => $('pkQ').focus(), 30); }
function renderPicker() {
  const q = $('pkQ').value.trim().toLowerCase(), counts = {}; PK.sel.forEach(id => counts[id] = (counts[id] || 0) + 1);
  let list = onSale().filter(c => !q || c.name.toLowerCase().includes(q));
  const S = { new: (x, y) => y.sort - x.sort || 0, asc: (x, y) => x.price - y.price, desc: (x, y) => y.price - x.price, vlo: (x, y) => caseVol(x) - caseVol(y), vhi: (x, y) => caseVol(y) - caseVol(x) };
  if (PK.sort === 'new') list = list.slice().reverse(); else list = list.slice().sort(S[PK.sort]);
  $('pkGrid').innerHTML = list.length ? list.map(c => `<button class="pkc ${counts[c.id] ? 'sel' : ''}" data-add="${c.id}">${counts[c.id] ? `<span class="cnt">${counts[c.id]}</span>` : ''}<span class="art">${cpic(c)}</span><b>${esc(c.name)}</b><span class="pp">${cv(c.price)}</span>${volBar(c)}</button>`).join('') : '<div class="lbempty" style="grid-column:1/-1">No cases match.</div>';
  const cost = PK.sel.reduce((s, id) => s + caseById(id).price, 0);
  $('pkCount').innerHTML = `${PK.sel.length} Case${PK.sel.length === 1 ? '' : 's'} - ${cv(cost)}`;
  $('pkAdd').disabled = !PK.sel.length;
  document.querySelectorAll('#pkSortMenu [data-sort]').forEach(b => b.classList.toggle('on', b.dataset.sort === PK.sort));
}
/* borrow slider panel, used when creating and when joining */
function borrowPanel(el, cost, pct, onChange) {
  const pay = Math.ceil(cost * (100 - pct) / 100);
  el.innerHTML = `<div><h4>Borrow Tokens</h4><input type="range" min="1" max="90" value="${pct}" style="--p:${((pct - 1) / 89 * 100).toFixed(1)}%" aria-label="Borrow percentage"><div class="bwq">${[1, 20, 40, 60].map(v => `<button data-bq="${v}" class="${pct === v ? 'on' : ''}">${v}%</button>`).join('')}<button data-bq="90" class="${pct === 90 ? 'on' : ''}">MAX</button></div></div>
    <div class="bwr"><div>Battle cost:<b>${cv(cost)}</b></div><div>Borrow amount:<span class="ac">${pct}% → ${cv(cost - pay)}</span></div><hr><div class="big">You pay:<span>${cv(pay)}</span></div><div>You receive on win:<b>${100 - pct}%</b></div></div>`;
  el.querySelector('input').oninput = e => onChange(+e.target.value);
  el.querySelectorAll('[data-bq]').forEach(b => b.onclick = () => onChange(+b.dataset.bq));
}
let BW = null;
function openBorrowJoin(id, seat) {
  if (!requireAuth()) return; const b = BT[id]; if (!b) return;
  BW = { id, seat, pct: 20 }; $('borrowModal').hidden = false;
  const draw = () => borrowPanel($('bwPanel'), b.cost, BW.pct, v => { BW.pct = v; draw(); }); draw();
}
$('borrowModal').onclick = e => { if (e.target === $('borrowModal') || e.target.closest('[data-bwclose]')) $('borrowModal').hidden = true; };
$('bwJoin').onclick = () => { if (!BW) return; $('borrowModal').hidden = true; joinSeat(BW.id, BW.seat, BW.pct); };
const vcard = it => it.dice ? `<div class="vc dice" style="--rc:${RC.legendary}"><span class="art">${DICE_ART}</span></div>`
  : `<div class="vc ${it.top ? 'tp' : ''}" style="--rc:${RC[it.r]}"><span class="art">${pic(it)}</span><span>${esc(it.n)}</span>${cv(it.v)}</div>`;
/* battle reel: lands the item, or the gold dice → flare → respin between the top pulls */
function vspin(reel, c, winner, dur) {
  const token = reel.dataset.spin = String(Math.random()), box = reel.parentElement;
  box.classList.remove('goldmode', 'flaring');
  if (!winner.top) return vroll(reel, () => shown(pick(c)), winner, dur, token);
  if (dur <= 0) { box.classList.add('goldmode'); vroll(reel, () => pickTop(c), winner, 0, token); reel.children[30].classList.add('jack'); return; }
  const d2 = Math.min(TOP_SPIN, dur), d1 = dur - d2 - FLARE_MS;
  const respin = () => { if (reel.dataset.spin !== token) return; box.classList.add('goldmode'); vroll(reel, () => pickTop(c), winner, d2, token); setTimeout(() => { if (reel.dataset.spin === token) reel.children[30].classList.add('jack'); }, d2); };
  if (d1 < 900) return respin();
  vroll(reel, () => shown(pick(c)), DICE, d1, token);
  setTimeout(() => { if (reel.dataset.spin !== token) return; flare(reel.children[30], box, FLARE_MS); setTimeout(respin, FLARE_MS); }, d1);
}
function vroll(reel, fill, winner, dur, token) {
  if (reel.id === 'vr0' && dur > 0) SFX.spin(dur - 450);
  const N = 36, W = 30; let h = ''; for (let i = 0; i < N; i++) h += vcard(i === W ? winner : fill()); reel.innerHTML = h;
  reel.style.transition = 'none'; reel.style.transform = 'translateY(0)'; void reel.offsetHeight;
  const H = reel.parentElement.clientHeight, y0 = 10 + W * PITCH + 65 - H / 2, card = reel.children[W];
  if (dur <= 0) { reel.style.transform = `translateY(${-y0}px)`; card.classList.add('won'); return; }
  const run = Math.max(300, dur - 450), off = (Math.random() < .5 ? -1 : 1) * (18 + Math.random() * 34);
  reel.style.transition = `transform ${run}ms cubic-bezier(.12,.8,.18,1)`; reel.style.transform = `translateY(${-(y0 + off)}px)`;
  setTimeout(() => { if (reel.dataset.spin !== token) return; reel.style.transition = 'transform .42s cubic-bezier(.3,1.35,.5,1)'; reel.style.transform = `translateY(${-y0}px)`; card.classList.add('won'); }, run + 40);
}
function idleV(reel, c) { reel.style.transition = 'none'; reel.parentElement.classList.remove('goldmode'); const s = reelSet(c); reel.innerHTML = s.concat(s, s).map(vcard).join(''); const H = reel.parentElement.clientHeight; reel.style.transform = `translateY(${-(10 + PITCH + 65 - H / 2)}px)`; }
function openBattle(id, join) {
  const b = BT[id]; if (!b) return;
  nav('battles'); showB('bView'); vs = { id, spinning: -1, sig: '' };
  const teams = MODES[b.mode], n = b.seats.length, tStart = new Set(teams.slice(1).map(t => t[0])), tEnd = new Set(teams.map(t => t[t.length - 1]));
  const teamOf = i => teams.findIndex(t => t.includes(i));
  $('vMode').innerHTML = esc(MODE_NAME[b.mode]) + modeTags(b);
  const g = $('vGrid'); g.style.setProperty('--n', n);
  let h = `<div class="ccol" id="vCases">${b.cases.map((c, r) => `<div class="cc" id="cc${r}" title="${esc(c.name)}">${cpic(c)}</div>`).join('')}</div>`;
  h += b.seats.map((_, i) => `<div class="seat ${tStart.has(i) ? 'tb' : ''} ${i === n - 1 ? 'last' : ''}" id="seat${i}">${tStart.has(i) ? `<span class="xs">${IC.swords}</span>` : ''}<div class="vbox"><div class="vreel" id="vr${i}"></div></div><div class="wait" id="wt${i}"></div></div>`).join('');
  h += '<div class="gsp"></div>' + b.seats.map((_, i) => `<div class="pc t${teamOf(i)} ${i === 0 ? 'first' : ''} ${tStart.has(i) ? 'tb' : ''} ${tEnd.has(i) ? 'te' : ''}" id="pc${i}"></div>`).join('');
  h += '<div class="gsp"></div>' + b.seats.map((_, i) => `<div class="rd ${tStart.has(i) ? 'tb' : ''}" id="rd${i}"></div>`).join('');
  g.innerHTML = h;
  b.seats.forEach((_, i) => idleV($('vr' + i), b.cases[0]));
  tickView(true);
  if (join) { const i = b.seats.indexOf(null); if (i >= 0) joinSeat(id, i); }
}
/* jackpot: a striped bar (one colour per side, sized by chance) spins to the server's roll */
function renderJackpot(b, p) {
  const el = $('vJack'), show = b.jackpot && b.jp && (p.ph === 'jackpot' || p.ph === 'done');
  el.hidden = !show; if (!show) return;
  const teams = MODES[b.mode], tot = totals(b, b.cases.length), tt = teams.map(t => t.reduce((s, i) => s + tot[i], 0)), pot = tt.reduce((x, y) => x + y, 0);
  const ch = tt.map(x => !pot ? 1 / teams.length : b.crazy ? (pot - x) / (pot * (teams.length - 1)) : x / pot), wt = b.jp.team, roll = Number(b.jp.roll);
  if (!vs.jp) {
    const W = el.clientWidth || 900, S = Math.max(W * 1.1, 760), R = 9;
    const seg = teams.map((t, k) => `<div class="jseg" style="--tc:${TEAM_COL[k % 4]};width:${Math.max(0, ch[k] * S - 4)}px">${ch[k] * S > 60 ? t.map(i => b.seats[i] ? avatar(b.seats[i]) : '').join('') : ''}${ch[k] * S > 150 ? `<span>${(ch[k] * 100).toFixed(2)}%</span>` : ''}</div>`).join('');
    el.innerHTML = `<h3>JACKPOT MODE</h3><div class="pot">${cv(pot)}</div><div class="jtrack"><div class="jstrip" id="jStrip">${seg.repeat(R)}</div></div><div class="jres" id="jRes"></div>`;
    vs.jp = { W, S, x: W / 2 - (6 * S + roll * S) };
    const strip = $('jStrip'), start = W / 2 - S * 0.5, elapsed = p.ph === 'jackpot' ? JP_MS - p.jpLeft : JP_MS;
    if (elapsed < JP_SPIN - 300) {
      strip.style.transform = `translateX(${start}px)`; void strip.offsetWidth;
      strip.style.transition = `transform ${JP_SPIN - elapsed}ms cubic-bezier(.1,.7,.1,1)`; strip.style.transform = `translateX(${vs.jp.x}px)`;
    } else strip.style.transform = `translateX(${vs.jp.x}px)`;
  }
  const res = $('jRes');
  if (p.ph === 'done' && !res.innerHTML) {
    const ws = teams[wt].filter(i => b.seats[i]);
    res.innerHTML = `<span class="lbl2">Battle complete</span><div class="jwho">${ws.map(i => avatar(b.seats[i])).join('')}</div><span><b class="wn"></b> won with a <em>${(ch[wt] * 100).toFixed(2)}%</em> chance</span>`;
    res.querySelector('.wn').textContent = ws.map(i => nameOf(b.seats[i])).join(' & ');
  }
}
function confetti(big) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const c = document.createElement('canvas'); c.className = 'confetti'; document.body.appendChild(c);
  const ctx = c.getContext('2d'), dpr = devicePixelRatio || 1, W = innerWidth, H = innerHeight;
  c.width = W * dpr; c.height = H * dpr; ctx.scale(dpr, dpr);
  const cols = ['#f7c948', '#3ee8a8', '#5b8cff', '#a66bff', '#ff4d6a', '#ffffff'], P = [], per = big ? 130 : 50;
  [[0.04, -Math.PI / 3], [0.96, -2 * Math.PI / 3]].forEach(([sx, ang]) => { for (let i = 0; i < per; i++) { const a = ang + (Math.random() - .5) * .9, v = 12 + Math.random() * 12; P.push({ x: W * sx, y: H * .98, vx: Math.cos(a) * v, vy: Math.sin(a) * v, w: 6 + Math.random() * 6, h: 9 + Math.random() * 9, r: Math.random() * 6, vr: (Math.random() - .5) * .35, c: cols[i % cols.length] }); } });
  const t0 = performance.now();
  (function f(now) {
    const t = now - t0; ctx.clearRect(0, 0, W, H);
    for (const p of P) { p.vy += .32; p.vx *= .985; p.vy *= .985; p.x += p.vx; p.y += p.vy; p.r += p.vr; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.globalAlpha = Math.max(0, 1 - Math.max(0, t - 2200) / 1400); ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, Math.max(1, p.h * Math.abs(Math.cos(p.r * 1.7)))); ctx.restore(); }
    if (t < 3600) requestAnimationFrame(f); else c.remove();
  })(t0);
}
function tickView(force) {
  if (!vs) return;
  const b = BT[vs.id]; if (!b) { showB('bLobby'); return; }
  const now = Date.now(), p = prog(b, now), n = b.cases.length;
  const want = p.spinning >= 0 ? p.spinning : p.revealed - 1;
  if (want >= 0 && vs.spinning !== want) {
    vs.spinning = want;
    const left = p.spinning >= 0 ? b.startedAt + b.rs[want] + SPIN_MS + b.bonus[want] - now : 0;
    b.seats.forEach((_, i) => { const it = b.results[i][want], l = it.top ? left : left - b.bonus[want]; vspin($('vr' + i), b.cases[want], it, l > 500 ? l : 0); });
  }
  if (vs.ph && vs.ph !== 'done' && p.ph === 'done') { const w0 = winners(b), mi = b.seats.indexOf(ME()); confetti(mi < 0 || w0.seats.includes(mi)); }
  vs.ph = p.ph;
  renderJackpot(b, p);
  const sig = [p.ph, p.revealed, p.spinning, p.count, b.seats.join(), busy, namesVer, me ? me.id : ''].join('|');
  if (!force && sig === vs.sig) return; vs.sig = sig;
  const mine = b.seats.includes(ME()), filled = b.seats.filter(Boolean).length, isCreator = me && b.creator === me.id;
  const cur = p.ph === 'open' || p.ph === 'starting' ? 0 : p.spinning >= 0 ? p.spinning : Math.min(p.revealed, n - 1);
  const shown = p.ph === 'done' ? n : p.ph === 'open' || p.ph === 'starting' ? 0 : p.spinning >= 0 ? p.spinning + 1 : p.revealed;
  $('vRoundsTop').textContent = `Rounds ${shown}/${n}`;
  $('vCost').innerHTML = cv(b.cost);
  const cc = b.cases[cur];
  $('vCase').innerHTML = `<span class="art">${cpic(cc)}</span><div><b>${esc(cc.name)}</b>${cv(cc.price)}</div>`;
  b.cases.forEach((_, r) => { $('cc' + r).className = 'cc' + (p.ph !== 'done' && r === cur ? ' on' : '') + (r < p.revealed && !(p.ph !== 'done' && r === cur) ? ' done' : ''); });
  const col = $('vCases'), on = $('cc' + cur); if (on) col.scrollTop = on.offsetTop - col.clientHeight / 2 + on.offsetHeight / 2;
  const t = totals(b, p.revealed), w = p.ph === 'done' ? winners(b) : null;
  let stat;
  if (p.ph === 'open') stat = `Waiting for players <b>${filled}/${b.seats.length}</b>`;
  else if (p.ph === 'starting') stat = `Starting in <b>${p.count}</b>`;
  else if (p.ph === 'rolling') stat = `Rolling round <b>${shown}</b>`;
  else if (p.ph === 'cancelled') stat = 'Cancelled';
  else if (p.ph === 'jackpot') stat = 'Jackpot spin…';
  else if (mine) { const mi = b.seats.indexOf(ME()), won = w.seats.includes(mi); stat = `<span class="bvstat ${won ? 'win' : 'lose'}">${won ? (isGroup(b.mode) ? 'Your share ' : 'You won ') + cv(b.payouts[mi]) : 'You lost'}</span>`; }
  else stat = `Finished · pot ${cv(w.pot)}`;
  $('vStat').innerHTML = stat;
  $('vFair').innerHTML = b.pfHash ? `<span>Seed hash <code>${esc(b.pfHash.slice(0, 16))}…</code></span>${b.pfSeed && p.ph === 'done' ? `<button class="pfbtn" data-vb="${esc(b.id)}">Verify battle</button>` : '<span class="mut">seed revealed when it ends</span>'}` : '';
  b.seats.forEach((s, i) => {
    const seat = $('seat' + i), won = w && w.seats.includes(i);
    seat.classList.toggle('rolling', p.ph === 'rolling' || p.ph === 'done' || p.ph === 'jackpot');
    seat.classList.toggle('win', !!won);
    let wh = '';
    if (p.ph === 'open' || p.ph === 'starting' || p.ph === 'cancelled') {
      if (s) wh = `${avatar(s, true)}<b class="nm"></b><span class="ok">${IC.check}${p.ph === 'starting' ? 'Starting…' : 'Ready'}</span>`;
      else {
        wh = '<span class="ring"></span><b>Waiting for players</b>';
        if (p.ph === 'open' && !mine) wh += `<button class="btn mint" data-join="${i}" ${busy ? 'disabled' : ''}>Join ${cv(b.cost)}</button><button class="btn dark sm" data-borrow="${i}" ${busy ? 'disabled' : ''} title="Pay less to enter, win less">Borrow</button>`;
        if (p.ph === 'open' && isCreator) wh += `<button class="btn dark" data-bot="${i}" ${busy ? 'disabled' : ''}>${IC.bot}Add bot</button>`;
      }
    }
    $('wt' + i).innerHTML = wh;
    const nm = $('wt' + i).querySelector('.nm'); if (nm) nm.textContent = nameOf(s);
    const pc = $('pc' + i);
    pc.classList.toggle('win', !!won); pc.classList.toggle('lose', !!(w && !won));
    if (s) { pc.innerHTML = `${avatar(s)}<span class="pcm"><span class="nm" ${s.startsWith('bot:') ? '' : `data-uid="${esc(s)}"`}></span><span class="pcs">${s.startsWith('bot:') ? '<span class="lvl bt">BOT</span>' : lvlBadge(levelInfo(PW[s] || 0).level)}<span class="tt">${won ? `+${COIN}${fmtS(b.payouts[i])}` : ''}</span></span></span>`; pc.querySelector('.nm').textContent = nameOf(s); if (!won) pc.querySelector('.tt').innerHTML = cvS(t[i]); pc.title = nameOf(s) + ': ' + fmt(won ? b.payouts[i] : t[i]); }
    else pc.innerHTML = '<span class="wt">Waiting for player</span>';
    $('rd' + i).innerHTML = b.cases.map((c, r) => { if (b.results && r < p.revealed) { const it = b.results[i][r]; return `<div class="rb got" style="--rc:${RC[it.r]}"><span class="art">${pic(it)}</span>${cv(it.v)}<em>Round ${r + 1}</em></div>`; } return `<div class="rb"><em>Round ${r + 1}</em></div>`; }).join('');
  });
  let ctl = '';
  if (p.ph === 'open' && isCreator) ctl = `<button class="btn dark" data-act="bots" ${busy ? 'disabled' : ''}>${IC.bot}Fill with bots</button><button class="btn dark" data-act="cancel" ${busy ? 'disabled' : ''}>Cancel &amp; refund</button>`;
  else if (p.ph === 'done') ctl = `<button class="btn gold" data-act="new">${IC.plus}New battle</button>`;
  $('vCtl').innerHTML = ctl;
}
$('bNew').onclick = () => { if (!requireAuth()) return; showB('bCreate'); renderCreate(); };
$('bCreateBack').onclick = () => showB('bLobby');
$('bBack').onclick = () => showB('bLobby');
$('bMake').onclick = createBattle;
$('bList').onclick = e => { const u = e.target.closest('[data-uid]'); if (u) return openProfile(u.dataset.uid); if (e.target.closest('[data-create]')) return $('bNew').click(); const t = e.target.closest('[data-open]'); if (t) openBattle(t.dataset.open, !!t.dataset.join); };
$('bTabs').onclick = e => { const b = e.target.closest('[data-t]'); if (!b) return; LF.tab = b.dataset.t; document.querySelectorAll('#bTabs button').forEach(x => x.classList.toggle('on', x === b)); renderLobby(true); };
$('bAfford').onclick = () => { LF.afford = !LF.afford; $('bAfford').setAttribute('aria-pressed', LF.afford); renderLobby(true); };
$('bSort').onchange = e => { LF.sort = e.target.value; renderLobby(true); };
$('bCreate').onclick = e => {
  const m = e.target.closest('[data-mode]'), tg = e.target.closest('[data-tg]'), inc = e.target.closest('[data-inc]'), dec = e.target.closest('[data-dec]');
  if (e.target.closest('[data-pick]')) return openPicker();
  if (m) draft.mode = m.dataset.mode;
  else if (tg) {
    const k = tg.dataset.tg; if (isGroup(draft.mode) && k !== 'borrow') return toast('Group Unbox splits everything, so Crazy and Jackpot don’t apply');
    if (k === 'borrow') draft.borrow = draft.borrow ? 0 : 20; else draft[k] = !draft[k];
  }
  else if (inc) { if (draft.cases.length >= MAX_ROUNDS) return toast(`That’s the ${MAX_ROUNDS}-round maximum`); draft.cases.splice(draft.cases.lastIndexOf(inc.dataset.inc) + 1, 0, inc.dataset.inc); }
  else if (dec) draft.cases.splice(draft.cases.lastIndexOf(dec.dataset.dec), 1);
  else return;
  renderCreate();
};
$('pickModal').onclick = e => {
  if (e.target === $('pickModal') || e.target.closest('[data-pkcancel]')) { $('pickModal').hidden = true; return; }
  const sb2 = e.target.closest('#pkSortBtn'); if (sb2) { const m = $('pkSortMenu'); m.hidden = !m.hidden; sb2.setAttribute('aria-expanded', !m.hidden); return; }
  const so = e.target.closest('[data-sort]'); if (so) { PK.sort = so.dataset.sort; $('pkSortLbl').textContent = so.textContent; $('pkSortMenu').hidden = true; $('pkSortBtn').setAttribute('aria-expanded', false); renderPicker(); return; }
  if (!e.target.closest('.pksort')) { $('pkSortMenu').hidden = true; $('pkSortBtn').setAttribute('aria-expanded', false); }
  const a2 = e.target.closest('[data-add]'); if (!a2) return;
  if (draft.cases.length + PK.sel.length >= MAX_ROUNDS) return toast(`That’s the ${MAX_ROUNDS}-round maximum`);
  PK.sel.push(a2.dataset.add); renderPicker();
};
$('pkAdd').onclick = () => { draft.cases.push(...PK.sel); PK.sel = []; $('pickModal').hidden = true; renderCreate(); };
$('pkQ').oninput = renderPicker;
$('bView').onclick = e => {
  if (!vs) return;
  const u = e.target.closest('[data-uid]'); if (u) return openProfile(u.dataset.uid);
  const vb = e.target.closest('[data-vb]'); if (vb) return verifyBattle(vb.dataset.vb);
  const j = e.target.closest('[data-join]'), bt = e.target.closest('[data-bot]'), a = e.target.closest('[data-act]');
  const bw = e.target.closest('[data-borrow]'); if (bw) return openBorrowJoin(vs.id, +bw.dataset.borrow);
  if (j) joinSeat(vs.id, +j.dataset.join);
  else if (bt) addBots(vs.id, +bt.dataset.bot);
  else if (a && a.dataset.act === 'bots') addBots(vs.id);
  else if (a && a.dataset.act === 'cancel') cancelBattle(vs.id);
  else if (a && a.dataset.act === 'new') { const b = BT[vs.id]; draft = { mode: b.mode, cases: b.cases.filter(c => c.active).map(c => c.id), crazy: b.crazy, jackpot: b.jackpot, borrow: 0 }; showB('bCreate'); renderCreate(); }
};
let rz; addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => { if (vs) openBattle(vs.id); }, 300); });
async function loadBattles() {
  if (!sb) { $('bNote').textContent = 'Battles appear once the site is connected to Supabase.'; renderLobby(true); return; }
  const qs = [sb.from('battles').select('*').order('created_at', { ascending: false }).limit(60)];
  if (me) qs.push(sb.from('battles').select('*').contains('seats', [me.id]).order('created_at', { ascending: false }).limit(60));
  const res = await Promise.all(qs);
  res.forEach(r => (r.data || []).forEach(ingest));
  (res[1] && res[1].data || []).forEach(row => { const b = BT[row.id]; if (b && prog(b).ph === 'done') announced.add(b.id); });
  Object.values(BT).forEach(b => { if (prog(b).ph === 'done' && Date.now() - b.startedAt > 120000) announced.add(b.id); });
  resolveNames(Object.values(BT).flatMap(b => b.seats.filter(Boolean)));
  $('bNote').textContent = 'Live: anyone signed in can join your battles.';
  renderLobby(true);
}
setInterval(() => { tickView(false); if (!$('bLobby').hidden) renderLobby(false); }, 250);
setInterval(settleSeen, 1000);

/* ---------- live chat ---------- */
let msgs = [];
const hhmm = t => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
function renderChat() {
  const box = $('msgs'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  if (!sb) { box.innerHTML = '<div class="chat-empty">Chat appears once the site is connected to Supabase.</div>'; return; }
  if (!msgs.length) { box.innerHTML = '<div class="chat-empty">No messages yet. Say hi!</div>'; return; }
  box.innerHTML = msgs.map((m, i) => `<div class="msg ${me && m.user_id === me.id ? 'mine' : ''}" data-i="${i}"><span class="av bacon" data-uid="${esc(m.user_id)}" title="View profile">${BACON}</span><div><div class="who"><span class="n" data-uid="${esc(m.user_id)}"></span>${lvlBadge(levelInfo(PW[m.user_id] || 0).level)}<time>${hhmm(m.created_at)}</time>${me && me.admin ? `<button class="del" data-del="${m.id}" title="Delete message" aria-label="Delete message">✕</button>` : ''}</div><div class="bub"></div></div></div>`).join('');
  box.querySelectorAll('.msg').forEach(el => { const m = msgs[+el.dataset.i]; const n = el.querySelector('.n'); n.textContent = PN[m.user_id] || m.username; if (me && m.user_id === me.id) n.classList.add('me'); el.querySelector('.bub').textContent = m.body; });
  if (near || (me && msgs[msgs.length - 1].user_id === me.id)) box.scrollTop = box.scrollHeight;
}
function renderChatInput() {
  $('chatIn').placeholder = !sb ? 'Chat is not set up yet' : me ? 'Type message…' : 'Sign in to chat';
  $('chatIn').readOnly = !me; $('chatSend').disabled = !me;
}
$('chatIn').onfocus = () => { if (sb && !me) openAuth('signup'); };
let lastSend = 0;
$('chatForm').onsubmit = async e => {
  e.preventDefault();
  if (!requireAuth()) return;
  const t = $('chatIn').value.replace(/\s+/g, ' ').trim().slice(0, 200);
  if (!t) return;
  const wait = 3000 - (Date.now() - lastSend);
  if (wait > 0) return toast(`Slowmode: wait ${Math.ceil(wait / 1000)}s`);
  lastSend = Date.now(); $('chatIn').value = '';
  try { await call('send_chat', { p_body: t }); } catch (err) { $('chatIn').value = t; toast(niceErr(err), 'lose'); }
};
$('msgs').onclick = async e => {
  const d = e.target.closest('[data-del]');
  if (d) { try { await call('admin_delete_chat', { p_id: +d.dataset.del }); msgs = msgs.filter(m => m.id !== +d.dataset.del); renderChat(); } catch (err) { toast(niceErr(err), 'lose'); } return; }
  const u = e.target.closest('[data-uid]'); if (u) openProfile(u.dataset.uid);
};
$('chatRules').onclick = () => toast('Be kind, no spam, no personal info, and never share passwords or trade real money.');
$('chatOpen').onclick = () => $('chat').classList.add('open');
$('chatClose').onclick = () => $('chat').classList.remove('open');
async function loadChat() {
  if (!sb) return renderChat();
  const { data } = await sb.from('chat_messages').select('id,user_id,username,body,created_at').order('id', { ascending: false }).limit(80);
  msgs = (data || []).reverse(); renderChat(); resolveNames(msgs.map(m => m.user_id));
}
setInterval(() => renderChat(), 60000);

/* ---------- online count: everyone with the site open (signed in or not) ---------- */
function trackOnline() {
  if (!sb || typeof sb.channel !== 'function') return;
  const key = (sessionStorageGet('eb_view') || (() => { const k = Math.random().toString(36).slice(2); sessionStorageSet('eb_view', k); return k; })());
  const ch = sb.channel('online', { config: { presence: { key } } });
  if (typeof ch.on !== 'function' || typeof ch.track !== 'function') return;
  const show = () => { const n = Object.keys(ch.presenceState ? ch.presenceState() : {}).length; const el = $('chatCount'); el.hidden = !n; el.textContent = `${fmt(n)} online`; };
  ch.on('presence', { event: 'sync' }, show).on('presence', { event: 'join' }, show).on('presence', { event: 'leave' }, show)
    .subscribe(st => { if (st === 'SUBSCRIBED') ch.track({ at: Date.now() }).catch(() => {}); });
}
function sessionStorageGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
function sessionStorageSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }

/* ---------- live updates ---------- */
function subscribe() {
  sb.channel('live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'battles' }, p => { if (p.new && p.new.id) { ingest(p.new); resolveNames((p.new.seats || []).filter(Boolean)); } })
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, p => {
      if (!p.new || msgs.some(m => m.id === p.new.id)) return;
      msgs.push(p.new); msgs = msgs.slice(-80); renderChat(); resolveNames([p.new.user_id]);
    })
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'chat_messages' }, p => {
      if (p.old && p.old.id) { msgs = msgs.filter(m => m.id !== p.old.id); renderChat(); }
    })
    .subscribe();
}

/* ---------- upgrader ---------- */
const TIER = v => v >= 20e6 ? 'legendary' : v >= 2e6 ? 'epic' : v >= 2e5 ? 'rare' : v >= 2e4 ? 'uncommon' : 'common';
function guessArt(name, r) {
  const c = RC[r], n = name.toLowerCase();
  if (/dominus/.test(n)) return ART.hood(c, '#f7c948', '#9be7ff');
  if (/valk|helm|viking|centurion|knightmare|warhelm/.test(n)) return ART.helm(c, /valk/.test(n) ? '#e5e9f2' : '');
  if (/fedora|sombrero|beret|capotain|cap\b|witch hat/.test(n)) return ART.fedora(c, '#20232b', /sparkle/.test(n) ? '#fff' : '');
  if (/top hat|hat\b/.test(n)) return ART.tophat(c, '#f7c948');
  if (/headphones/.test(n)) return ART.phones(c, '#3a2a14');
  if (/shades|glasses|eyes|visor|goggles|spectacles|oculus|stunnas|gaze/.test(n)) return ART.shades('#15172a', c);
  if (/horns|antlers/.test(n)) return ART.horns(c, '#ffc13c');
  if (/face|smile|grin|happy/.test(n)) return ART.face(c === RC.common ? '#ffd23f' : c);
  if (/pumpkin/.test(n)) return ART.pumpkin('#ff8a1f');
  if (/vamp/.test(n)) return ART.vampire();
  if (/head|cone|bucket/.test(n)) return ART.bighead(c);
  return ART.crown(c, '#fff');
}
let UPI = [], uSel = null, uShow = 70, uSpinning = false, uRot = 0;
const U = { mode: 'manual', over: false, running: false };
async function loadUpgradeItems() {
  if (!sb) return;
  const { data, error } = await sb.from('upgrade_items').select('id,name,value').order('value', { ascending: false });
  if (error) { $('uGrid').innerHTML = '<div class="loading">Could not load items. Refresh to try again.</div>'; return; }
  UPI = (data || []).map(x => { const v = Number(x.value), r = TIER(v); return { id: Number(x.id), n: x.name, v, r, art: guessArt(x.name, r), img: null }; });
  renderUGrid(); renderUpg(); thumbsFor(UPI).then(() => { renderUGrid(); renderUpg(); renderRewards(); });
}
async function thumbsFor(list) {
  const ids = [...new Set(list.filter(i => i.id > 0 && !i.img).map(i => i.id))];
  for (let k = 0; k < ids.length; k += 100) {
    try {
      const j = await (await fetch(`https://thumbnails.roproxy.com/v1/assets?assetIds=${ids.slice(k, k + 100).join(',')}&size=150x150&format=Png&isCircular=false`)).json();
      (j.data || []).forEach(d => { if (d.state === 'Completed' && /^https:\/\//.test(d.imageUrl)) list.filter(i => i.id === d.targetId).forEach(i => i.img = d.imageUrl); });
    } catch (e) { return; }
  }
}
const uBet = () => Math.max(0, Math.round(+$('uBet').value || 0));
const uChance = () => uSel && uBet() > 0 && uBet() < uSel.v ? Math.min(80, uBet() / uSel.v * 95) : 0;
function uFiltered() {
  const q = $('uSearch').value.trim().toLowerCase(), mn = +$('uMin').value || 0, mx = +$('uMax').value || Infinity;
  const l = UPI.filter(i => (!q || i.n.toLowerCase().includes(q)) && i.v >= mn && i.v <= mx);
  return $('uSort').value === 'asc' ? l.slice().sort((a, b) => a.v - b.v) : l;
}
function renderUGrid() {
  if (!UPI.length) return;
  const l = uFiltered(), b = uBet();
  $('uGrid').innerHTML = l.length ? l.slice(0, uShow).map(i => `<button class="ucard ${uSel && uSel.id === i.id ? 'sel' : ''} ${i.v <= b ? 'too' : ''}" data-u="${i.id}" style="--rc:${RC[i.r]}"><span class="tag">${i.r}</span><span class="art">${pic(i)}</span><b>${esc(i.n)}</b>${cv(i.v)}</button>`).join('')
    : '<div class="loading">No items match. Try a different search or price range.</div>';
  $('uMore').hidden = l.length <= uShow;
}
function renderUpg(result) {
  const ch = uChance(), C = 2 * Math.PI * 178;
  $('uArc').setAttribute('stroke-dasharray', `${C * ch / 100} ${C}`);
  $('uArc').setAttribute('transform', `rotate(${-90 + (U.over ? 360 * (1 - ch / 100) : 0)} 200 200)`);
  if (!result) {
    $('uWheel').classList.remove('win', 'lose');
    $('uPct').textContent = ch ? (ch < 0.01 ? ch.toFixed(4) : ch.toFixed(2)) + '%' : '0.00%';
    $('uLab').textContent = 'Upgrade chance';
    const lo = U.over ? (100 - ch) : 0, hi = U.over ? 99.9999 : Math.max(0, ch - 0.0001);
    $('uRng').innerHTML = !uSel ? 'Pick an item below' : uBet() >= uSel.v ? 'Pick an item worth more than your bet' : `<em>ROLL</em> ${lo.toFixed(4)} to ${hi.toFixed(4)} <em>TO WIN</em>`;
  }
  $('uStatChance').textContent = ch ? ch.toFixed(4) + '%' : '0%';
  $('uFlow').innerHTML = `<span class="fb"><small>Your bet</small>${cv(uBet())}</span><span class="fa">${IC.chev}</span><span class="fb t"><small>${uSel ? 'You could win' : 'Pick an item'}</small>${uSel ? cv(uSel.v) : cv(0)}</span>`;
  $('uStatPay').innerHTML = uSel ? cv(uSel.v) : cv(0);
  const t = $('uTarget');
  if (!uSel) t.innerHTML = '<div class="h">Select an item to upgrade</div><div class="empty-t">Pick a limited from the list below.<br>The pricier the item, the lower your chance.</div><div></div>';
  else {
    const m = uBet() ? uSel.v / uBet() : 0;
    t.innerHTML = `<button class="x" id="uClear" aria-label="Clear item">✕</button><div class="h">Upgrading to</div><span class="tart" style="--rc:${RC[uSel.r]}"><span class="rar">${uSel.r}</span>${pic(uSel)}</span><div class="tn"></div><div class="tv">${cv(uSel.v)}</div><div class="tpills"><span>Multiplier<b>${m ? m.toFixed(2) + '×' : '0.00×'}</b></span><span>Chance<b>${ch ? ch.toFixed(2) + '%' : '0%'}</b></span></div>`;
    t.querySelector('.tn').textContent = uSel.n;
    $('uClear').onclick = () => { if (uSpinning || U.running) return; uSel = null; renderUpg(); renderUGrid(); };
  }
  const p = $('uPlay');
  if (U.mode === 'auto') { p.className = 'btn big ' + (U.running ? 'redb' : 'gold'); p.textContent = U.running ? 'Stop autobet' : 'Start autobet'; p.disabled = false; }
  else { p.className = 'btn big gold'; p.textContent = uSpinning ? 'Rolling…' : 'Play'; p.disabled = uSpinning; }
  const lock = uSpinning || U.running;
  ['uBet', 'uCustom', 'uCount'].forEach(id => $(id).disabled = lock);
  document.querySelectorAll('#uMult button,#uDir button,#uMode button,[data-ub]').forEach(b => b.disabled = lock);
}
function pickForMult(m) {
  const b = uBet(); if (!b) return toast('Enter a bet amount first', 'lose');
  const want = b * m, l = UPI.slice().sort((x, y) => x.v - y.v);
  uSel = l.find(i => i.v >= want) || l[l.length - 1];
  renderUpg(); renderUGrid();
}
async function upgradeOnce(spinMs) {
  const b = uBet();
  if (!uSel) { toast('Pick an item to upgrade to', 'lose'); return false; }
  if (!(b > 0)) { toast('Enter a bet amount', 'lose'); return false; }
  if (b >= uSel.v) { toast('Pick an item worth more than your bet', 'lose'); return false; }
  if (b > bal) { toast('Not enough coins. Tap + for free coins', 'lose'); return false; }
  uSpinning = true; renderUpg();
  let r;
  try { r = await call('upgrade', { p_bet: b, p_item: uSel.id, p_over: U.over }); }
  catch (e) { uSpinning = false; renderUpg(); toast(niceErr(e), 'lose'); return false; }
  showBal(bal - b);
  const target = Number(r.roll) / 100 * 360, base = uRot - (uRot % 360);
  uRot = base + 360 * (spinMs > 3000 ? 7 : 4) + target;
  const ptr = $('uPtr');
  ptr.style.transition = `transform ${spinMs}ms cubic-bezier(.08,.6,.06,1)`; SFX.upgrade(spinMs); $('uWheel').classList.add('spin'); ptr.style.transform = `rotate(${uRot}deg)`;
  $('uLab').textContent = 'Rolling…'; $('uRng').textContent = '';
  await sleep(spinMs + 80);
  const w = $('uWheel'); w.classList.remove('spin'); w.classList.toggle('win', r.win); w.classList.toggle('lose', !r.win);
  if (r.win) { SFX.upWin(); upSound = true; } else SFX.upLose();
  if (r.win) confetti(r.chance < 25); else { losePop(b); w.classList.remove('shake'); void w.offsetWidth; w.classList.add('shake'); }
  $('uPct').textContent = Number(r.roll).toFixed(4); $('uLab').textContent = r.win ? 'You won!' : 'Not this time';
  $('uRng').innerHTML = r.win ? `+${cv(r.value)}` : `Needed ${U.over ? 'over ' + (100 - r.chance).toFixed(4) : 'under ' + Number(r.chance).toFixed(4)}`;
  showBal(r.coins); bumpMe();
  if (r.win) toast(`Upgraded to <b>${esc(r.name)}</b>! +${cv(r.value)}`, 'win');
  uSpinning = false; renderUpg(true);
  return true;
}
$('uPlay').onclick = async () => {
  if (!requireAuth()) return;
  if (U.mode === 'auto') {
    if (U.running) { U.running = false; renderUpg(true); return; }
    let left = Math.max(0, Math.floor(+$('uCount').value || 0)); const inf = left === 0;
    U.running = true; renderUpg(true);
    while (U.running && (inf || left > 0)) { if (!await upgradeOnce(2800)) break; if (!inf) left--; await sleep(900); }
    U.running = false; renderUpg(true); return;
  }
  if (!uSpinning) upgradeOnce(6000);
};
$('uGrid').onclick = e => { const c = e.target.closest('[data-u]'); if (!c || uSpinning || U.running) return; uSel = UPI.find(i => i.id === +c.dataset.u); renderUpg(); renderUGrid(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
$('uMore').onclick = () => { uShow += 70; renderUGrid(); };
['uSearch', 'uMin', 'uMax'].forEach(id => $(id).oninput = () => { uShow = 70; renderUGrid(); });
$('uSort').onchange = () => { uShow = 70; renderUGrid(); };
$('uBet').oninput = () => { renderUpg(); renderUGrid(); };
document.querySelectorAll('[data-ub]').forEach(b => b.onclick = () => { const el = $('uBet'); el.value = b.dataset.ub === 'max' ? Math.floor(bal) : Math.max(1, Math.round(+el.value * +b.dataset.ub)); renderUpg(); renderUGrid(); });
$('uMult').onclick = e => { const b = e.target.closest('[data-x]'); if (!b) return; document.querySelectorAll('#uMult button').forEach(x => x.classList.toggle('on', x === b)); const custom = b.dataset.x === 'custom'; $('uCustomRow').hidden = !custom; pickForMult(custom ? Math.max(1.2, +$('uCustom').value || 2) : +b.dataset.x); };
$('uCustom').oninput = () => { const m = +$('uCustom').value; if (m >= 1.2) pickForMult(m); };
$('uDir').onclick = e => { const b = e.target.closest('[data-d]'); if (!b) return; U.over = b.dataset.d === 'over'; document.querySelectorAll('#uDir button').forEach(x => x.classList.toggle('on', x === b)); renderUpg(); };
$('uMode').onclick = e => { const b = e.target.closest('[data-m]'); if (!b || U.running) return; U.mode = b.dataset.m; document.querySelectorAll('#uMode button').forEach(x => x.classList.toggle('on', x === b)); $('uAutoOpts').hidden = U.mode !== 'auto'; renderUpg(); };
/* tick marks around the wheel */
$('uTicks').innerHTML = Array.from({ length: 100 }, (_, k) => { const big = k % 10 === 0, r1 = big ? 152 : 156, r2 = 162, an = (k / 100) * 2 * Math.PI - Math.PI / 2; return `<line x1="${200 + r1 * Math.cos(an)}" y1="${200 + r1 * Math.sin(an)}" x2="${200 + r2 * Math.cos(an)}" y2="${200 + r2 * Math.sin(an)}" stroke="${big ? '#ffffff55' : '#ffffff1c'}" stroke-width="${big ? 2.4 : 1.4}"/>`; }).join('');
renderUpg();

/* ---------- blackjack (the server deals; the deck never reaches the browser) ---------- */
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'], SUITS = ['♠', '♥', '♦', '♣'];
const BACK = '<span class="back"><img src="assets/dice-gold.png" alt=""></span>';
const cardHTML = (c, cls = '') => c < 0 ? `<span class="pcard hidden ${cls}" data-c="-1">${BACK}<span class="face"></span></span>`
  : `<span class="pcard ${cls}" data-c="${c}"><span class="face ${[1, 2].includes(Math.floor(c / 13)) ? 'red' : ''}"><span class="r">${RANKS[c % 13]}</span><span class="s">${SUITS[Math.floor(c / 13)]}</span></span>${BACK}</span>`;
let BJ = null, bjBusy = false, bjShown = { dealer: 0, hands: [] }, bjAnim = 0;
const BJ_GAP = 500, BJ_DEAL = 850, BJ_FLIP = 750;
/* blackjack total of the cards a player can currently see */
function bjCount(cardsEl) {
  let t = 0, aces = 0;
  cardsEl.querySelectorAll('.pcard').forEach(p => { const c = +p.dataset.c; if (c < 0 || p.dataset.wait) return; const r = c % 13; if (r === 0) { aces++; t += 11; } else t += Math.min(10, r + 1); });
  while (t > 21 && aces) { t -= 10; aces--; }
  return t;
}
function bjShowTot(cardsEl) { const tot = cardsEl.querySelector('.bjtot'); if (tot) tot.textContent = cardsEl.querySelector('.pcard:not([data-wait])') ? bjCount(cardsEl) : ''; }
/* first deal goes player, dealer, player, dealer like a real table */
const bjOrder = c => { const inD = !!c.closest('#bjDealer'), k = [...c.parentElement.querySelectorAll('.pcard')].indexOf(c); return k < 2 && BJ && BJ.dealer.length + BJ.hands[0].cards.length === 4 ? k * 2 + (inD ? 1 : 0) : 10 + k + (inD ? 100 : 0); };
const RES_TXT = { win: 'Win', blackjack: 'Blackjack!', lose: 'Lose', bust: 'Bust', push: 'Push' };
function bjCards(box, cards, already) {
  const el = box.querySelector('.bjcards');
  const have = el.children.length;
  for (let i = have; i < cards.length; i++) el.insertAdjacentHTML('beforeend', cardHTML(cards[i], i >= already ? 'deal' : ''));
}
function bjRender(st, animateDealer) {
  BJ = st;
  const hasGame = !!st, live = st && st.status !== 'done';
  $('bjTotal').innerHTML = cv(st ? st.hands.reduce((s, h) => s + Number(h.bet), 0) + Number(st.insurance || 0) : 0);
  if (!st) { $('bjDealer').innerHTML = '<div class="bjempty">Dealer</div>'; $('bjHands').innerHTML = '<div class="bjempty">Place a bet and press Deal</div>'; }
  else {
    if (!$('bjDealer').querySelector('.bjcards')) $('bjDealer').innerHTML = '<div class="bjcards"><span class="bjtot" id="bjDTot"></span></div><div class="bjres"></div>';
    const dEl = $('bjDealer').querySelector('.bjcards');
    // dealer: first two slots, then extras
    const shownD = [...dEl.querySelectorAll('.pcard')]; var flipped = false;
    st.dealer.forEach((c, i) => {
      if (i < shownD.length) {
        if (c >= 0 && shownD[i].classList.contains('hidden')) {           // reveal the hole card
          const fresh = document.createElement('div'); fresh.innerHTML = cardHTML(c); const nc = fresh.firstChild;
          nc.classList.add('hidden', 'flip'); nc.dataset.wait = 1; SFX.flip(); shownD[i].replaceWith(nc); flipped = true; setTimeout(() => { delete nc.dataset.wait; bjShowTot(dEl); }, BJ_FLIP * 0.6); requestAnimationFrame(() => requestAnimationFrame(() => nc.classList.remove('hidden')));
        }
      } else dEl.insertAdjacentHTML('beforeend', cardHTML(c, 'deal'));
    });
    
    const hb = $('bjHands');
    if (hb.children.length !== st.hands.length || hb.querySelector('.bjempty')) {
      hb.innerHTML = st.hands.map((_, i) => `<div class="bjhand" data-h="${i}"><div class="bjcards"><span class="bjtot"></span></div><div class="bjres"></div></div>`).join('');
      bjShown.hands = st.hands.map(() => 0);
    }
    st.hands.forEach((h, i) => {
      const box = hb.children[i];
      const cardsEl = box.querySelector('.bjcards'), cur = cardsEl.querySelectorAll('.pcard').length;
      if (cur > h.cards.length) { cardsEl.querySelectorAll('.pcard').forEach(x => x.remove()); }
      h.cards.forEach((c, k) => { if (k >= cardsEl.querySelectorAll('.pcard').length) cardsEl.insertAdjacentHTML('beforeend', cardHTML(c, 'deal')); });
      box.className = 'bjhand' + (live && st.hands.length > 1 && st.active === i + 1 ? ' active' : '') + (h.result ? ' res-' + h.result : '');
      const r = box.querySelector('.bjres');
      r.className = 'bjres ' + (h.result || ''); r.innerHTML = h.result ? RES_TXT[h.result] : (st.hands.length > 1 && live && st.active === i + 1 ? 'Your turn' : '');
    });
    // stagger newly dealt cards
    const fresh = [...document.querySelectorAll('#bjTable .pcard.deal:not([data-d])')], base = flipped ? BJ_FLIP : 0;
    fresh.forEach(c => c.dataset.wait = 1);
    fresh.sort((x, y) => bjOrder(x) - bjOrder(y)).forEach((c, i) => { c.dataset.d = 1; c.style.animationDelay = (base + i * BJ_GAP) + 'ms';
      setTimeout(() => SFX.card(), base + i * BJ_GAP);
      setTimeout(() => { delete c.dataset.wait; bjShowTot(c.parentElement); }, base + i * BJ_GAP + BJ_DEAL * 0.7); c.addEventListener('animationend', () => { c.classList.remove('deal'); c.style.animationDelay = ''; delete c.dataset.d; }, { once: true }); });
    bjAnim = fresh.length ? base + (fresh.length - 1) * BJ_GAP + BJ_DEAL : base;
    document.querySelectorAll('#bjTable .bjcards').forEach(bjShowTot);
  }
  $('bjIns').hidden = !(st && st.status === 'insurance');
  if (st && st.status === 'insurance') $('bjInsTxt').innerHTML = `The dealer shows an ace. Insure for ${cv(Math.floor(st.bet / 2))}? It pays 2 to 1 if the dealer has blackjack.`;
  const playing = st && st.status === 'playing';
  $('bjHit').disabled = $('bjStand').disabled = !playing || bjBusy;
  $('bjDouble').disabled = !playing || bjBusy || !st.can_double;
  $('bjSplit').disabled = !playing || bjBusy || !st.can_split;
  $('bjDeal').disabled = bjBusy || !!live;
  $('bjDeal').textContent = live ? 'Hand in play' : hasGame ? 'Deal again' : 'Deal';
  ['bjBet'].forEach(id => $(id).disabled = !!live || bjBusy);
  document.querySelectorAll('[data-bb]').forEach(b => b.disabled = !!live || bjBusy);
}
function bjFinishMsg(st) {
  const total = st.hands.reduce((s, h) => s + Number(h.bet), 0) + Number(st.insurance || 0), net = Number(st.payout) - total;
  const res = st.hands.map(h => RES_TXT[h.result]).join(' · ');
  if (net > 0) { toast(`${res}: +${cv(net)}`, 'win'); if (st.hands.some(h => h.result === 'blackjack')) confetti(false); }
  else if (net === 0) toast(`${res}: your bet is back`);
  else { losePop(-net); toast(`${res}: ${cv(-net)} lost`, 'lose'); }
}
async function bjSend(fn, args) {
  if (bjBusy) return; bjBusy = true; bjRender(BJ);
  try {
    const st = await call(fn, args);
    // show the cards arriving first; results only once the last card lands
    const pre = st.status === 'done' ? { ...st, status: 'dealing', dealer_total: '', hands: st.hands.map(h => ({ ...h, result: null })) } : st;
    // mid-hand finish (bust, stand, double): show your new card first, then the dealer reveals
    if (st.status === 'done' && BJ && BJ.status && BJ.status !== 'done' && BJ.dealer && BJ.dealer.length) {
      bjAnim = 0; bjRender({ ...pre, dealer: BJ.dealer });
      await sleep(bjAnim + 650);
    }
    bjAnim = 0; bjRender(pre);
    await sleep(bjAnim + 150);
    bjBusy = false; bjRender(st);
    if (st.status === 'done') {
      await sleep(250);
      if (st.coins != null) showBal(st.coins); else { const p = await call('my_profile').catch(() => null); if (p) showBal(p.coins); }
      bjFinishMsg(st); bumpMe();
    } else if (st.coins != null) showBal(st.coins);
  } catch (e) { bjBusy = false; bjRender(BJ); toast(niceErr(e), 'lose'); }
}
$('bjDeal').onclick = () => {
  if (!requireAuth()) return;
  const bet = Math.round(+$('bjBet').value);
  if (!(bet > 0)) return toast('Enter a bet amount', 'lose');
  if (bet > bal) return toast('Not enough coins. Tap + for free coins', 'lose');
  $('bjDealer').innerHTML = ''; $('bjHands').innerHTML = ''; BJ = null;
  bjSend('bj_start', { p_bet: bet });
};
$('bjHit').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'hit' });
$('bjStand').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'stand' });
$('bjDouble').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'double' });
$('bjSplit').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'split' });
$('bjYesIns').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'insure' });
$('bjNoIns').onclick = () => BJ && bjSend('bj_act', { p_id: BJ.id, p_action: 'no_insure' });
document.querySelectorAll('[data-bb]').forEach(b => b.onclick = () => { const el = $('bjBet'); el.value = b.dataset.bb === 'max' ? Math.floor(bal) : Math.max(1, Math.round(+el.value * +b.dataset.bb)); });
addEventListener('keydown', e => {
  if (!$('blackjack').classList.contains('on') || /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '')) return;
  const k = e.key.toLowerCase(), map = { h: 'bjHit', s: 'bjStand', d: 'bjDouble', p: 'bjSplit' };
  if (map[k] && !$(map[k]).disabled) $(map[k]).click();
});
async function resumeBj() { if (!me) return; try { const st = await call('bj_resume'); if (st) { $('bjDealer').innerHTML = ''; $('bjHands').innerHTML = ''; bjRender(st); } } catch (e) { } }
bjRender(null);

/* ---------- admin (server checks is_admin on every call) ---------- */
let ADM = [];
async function loadAdmin(q) {
  if (!me || !me.admin) return;
  try {
    const st = await call('admin_stats');
    $('aStats').innerHTML = [['Players', fmt(st.players)], ['New today', fmt(st.new_today)], ['Coins held', cv(st.coins)], ['Total wagered', cv(st.wagered)], ['Cases opened', fmt(st.cases)], ['Chatting (1h)', fmt(st.online_chat)]].map(([k, v]) => `<div>${k}<b>${v}</b></div>`).join('');
    ADM = await call('admin_find', { p_q: q || '' }) || [];
    $('aRows').innerHTML = ADM.length ? ADM.map((p, i) => `<div class="arow" data-i="${i}"><span class="nm"><span class="av bacon">${BACON}</span><span class="n" data-uid="${esc(p.id)}"></span>${p.is_admin ? '<i class="tag">ADMIN</i>' : ''}${p.lb_hidden ? '<i class="tag off">HIDDEN</i>' : ''}</span><span class="em"></span><span>${cv(p.coins)}</span><span>${cv(p.wagered)}</span><span class="give"><input type="number" min="1" placeholder="Amount" aria-label="Amount"><button class="g" data-act="give">Give</button><button class="t" data-act="take">Take</button></span><span class="abtns"><button class="adm-t" data-act="lb">${p.lb_hidden ? 'Show on leaderboard' : 'Hide from leaderboard'}</button><button class="adm-t" data-act="admin">${p.is_admin ? 'Remove admin' : 'Make admin'}</button></span></div>`).join('') : '<div class="lbempty">No players found.</div>';
    $('aRows').querySelectorAll('.arow').forEach(r => { const p = ADM[+r.dataset.i]; r.querySelector('.n').textContent = p.username; r.querySelector('.em').textContent = p.email || ''; });
  } catch (e) { toast(niceErr(e), 'lose'); }
}
$('aFind').onsubmit = e => { e.preventDefault(); loadAdmin($('aQ').value.trim()); };
$('aRows').onclick = async e => {
  const n = e.target.closest('.n[data-uid]'); if (n) return openProfile(n.dataset.uid);
  const b = e.target.closest('[data-act]'); if (!b) return;
  const row = b.closest('.arow'), p = ADM[+row.dataset.i];
  try {
    if (b.dataset.act === 'lb') {
      await call('admin_set_lb_hidden', { p_user: p.id, p_hidden: !p.lb_hidden });
      toast(p.lb_hidden ? `${esc(p.username)} is back on the leaderboard` : `${esc(p.username)} is hidden from the leaderboard. Their wagers won't count`, 'win');
    } else if (b.dataset.act === 'admin') {
      if (!confirmBox(`${p.is_admin ? 'Remove admin from' : 'Make'} ${p.username}${p.is_admin ? '' : ' an admin'}?`)) return;
      await call('admin_set_admin', { p_user: p.id, p_on: !p.is_admin }); toast('Done', 'win');
    } else {
      const amt = Math.round(+row.querySelector('input').value || 0); if (!(amt > 0)) return toast('Enter an amount', 'lose');
      const nb = await call('admin_coins', { p_user: p.id, p_amount: b.dataset.act === 'give' ? amt : -amt });
      toast(`${esc(p.username)} now has ${cv(nb)}`, 'win'); if (p.id === me.id) showBal(nb);
    }
    loadAdmin($('aQ').value.trim());
  } catch (err) { toast(niceErr(err), 'lose'); }
};
const confirmBox = t => window.confirm(t);

/* ---------- provably fair ---------- */
const FAIR_IC = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 2l8 3v6c0 5-3.4 9.4-8 11-4.6-1.6-8-6-8-11V5z" opacity=".9"/><path d="M8.5 12l2.4 2.4L15.8 9.6" stroke="#14161b" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const PF_GAME = { cases: 'Cases', mines: 'Mines', upgrader: 'Upgrader', blackjack: 'Blackjack', rewards: 'Rewards', battles: 'Battles' };
let PF = { tab: 'seeds', state: null, bets: [], v: null };
async function pfFloats(seed, client, nonce, n) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(seed), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const out = [];
  for (let c = 0; c < n; c++) { const h = new DataView(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${client}:${nonce}:${c}`))); out.push(h.getUint32(0) / 4294967296); }
  return out;
}
async function sha256hex(t) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join(''); }
const pickW = (items, f) => { const tot = items.reduce((s, i) => s + i.w, 0), x = f * tot; let c = 0; for (const it of items.slice().sort((a, b) => a.idx - b.idx)) { c += it.w; if (c > x) return it; } return items[items.length - 1]; };
const cardName = c => RANKS[c % 13] + SUITS[Math.floor(c / 13)];
/* recompute a bet's result from its seeds, exactly like the server does */
async function pfVerify(v) {
  const hash = await sha256hex(v.seed);
  let out = `<div>Server seed hash: <span class="pfmono" style="display:inline;padding:2px 6px">${hash.slice(0, 16)}…</span>${v.hash ? (hash === v.hash ? ' <b>✓ matches</b>' : ' ✗ does not match') : ''}</div>`;
  if (v.game === 'cases') {
    const c = caseById(v.detail.case); if (!c) return out + '<div>Unknown case.</div>';
    const [f] = await pfFloats(v.seed, v.client, v.nonce, 1), it = pickW(c.items, f);
    out += `<div>Roll ${f.toFixed(8)} → <b>${esc(it.n)}</b> (${cv(it.v)}) from ${esc(c.name)}</div>`;
  } else if (v.game === 'rewards') {
    const p = PACKS.find(x => x.level === +v.detail.level); if (!p) return out;
    const [f] = await pfFloats(v.seed, v.client, v.nonce, 1), it = pickW(p.items, f);
    out += `<div>Roll ${f.toFixed(8)} → <b>${esc(it.n)}</b> from the level ${p.level} reward</div>`;
  } else if (v.game === 'upgrader') {
    const [f] = await pfFloats(v.seed, v.client, v.nonce, 1);
    out += `<div>Roll <b>${(Math.floor(f * 1000000) / 10000).toFixed(4)}</b> (0 to 99.9999)</div>`;
  } else if (v.game === 'mines') {
    const n = +v.detail.size, m = +v.detail.mines, fl = await pfFloats(v.seed, v.client, v.nonce, n);
    const mines = fl.map((f, t) => [t, f]).sort((a, b) => a[1] - b[1]).slice(0, m).map(p => p[0] + 1).sort((a, b) => a - b);
    out += `<div>Mines on tiles <b>${mines.join(', ')}</b> (counting 1 to ${n}, left to right, top to bottom)</div>`;
  } else if (v.game === 'blackjack') {
    const fl = await pfFloats(v.seed, v.client, v.nonce, 312);
    const shoe = fl.map((f, c) => [c % 52, f]).sort((a, b) => a[1] - b[1]).map(p => p[0]);
    out += `<div>First cards from the shoe: <b>${shoe.slice(0, 10).map(cardName).join(' ')}</b></div><div class="mut small">Dealt in order: you, dealer, you, dealer, then hits.</div>`;
  } else if (v.game === 'battles') {
    const b = BT[v.battle]; if (!b) return out + '<div>Open the battle to verify it.</div>';
    const n = b.seats.length * b.cases.length + (b.jackpot ? 1 : 0), fl = await pfFloats(v.seed, v.client, 0, n);
    let k = 0, rows = '';
    b.seats.forEach((s, i) => { rows += `<div>${esc(nameOf(s))}: ${b.cases.map(c => esc(pickW(c.items, fl[k++]).n)).join(', ')}</div>`; });
    if (b.jackpot) rows += `<div>Jackpot roll <b>${fl[k].toFixed(8)}</b></div>`;
    out += rows;
  }
  return out;
}
function pfRender() {
  document.querySelectorAll('#fairModal .pftabs [data-pft]').forEach(b => b.classList.toggle('on', b.dataset.pft === PF.tab));
  const B = $('pfBody');
  if (PF.tab === 'how') {
    B.innerHTML = `<p class="pfnote">Every result comes from three things: a <b>server seed</b> (secret until you change seeds, but its SHA-256 hash is shown before you bet, so it can't be swapped), your <b>client seed</b> (you can set it to anything), and a <b>nonce</b> that goes up by one with every bet.</p>
    <p class="pfnote">Each random number is the first 4 bytes of <span class="pfmono" style="display:inline;padding:2px 6px">HMAC-SHA256(server seed, "client seed:nonce:n")</span> divided by 2³², for n = 0, 1, 2…</p>
    <p class="pfnote"><b>Cases & rewards</b>: one number picks the item using the odds shown on the case.<br><b>Upgrader</b>: one number × 100 is your roll.<br><b>Mines</b>: one number per tile; the lowest numbers are the mines.<br><b>Blackjack</b>: one number per card in the 6-deck shoe; cards are dealt from lowest to highest.<br><b>Battles</b>: each battle has its own seed (hash shown before it starts, seed shown after), the client seed is the battle id and the nonce is 0. Numbers go player 1 round 1, player 1 round 2… then the jackpot roll.</p>
    <p class="pfnote">To check a bet, change your client seed (this reveals the old server seed), then press Verify on that bet.</p>`;
    return;
  }
  if (!me) { B.innerHTML = '<p class="pfnote">Sign in to see your seeds and bets.</p>'; return; }
  if (PF.tab === 'seeds') {
    const st = PF.state, cp = v => `<button class="pfcp" data-copy="${esc(v)}" title="Copy" aria-label="Copy"><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><rect x=\"8\" y=\"8\" width=\"13\" height=\"13\" rx=\"3\"/><path d=\"M5 16H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v1\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></svg></button>`;
    if (!st) { B.innerHTML = '<div class="loading">Loading…</div>'; return; }
    if (!PF.newClient) PF.newClient = Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10);
    B.innerHTML = `<div class="pfl">Active client seed</div><div class="pfv"><span>${esc(st.client)}</span>${cp(st.client)}</div>
      <div class="pfl">Active server seed (Hashed)</div><div class="pfv"><span>${esc(st.hash)}</span>${cp(st.hash)}</div>
      <div class="pfl">Nonce</div><div class="pfv"><span>${fmt(st.nonce)}</span>${cp(String(st.nonce))}</div>
      <div class="pfsep"></div>
      <div class="pfl">New client seed</div><div class="pfv edit"><input id="pfNew" value="${esc(PF.newClient)}" maxlength="64" aria-label="New client seed"></div>
      <div class="pfl">Next server seed (Hashed)</div><div class="pfv"><span>${esc(st.next_hash || '')}</span>${cp(st.next_hash || '')}</div>
      <button class="btn gold pfrot" id="pfRot">Rotate seed</button>
      ${PF.revealed ? `<div class="pfl" style="margin-top:16px">Previous server seed (revealed)</div><div class="pfv"><span>${esc(PF.revealed)}</span>${cp(PF.revealed)}</div>` : ''}
      <p class="pfwarn">Rotating reveals your current server seed so you can verify past bets in My bets. You can't rotate during a Mines round or Blackjack hand.</p>`;
    $('pfNew').oninput = e => PF.newClient = e.target.value;
    $('pfRot').onclick = async () => { try { const x = await call('pf_rotate', { p_client: $('pfNew').value.trim() }); PF.revealed = x.revealed; PF.newClient = ''; await pfLoad(); toast('Seed rotated. Your previous server seed is revealed'); } catch (e) { toast(niceErr(e), 'lose'); } };
  } else if (PF.tab === 'bets') {
    B.innerHTML = PF.bets.length ? `<div class="pfbets">${PF.bets.map((b, i) => `<div class="pfbet"><span>${PF_GAME[b.game] || b.game}${b.detail && b.detail.case ? ' · ' + esc((caseById(b.detail.case) || {}).name || '') : ''}</span><span class="mut">#${b.nonce}</span><span class="h" title="${esc(b.seed_hash)}">${esc(b.seed_hash)}</span><button data-pfv="${i}" ${b.server_seed ? '' : 'disabled title="Change seeds to reveal this server seed"'}>${b.server_seed ? 'Verify' : 'Hidden'}</button></div>`).join('')}</div>` : '<p class="pfnote">No bets yet.</p>';
  } else if (PF.tab === 'verify') {
    const v = PF.v || { game: 'cases', seed: '', client: '', nonce: 0, detail: {} };
    B.innerHTML = `<div class="pff"><label>Game</label><select class="fsel" id="pvGame">${['cases', 'upgrader', 'mines', 'blackjack', 'rewards'].map(g => `<option value="${g}" ${v.game === g ? 'selected' : ''}>${PF_GAME[g]}</option>`).join('')}</select></div>
      <div class="pff"><label>Server seed</label><input class="tin" id="pvSeed" value="${esc(v.seed)}"></div>
      <div class="pff"><label>Client seed</label><input class="tin" id="pvClient" value="${esc(v.client)}"></div>
      <div class="pff"><label>Nonce</label><input class="tin" id="pvNonce" type="number" min="0" value="${v.nonce}"></div>
      <div class="pff" id="pvExtra"></div>
      <button class="btn gold" id="pvGo">Verify</button><div id="pvOut"></div>`;
    const extra = () => { const g = $('pvGame').value, d = v.detail || {};
      $('pvExtra').innerHTML = g === 'cases' ? `<label>Case</label><select class="fsel" id="pvCase">${onSale().map(c => `<option value="${c.id}" ${d.case === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>`
        : g === 'mines' ? `<label>Grid & mines</label><div class="row"><select class="fsel" id="pvSize">${[16, 25, 36, 49, 64].map(n => `<option ${+d.size === n ? 'selected' : ''}>${n}</option>`).join('')}</select><input class="tin" id="pvMines" type="number" min="1" value="${d.mines || 3}"></div>`
        : g === 'rewards' ? `<label>Level</label><select class="fsel" id="pvLvl">${PACKS.map(p => `<option ${+d.level === p.level ? 'selected' : ''}>${p.level}</option>`).join('')}</select>` : ''; };
    extra(); $('pvGame').onchange = extra;
    $('pvGo').onclick = async () => {
      const g = $('pvGame').value, d = g === 'cases' ? { case: $('pvCase').value } : g === 'mines' ? { size: +$('pvSize').value, mines: +$('pvMines').value } : g === 'rewards' ? { level: +$('pvLvl').value } : {};
      PF.v = { game: g, seed: $('pvSeed').value.trim(), client: $('pvClient').value.trim(), nonce: +$('pvNonce').value || 0, detail: d, hash: v.hash };
      if (!PF.v.seed) return toast('Enter the server seed', 'lose');
      try { $('pvOut').innerHTML = `<div class="pfres">${await pfVerify(PF.v)}</div>`; } catch (e) { $('pvOut').innerHTML = `<div class="pfres bad">Could not verify: ${esc(e.message)}</div>`; }
    };
    if (PF.v && PF.v.seed && PF.v.auto) { PF.v.auto = false; $('pvGo').click(); }
  }
}
async function pfLoad() {
  if (!me) return pfRender();
  try { const [st, bets] = await Promise.all([call('pf_state'), call('pf_my_bets', { p_limit: 40 })]); PF.state = st; PF.bets = bets || []; } catch (e) { toast(niceErr(e), 'lose'); }
  pfRender();
}
function openFair(tab) { PF.tab = tab || 'seeds'; $('fairModal').hidden = false; pfRender(); pfLoad(); }
$('fairModal').onclick = e => {
  if (e.target === $('fairModal') || e.target.closest('[data-pfclose]')) { $('fairModal').hidden = true; return; }
  const cpb = e.target.closest('[data-copy]'); if (cpb) { navigator.clipboard && navigator.clipboard.writeText(cpb.dataset.copy).then(() => toast('Copied')).catch(() => {}); return; }
  const t = e.target.closest('[data-pft]'); if (t) { e.preventDefault(); PF.tab = t.dataset.pft; pfRender(); return; }
  const v = e.target.closest('[data-pfv]');
  if (v) {
    const b = PF.bets[+v.dataset.pfv], row = v.closest('.pfbet'), old = row.querySelector('.pfres');
    if (old) { old.remove(); return; }
    const box = document.createElement('div'); box.className = 'pfres'; box.textContent = 'Checking…'; row.appendChild(box);
    pfVerify({ game: b.game, seed: b.server_seed, client: b.client_seed, nonce: +b.nonce, detail: b.detail || {}, hash: b.seed_hash })
      .then(h => box.innerHTML = h).catch(err => { box.className = 'pfres bad'; box.textContent = 'Could not verify: ' + err.message; });
  }
};
document.addEventListener('click', e => { const b = e.target.closest('[data-fair]'); if (b) openFair(); });
async function verifyBattle(id) {
  const b = BT[id]; if (!b || !b.pfSeed) return;
  openFair('verify');
  $('pfBody').innerHTML = `<div class="pff"><label>Battle seed</label><code>${esc(b.pfSeed)}</code></div><div class="pff"><label>Client seed (battle id)</label><code>${esc(b.id)}</code></div><div class="pfres">${await pfVerify({ game: 'battles', seed: b.pfSeed, client: b.id, nonce: 0, hash: b.pfHash, battle: b.id })}</div>`;
}

/* ---------- gentle snowfall ---------- */
(() => {
  const c = $('snow'); if (!c || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const x = c.getContext('2d'); let W, H, dpr, flakes = [];
  const size = () => { dpr = Math.min(2, devicePixelRatio || 1); W = innerWidth; H = innerHeight; c.width = W * dpr; c.height = H * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.round(Math.min(110, W * H / 14000)); flakes = Array.from({ length: n }, () => mk(true)); };
  const mk = any => ({ x: Math.random() * W, y: any ? Math.random() * H : -10, r: .6 + Math.random() * 2.1, s: .25 + Math.random() * .7, d: Math.random() * Math.PI * 2, o: .25 + Math.random() * .5 });
  addEventListener('resize', size); size();
  let last = performance.now();
  (function tick(now) {
    const dt = Math.min(50, now - last) / 16.7; last = now;
    if (!document.hidden) {
      x.clearRect(0, 0, W, H);
      for (const f of flakes) {
        f.y += f.s * dt; f.d += .012 * dt; f.x += Math.sin(f.d) * .35 * dt;
        if (f.y > H + 6) Object.assign(f, mk(false));
        x.globalAlpha = f.o; x.fillStyle = '#fff'; x.beginPath(); x.arc(f.x, f.y, f.r, 0, 6.283); x.fill();
      }
    }
    requestAnimationFrame(tick);
  })(last);
})();

/* ---------- weekly leaderboard ---------- */
let LB = null, lbEnd = 0;
const pad2 = n => String(Math.max(0, n)).padStart(2, '0');
async function loadLb() {
  if (!sb) return;
  try { LB = await call('get_leaderboard'); lbEnd = Date.parse(LB.ends_at); renderLb(); resolveNames((LB.top || []).map(r => r.user_id)); }
  catch (e) { $('lbRows').innerHTML = `<div class="lbempty">${esc(niceErr(e))}</div>`; }
}
function lbUser(r, you) { return `<span class="u"><span class="av bacon" data-uid="${esc(r.user_id)}">${BACON}</span>${lvlBadge(r.level || levelInfo(PW[r.user_id] || 0).level)}<span class="n" data-uid="${esc(r.user_id)}"></span>${you ? '<span class="you">YOU</span>' : ''}</span>`; }
function renderLb() {
  if (!LB) return;
  const P = LB.prizes.map(Number), top = LB.top || [];
  const pod = [1, 0, 2].map(i => {
    const r = top[i], cls = 'p' + (i + 1);
    return `<div class="pod ${cls} ${r ? '' : 'empty'}"><span class="ava">${BACON}</span><span class="rib">${IC.crown}</span><div class="nm">${r ? lvlBadge(r.level) + '<span data-uid="' + esc(r.user_id) + '"></span>' : '<span>Up for grabs</span>'}</div><div class="wg">Wagered${cv(r ? r.wagered : 0)}</div><div class="pz">${cv(P[i])}</div></div>`;
  }).join('');
  $('lbPodium').innerHTML = pod;
  [1, 0, 2].forEach((i, k) => { const r = top[i]; if (r) $('lbPodium').children[k].querySelector('[data-uid]').textContent = r.username; });
  if (me && LB.me) {
    const rk = LB.me.rank, pr = rk && rk <= 10 ? P[rk - 1] : 0;
    $('lbMe').innerHTML = `<div class="lbrow me"><span class="rk">${rk || ''}</span>${lbUser({ user_id: me.id, level: levelInfo(PW[me.id] || 0).level }, true)}<span class="r wgc">${cv(LB.me.wagered)}</span><span class="r pz">${pr ? cv(pr) : cv(0)}</span></div>`;
    $('lbMe').querySelector('.n').textContent = me.username;
  } else $('lbMe').innerHTML = '';
  $('lbRows').innerHTML = top.length ? top.map(r => `<div class="lbrow ${r.rank <= 3 ? 'r' + r.rank : ''}"><span class="rk">${r.rank}</span>${lbUser(r, me && r.user_id === me.id)}<span class="r wgc">${cv(r.wagered)}</span><span class="r pz">${r.rank <= 10 ? cv(P[r.rank - 1]) : cv(0)}</span></div>`).join('')
    : '<div class="lbempty">No wagers yet this week. Play any game to take first place.</div>';
  $('lbRows').querySelectorAll('.lbrow').forEach((row, k) => { row.querySelector('.n').textContent = top[k].username; });
  const last = LB.last_week || [];
  $('lbLast').hidden = !last.length;
  $('lbLastList').innerHTML = last.map(r => `<li><b></b>: wagered ${cv(r.wagered)}, won ${cv(r.prize)}</li>`).join('');
  $('lbLastList').querySelectorAll('b').forEach((b, k) => b.textContent = last[k].username);
  tickLb();
}
function tickLb() {
  if (!lbEnd) return;
  let t = Math.max(0, Math.floor((lbEnd - Date.now()) / 1000));
  $('cdD').textContent = pad2(Math.floor(t / 86400)); t %= 86400;
  $('cdH').textContent = pad2(Math.floor(t / 3600)); t %= 3600;
  $('cdM').textContent = pad2(Math.floor(t / 60)); $('cdS').textContent = pad2(t % 60);
  if (lbEnd - Date.now() < -2000 && $('leaderboard').classList.contains('on')) { lbEnd = 0; setTimeout(loadLb, 1500); }
}
setInterval(tickLb, 1000);
setInterval(() => { if ($('leaderboard').classList.contains('on')) loadLb(); }, 30000);
$('leaderboard').onclick = e => { const u = e.target.closest('[data-uid]'); if (u) openProfile(u.dataset.uid); };

/* ---------- rewards: a free pack every 10 levels, once a day ---------- */
const PK_THEME = { 10: ['#6b4a2c', '#2e2013'], 20: ['#4f5866', '#23272f'], 30: ['#7a4630', '#2f1b14'], 40: ['#6d7380', '#2a2d34'], 50: ['#7a5d2c', '#30230f'],
  60: ['#2f6b5c', '#132a24'], 70: ['#2f4f8a', '#121d33'], 80: ['#8a2f3c', '#331217'], 90: ['#5b3a8a', '#22163a'], 100: ['#8f8a7e', '#2f2d29'] };
let PACKS = [], CLAIMS = {}, rwCur = null, rwSpinning = false;
async function loadPacks() {
  if (!sb) return;
  const [p, i] = await Promise.all([sb.from('reward_packs').select('level,name').order('level'), sb.from('reward_pack_items').select('level,idx,item_id,weight').order('idx')]);
  if (p.error || i.error) { $('rwGrid').innerHTML = '<div class="loading">Rewards are not set up yet. Run update 4 in Supabase.</div>'; return; }
  PACKS = p.data.map(pk => {
    const items = i.data.filter(x => x.level === pk.level).map(x => {
      const u = UPI.find(y => y.id === Number(x.item_id)) || { n: 'Limited', v: 0, r: 'common', art: ART.crown('#9aa3b8', '#fff'), img: null };
      return { idx: x.idx, w: x.weight, id: u.id, get n() { return u.n; }, get v() { return u.v; }, get r() { return u.r; }, get art() { return u.art; }, get img() { return u.img; } };
    }).sort((a, b) => a.idx - b.idx);
    return { level: pk.level, name: pk.name, items, tot: items.reduce((s, x) => s + x.w, 0), top: items.slice().sort((a, b) => b.v - a.v)[0] };
  });
  renderRewards();
}
async function loadClaims() {
  CLAIMS = {};
  if (me && sb) { const { data } = await sb.from('reward_claims').select('level,claimed_at'); (data || []).forEach(c => CLAIMS[c.level] = Date.parse(c.claimed_at) + 86400000); }
  renderRewards();
}
const myLevel = () => me ? levelInfo(PW[me.id] || 0).level : 0;
const left = ms => { const m = Math.max(1, Math.ceil(ms / 60000)); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
function packState(pk) {
  if (!me) return { cls: 'locked', btn: '<button class="btn dark" data-signin="1">Sign in to open</button>' };
  if (myLevel() < pk.level) return { cls: 'locked', btn: `<button class="btn dark" disabled>Reach level ${pk.level}</button>` };
  const next = CLAIMS[pk.level];
  if (next && next > Date.now()) return { cls: 'cool', btn: `<button class="btn dark" disabled>Opens in ${left(next - Date.now())}</button>` };
  return { cls: 'ready', btn: `<button class="btn gold" data-pk="${pk.level}">Open</button>` };
}
function renderRewards() {
  if (!PACKS.length || $('rwList').hidden) return;
  $('rwGrid').innerHTML = PACKS.map(pk => {
    const st = packState(pk), [c1, c2] = PK_THEME[pk.level] || ['#444', '#222'];
    const show = pk.items.slice().sort((a, b) => b.v - a.v).slice(0, 4);
    return `<div class="pk ${st.cls}"><div class="pk-card" data-view="${pk.level}" style="--pk1:${c1};--pk2:${c2}" title="See what's inside"><span class="pk-lv">LEVEL ${pk.level}</span><div class="pk-items">${show.map(it => `<span>${pic(it)}</span>`).join('')}</div>${st.cls === 'locked' ? `<span class="pk-lock"><i>${IC.lock}</i></span>` : ''}</div><b>Level ${pk.level}</b>${st.btn}</div>`;
  }).join('');
}
function showRw(view) { $('rwList').hidden = view; $('rwView').hidden = !view; }
function openPackView(level) {
  rwCur = PACKS.find(p => p.level === level); if (!rwCur) return;
  showRw(true); $('rwName').textContent = `Level ${rwCur.level} reward`;
  $('rwItems').innerHTML = rwCur.items.slice().sort((a, b) => b.v - a.v).map(i => `<div class="ic2" style="--rc:${RC[i.r]}"><span class="odds">${(i.w / rwCur.tot * 100).toFixed(2)}%</span><span class="art">${pic(i)}</span><b>${esc(i.n)}</b>${cv(i.v)}</div>`).join('');
  idleH($('rwReel'), rwCur); updRwBtn();
}
function updRwBtn() {
  if (!rwCur) return;
  const st = packState(rwCur), b = $('rwOpen');
  b.className = 'btn ' + (!me || st.cls === 'ready' ? 'gold' : 'dark');
  b.disabled = rwSpinning || st.cls !== 'ready' && !!me;
  b.textContent = rwSpinning ? 'Opening…' : !me ? 'Sign in to open' : st.cls === 'ready' ? 'Open pack (free)' : myLevel() < rwCur.level ? `Reach level ${rwCur.level}` : `Opens in ${left(CLAIMS[rwCur.level] - Date.now())}`;
}
$('rwGrid').onclick = e => {
  if (e.target.closest('[data-signin]')) return openAuth('login');
  const o = e.target.closest('[data-pk]'); if (o) { openPackView(+o.dataset.pk); $('rwOpen').click(); return; }
  const v = e.target.closest('[data-view]'); if (v) openPackView(+v.dataset.view);
};
$('rwBack').onclick = () => { if (rwSpinning) return; showRw(false); renderRewards(); };
$('rwOpen').onclick = async () => {
  if (!requireAuth() || rwSpinning || !rwCur || packState(rwCur).cls !== 'ready') return;
  rwSpinning = true; updRwBtn(); $('rwBack').disabled = true;
  try {
    const r = await call('claim_pack', { p_level: rwCur.level });
    CLAIMS[rwCur.level] = Date.parse(r.next_at) || Date.now() + 86400000;
    const w = rwCur.items.find(i => i.idx === r.idx) || rwCur.items[0];
    await hspin($('rwReel'), rwCur, w, 4600);
    showBal(r.coins); bumpMe(); confetti(false);
    toast(`Level ${rwCur.level} reward: <b>${esc(w.n)}</b> +${cv(w.v)}`, 'win');
  } catch (e) { toast(niceErr(e), 'lose'); }
  rwSpinning = false; $('rwBack').disabled = false; updRwBtn();
};
setInterval(() => { if ($('rewards').classList.contains('on')) { renderRewards(); updRwBtn(); } }, 30000);

/* ---------- levels, profiles, tips, transactions ---------- */
let LV = [], myProf = null, primed = false, bumpT = null, userCh = null;
async function loadLevels() { if (!sb) return; const { data } = await sb.from('levels').select('level,xp').order('level'); LV = (data || []).map(r => ({ level: r.level, xp: Number(r.xp) })); }
function levelInfo(w) {
  w = Number(w) || 0;
  if (!LV.length) return { level: 1, pct: 0, toGo: 0 };
  let i = 0; while (i + 1 < LV.length && LV[i + 1].xp <= w) i++;
  const cur = LV[i], next = LV[i + 1];
  if (!next) return { level: cur.level, pct: 100, toGo: 0 };
  return { level: cur.level, pct: Math.max(0, Math.min(100, (w - cur.xp) / (next.xp - cur.xp) * 100)), toGo: next.xp - w };
}
const lvlBadge = l => `<span class="lvl t${l >= 100 ? 6 : l >= 75 ? 5 : l >= 50 ? 4 : l >= 25 ? 3 : l >= 10 ? 2 : 1}" title="Level ${l}">${l}</span>`;
const fmtDate = t => new Date(t).toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
function profileCard(p, tip) {
  const lv = levelInfo(p.wagered);
  return `<div class="pc-top"><span class="av bacon">${BACON}</span><div class="pc-id"><div class="pc-n"><b class="pnm"></b>${lvlBadge(lv.level)}</div><span class="mut small">Joined ${fmtDate(p.joined)}</span></div>${tip ? '<button class="btn gold" id="tipOpen">Tip user</button>' : ''}</div>
  <div class="lvrow"><b>Level ${lv.level}</b><span class="mut">${lv.toGo ? fmt(lv.toGo) + ' coins to go' : 'Max level'}</span></div><div class="lvbar"><i style="width:${lv.pct.toFixed(1)}%"></i></div>
  <div class="pc-cards"><div><b>${cv(p.wagered)}</b><span>Total wagered</span></div><div><b>${esc(p.favorite || 'None yet')}</b><span>Favorite game</span></div><div><b>${cv(p.rewards)}</b><span>Rewards claimed</span></div></div>`;
}
/* someone else's profile (or your own) in a pop-up */
let pmUid = null;
async function openProfile(uid) {
  if (!sb || !uid || uid.startsWith('bot:')) return;
  pmUid = uid; $('tipForm').hidden = true; $('tipErr').textContent = '';
  $('pmBody').innerHTML = '<div class="loading">Loading profile…</div>'; $('profModal').hidden = false;
  try {
    const p = await call('get_profile', { p_id: uid });
    if (pmUid !== uid) return;
    if (!p) { $('pmBody').innerHTML = '<div class="loading">Player not found.</div>'; return; }
    PW[uid] = Number(p.wagered) || 0;
    $('pmBody').innerHTML = profileCard(p, !(me && me.id === uid));
    $('pmBody').querySelector('.pnm').textContent = p.username;
    if ($('tipOpen')) $('tipOpen').onclick = () => { if (!requireAuth()) return; $('tipForm').hidden = false; $('tipAmt').focus(); $('tipAmt').select(); };
  } catch (e) { $('pmBody').innerHTML = `<div class="loading">${esc(niceErr(e))}</div>`; }
}
$('pmClose').onclick = () => { $('profModal').hidden = true; };
$('profModal').onclick = e => { if (e.target === $('profModal')) $('profModal').hidden = true; };
addEventListener('keydown', e => { if (e.key === 'Escape') $('profModal').hidden = true; });
$('tipCancel').onclick = () => { $('tipForm').hidden = true; };
document.querySelectorAll('[data-tip]').forEach(b => b.onclick = () => { $('tipAmt').value = b.dataset.tip; });
$('tipForm').onsubmit = async e => {
  e.preventDefault(); $('tipErr').textContent = '';
  const amt = Math.floor(+$('tipAmt').value);
  if (!(amt >= 100)) return $('tipErr').textContent = 'The smallest tip is 100 coins.';
  if (amt > bal) return $('tipErr').textContent = "You don't have that many coins.";
  $('tipGo').disabled = true;
  try {
    const r = await call('tip_user', { p_to: pmUid, p_amount: amt });
    showBal(r.coins); bumpMe(); $('tipForm').hidden = true;
    toast(`You tipped <b>${esc(r.to)}</b> ${cv(r.amount)}`, 'win');
  } catch (err) { $('tipErr').textContent = niceErr(err); }
  $('tipGo').disabled = false;
};
/* keep your own level and stats fresh */
function bumpMe(now) {
  if (!me) return;
  clearTimeout(bumpT);
  bumpT = setTimeout(async () => {
    try {
      const p = await call('get_profile', { p_id: me.id }); if (!p) return;
      const old = levelInfo(PW[me.id] || 0).level, nl = levelInfo(p.wagered).level;
      PW[me.id] = Number(p.wagered) || 0; myProf = p; myProf.email = me.email;
      if (primed && nl > old) toast(`Level up! You're now level ${nl} ${lvlBadge(nl)}`, 'win');
      primed = true; namesVer++; renderAuth(); renderChat(); renderRewards(); updRwBtn();
      if ($('profile').classList.contains('on')) renderProfilePage();
    } catch (e) { /* try again next time */ }
  }, now ? 0 : 700);
}
setInterval(async () => {
  const ids = Object.keys(PN).filter(Boolean).slice(0, 200); if (!ids.length || !sb) return;
  const { data } = await sb.from('profiles').select('id,wagered').in('id', ids);
  (data || []).forEach(p => { if (!me || p.id !== me.id) PW[p.id] = Number(p.wagered) || 0; });
  namesVer++; renderChat();
}, 60000);
/* your profile page */
function openMyProfile() { if (!requireAuth()) return; nav('profile'); renderProfilePage(); loadTx(true); bumpMe(true); }
function renderProfilePage() {
  if (!me) { nav('mines'); return; }
  const p = myProf || { username: me.username, joined: Date.now(), wagered: 0, returned: 0, rewards: 0 };
  $('ppCard').innerHTML = profileCard(p, false); $('ppCard').querySelector('.pnm').textContent = me.username;
  $('ppName').textContent = me.username; $('ppEmail').textContent = me.email || '';
  const profit = (Number(p.returned) || 0) - (Number(p.wagered) || 0);
  const rows = [['Total wagered', cv(p.wagered || 0)], ['Total returned', cv(p.returned || 0)],
    ['Profit', `<span class="${profit >= 0 ? 'pos' : 'neg'}">${profit >= 0 ? '+' : '−'}${cv(Math.abs(profit))}</span>`],
    ['Cases opened', fmt(p.cases_opened || 0)], ['Mines rounds', fmt(p.mines_played || 0)], ['Battles played', fmt(p.battles_played || 0)], ['Upgrades', fmt(p.upgrades_played || 0)], ['Blackjack hands', fmt(p.blackjack_played || 0)],
    ['Rewards claimed', cv(p.rewards || 0)], ['Tips sent', cv(p.tips_sent || 0)], ['Tips received', cv(p.tips_received || 0)]];
  $('ppStats').innerHTML = rows.map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('');
}
$('ppNameBtn').onclick = () => { $('nmInput').value = me.username; $('nmErr').textContent = ''; $('nameModal').hidden = false; $('nmInput').focus(); };
$('ppPassBtn').onclick = () => { $('ppPassForm').hidden = false; $('ppPassErr').textContent = ''; $('ppPass1').value = $('ppPass2').value = ''; $('ppPass1').focus(); };
$('ppPassCancel').onclick = () => { $('ppPassForm').hidden = true; };
$('ppPassForm').onsubmit = async e => {
  e.preventDefault();
  const a1 = $('ppPass1').value, a2 = $('ppPass2').value;
  if (a1.length < 8) return $('ppPassErr').textContent = 'Use at least 8 characters.';
  if (a1 !== a2) return $('ppPassErr').textContent = "The two passwords don't match.";
  $('ppPassGo').disabled = true;
  const { error } = await sb.auth.updateUser({ password: a1 });
  $('ppPassGo').disabled = false;
  if (error) return $('ppPassErr').textContent = niceErr(error);
  $('ppPassForm').hidden = true; toast('Password changed', 'win');
};
const GAME_IC = { admin: IC.plus, cases: IC.cases, mines: IC.mines, battles: IC.swords, upgrader: IC.up, blackjack: IC.cards, tips: IC.send, rewards: IC.plus };
let txOffset = 0, txReq = 0;
async function loadTx(reset) {
  if (!me) return;
  const my = ++txReq;
  if (reset) { txOffset = 0; $('txBody').innerHTML = '<tr><td colspan="4" class="txempty">Loading…</td></tr>'; }
  let q = sb.from('transactions').select('id,game,method,amount,created_at').order('id', { ascending: false });
  const g = $('txGame').value, am = $('txAmt').value, tm = $('txTime').value;
  if (g !== 'all') q = q.eq('game', g);
  if (am === 'in') q = q.gt('amount', 0); else if (am === 'out') q = q.lt('amount', 0);
  if (tm !== 'all') q = q.gte('created_at', new Date(Date.now() - (+tm) * 86400000).toISOString());
  const { data, error } = await q.range(txOffset, txOffset + 49);
  if (my !== txReq) return;
  if (error) { $('txBody').innerHTML = `<tr><td colspan="4" class="txempty">${esc(niceErr(error))}</td></tr>`; return; }
  const rows = (data || []).map(t => { const n = Number(t.amount); return `<tr><td><span class="g">${GAME_IC[t.game] || ''}${esc(t.game)}</span></td><td>${esc(t.method)}</td><td class="r ${n >= 0 ? 'amt-in' : 'amt-out'}">${n >= 0 ? '+' : '−'}${cv(Math.abs(n))}</td><td class="r">${new Date(t.created_at).toLocaleString([], { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</td></tr>`; }).join('');
  if (reset) $('txBody').innerHTML = rows || '<tr><td colspan="4" class="txempty">No transactions yet.</td></tr>';
  else $('txBody').insertAdjacentHTML('beforeend', rows);
  txOffset += (data || []).length;
  $('txMore').hidden = (data || []).length < 50;
}
['txGame', 'txAmt', 'txTime'].forEach(id => $(id).onchange = () => loadTx(true));
$('txMore').onclick = () => loadTx(false);
/* tips you receive arrive live */
function subscribeUser() {
  if (userCh) { sb.removeChannel(userCh); userCh = null; }
  if (!me) return;
  userCh = sb.channel('me-' + me.id)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'transactions', filter: 'user_id=eq.' + me.id }, p => {
      const t = p.new || {};
      if ((t.game === 'tips' || /^Weekly leaderboard/.test(t.method || '')) && Number(t.amount) > 0) {
        toast(`${esc(t.method)}: +${cv(t.amount)}`, 'win');
        call('my_profile').then(x => { if (x) showBal(x.coins); }).catch(() => {});
        bumpMe();
      }
      if ($('profile').classList.contains('on')) { clearTimeout(subscribeUser.t); subscribeUser.t = setTimeout(() => loadTx(true), 800); }
    })
    .subscribe();
}

/* ---------- start ---------- */
renderAuth(); renderChatInput(); renderCaseGrid(); renderChat(); renderLobby(true);
if (sb) {
  sb.auth.onAuthStateChange((event, session) => {
    if (event === 'PASSWORD_RECOVERY') openAuth('reset');
    setTimeout(async () => {
      const had = me && me.id;
      await refreshMe();
      if ((me && me.id) !== had) loadClaims();
      if (me && me.id !== had) { primed = false; resumeMines(); resumeBj(); loadBattles(); renderChat(); bumpMe(true); subscribeUser(); }
      if (!me && had) { MN.on = false; drawBoard(); BJ = null; $('bjDealer').innerHTML = ''; $('bjHands').innerHTML = ''; bjRender(null); renderChat(); lobbySig = ''; myProf = null; subscribeUser(); if ($('profile').classList.contains('on')) nav('mines'); }
    }, 0);
  });
  (async () => {
    await Promise.all([loadCases(), loadLevels(), loadUpgradeItems()]);
    await loadPacks();
    await refreshMe();
    if (me) { bumpMe(true); subscribeUser(); }
    loadClaims();
    await Promise.all([loadBattles(), loadChat()]);
    resumeMines(); resumeBj();
    subscribe(); try { trackOnline(); } catch (e) {}
    call('get_leaderboard').then(x => { LB = x; lbEnd = Date.parse(x.ends_at); }).catch(() => {});
  })();
}
